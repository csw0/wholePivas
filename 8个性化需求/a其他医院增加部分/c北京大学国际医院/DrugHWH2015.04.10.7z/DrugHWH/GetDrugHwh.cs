﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;


namespace DrugHWH
{
    internal partial class GetDrugHwh : Form
    {
        private string INIPath = Application.StartupPath + "\\Config.ini";
        private OleDbConnectionStringBuilder osb;
        private SqlConnectionStringBuilder ssb;
        private bool HadConn;
        private bool HasRun;
        private int ts = 0;
        internal GetDrugHwh()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // string oraconn = @"Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.3.1.71)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=orcl)));User Id=bl_pivas;Password=bl_pivas"; 
            //国药Oracle11g测试数据库访问地址：10.3.1.71
            //端口号：1521
            //实例名：orcl
            if (HadConn)
            {
                HadConn = false;
                timer1.Stop();
                textBox1.Enabled = true;
                textBox2.Enabled = true;
                textBox3.Enabled = true;
                textBox5.Enabled = true;
                textBox6.Enabled = true;
                textBox7.Enabled = true;
                textBox8.Enabled = true;
                textBox9.Enabled = true;
                label10.Text = "同步停止！";
                label10.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                try
                {
                    osb = new OleDbConnectionStringBuilder();
                    osb.Provider = "MSDAORA.1";
                    osb.DataSource = textBox1.Text.Trim();
                    osb.Add("User ID", textBox2.Text.Trim());
                    osb.Add("Password", textBox3.Text.Trim());
                    ssb = new SqlConnectionStringBuilder();
                    ssb.DataSource = textBox5.Text.Trim();
                    ssb.InitialCatalog = textBox6.Text.Trim();
                    ssb.UserID = textBox7.Text.Trim();
                    ssb.Password = textBox8.Text.Trim();
                    using (DataSet ds = new DataSet())
                    {
                        using (OleDbConnection odb = new OleDbConnection(osb.ConnectionString))
                        {
                            using (OleDbDataAdapter oda = new OleDbDataAdapter(textBox9.Text, odb))
                            {
                                oda.Fill(ds);
                            }
                        }
                        if (ds != null && ds.Tables.Count > 0)
                        {
                            if (ds.Tables[0].Rows.Count > 0)
                            {
                                ds.Tables[0].PrimaryKey = new DataColumn[] { ds.Tables[0].Columns[0] };
                                using (DataSet das = new DataSet())
                                {
                                    using (SqlConnection sdb = new SqlConnection(ssb.ConnectionString))
                                    {
                                        using (SqlDataAdapter sda = new SqlDataAdapter("SELECT [DrugCode],[PortNo] FROM [dbo].[DDrug]", sdb))
                                        {
                                            using (SqlCommandBuilder scb = new SqlCommandBuilder(sda))
                                            {
                                                sda.Fill(das);
                                                if (das != null && das.Tables.Count > 0 && das.Tables[0].Rows.Count > 0)
                                                {
                                                    das.Tables[0].PrimaryKey = new DataColumn[] { das.Tables[0].Columns[0] };
                                                    foreach (DataRow dr in ds.Tables[0].Rows)
                                                    {
                                                        foreach (DataRow drs in das.Tables[0].Select(string.Format("DrugCode like ('{0}%')", dr[0].ToString().Trim())))
                                                        {
                                                            drs[1] = dr[1].ToString().Trim();
                                                        }
                                                    }
                                                    scb.GetUpdateCommand();
                                                    scb.DataAdapter.Update(das.GetChanges(DataRowState.Modified));
                                                }
                                            }
                                        }
                                    }
                                }
                                HadConn = true;
                                timer1.Start();
                                textBox1.Enabled = false;
                                textBox2.Enabled = false;
                                textBox3.Enabled = false;
                                textBox5.Enabled = false;
                                textBox6.Enabled = false;
                                textBox7.Enabled = false;
                                textBox8.Enabled = false;
                                textBox9.Enabled = false;
                                label10.Text = "同步开始！";
                                label10.ForeColor = System.Drawing.Color.Green;
                                textBox4.Text = string.Empty;
                                WriteINI("DataBase", "textBox1", textBox1.Text.Trim());
                                WriteINI("DataBase", "textBox2", textBox2.Text.Trim());
                                WriteINI("DataBase", "textBox3", textBox3.Text.Trim());
                                WriteINI("DataBase", "textBox5", textBox5.Text.Trim());
                                WriteINI("DataBase", "textBox6", textBox6.Text.Trim());
                                WriteINI("DataBase", "textBox7", textBox7.Text.Trim());
                                WriteINI("DataBase", "textBox8", textBox8.Text.Trim());
                            }
                            else
                            {
                                MessageBox.Show("没有数据！！！");
                            }
                        }
                        else
                        {
                            MessageBox.Show("数据查询失败！！！");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (!HasRun)
            {
                HasRun = true;
            }
            else
            {
                if (ts < 3)
                {
                    ts = ts + 1;
                    return;
                }
                else
                {
                    ts = 0;
                }
            }
            try
            {
                using (DataSet ds = new DataSet())
                {
                    using (OleDbConnection odb = new OleDbConnection(osb.ConnectionString))
                    {
                        using (OleDbDataAdapter oda = new OleDbDataAdapter(textBox9.Text, odb))
                        {
                            oda.Fill(ds);
                        }
                    }
                    if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                    {
                        ds.Tables[0].PrimaryKey = new DataColumn[] { ds.Tables[0].Columns[0] };
                        using (DataSet das = new DataSet())
                        {
                            using (SqlConnection sdb = new SqlConnection(ssb.ConnectionString))
                            {
                                using (SqlDataAdapter sda = new SqlDataAdapter("SELECT [DrugCode],[PortNo] FROM [dbo].[DDrug]", sdb))
                                {
                                    using (SqlCommandBuilder scb = new SqlCommandBuilder(sda))
                                    {
                                        sda.Fill(das);
                                        if (das != null && das.Tables.Count > 0 && das.Tables[0].Rows.Count > 0)
                                        {
                                            das.Tables[0].PrimaryKey = new DataColumn[] { das.Tables[0].Columns[0] };
                                            foreach (DataRow dr in ds.Tables[0].Rows)
                                            {
                                                foreach (DataRow drs in das.Tables[0].Select(string.Format("DrugCode like ('{0}%')", dr[0].ToString().Trim())))
                                                {
                                                    drs[1] = dr[1].ToString().Trim();
                                                }
                                            }
                                            scb.GetUpdateCommand();
                                            scb.DataAdapter.Update(das.GetChanges(DataRowState.Modified));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                textBox4.Text = ex.Message;
            }
            finally
            {
                HasRun = false;
            }
        }

        private void GetDrugHwh_Load(object sender, EventArgs e)
        {
            textBox1.Text = string.IsNullOrEmpty(ReadINI("DataBase", "textBox1")) ? "orcl" : ReadINI("DataBase", "textBox1");
            textBox2.Text = string.IsNullOrEmpty(ReadINI("DataBase", "textBox2")) ? "bl_pivas" : ReadINI("DataBase", "textBox2");
            textBox3.Text = string.IsNullOrEmpty(ReadINI("DataBase", "textBox3")) ? "bl_pivas" : ReadINI("DataBase", "textBox3");
            StringBuilder sb = new StringBuilder(1024);
            sb.AppendLine("select ");
            sb.AppendLine("HOS_DRUG_CODE as DrugCode , ");
            sb.AppendLine("max(LOCATION_NME) as PortNo ");
            sb.AppendLine("from ");
            sb.AppendLine("spd_drug_allocation_v ");
            sb.AppendLine("group by HOS_DRUG_CODE ");
            textBox9.Text = sb.ToString();
            textBox5.Text = string.IsNullOrEmpty(ReadINI("DataBase", "textBox5")) ? "." : ReadINI("DataBase", "textBox5");
            textBox6.Text = string.IsNullOrEmpty(ReadINI("DataBase", "textBox6")) ? "Pivas2014" : ReadINI("DataBase", "textBox6");
            textBox7.Text = string.IsNullOrEmpty(ReadINI("DataBase", "textBox7")) ? "laennec" : ReadINI("DataBase", "textBox7");
            textBox8.Text = string.IsNullOrEmpty(ReadINI("DataBase", "textBox8")) ? "13816350872" : ReadINI("DataBase", "textBox8");
            comboBox1.SelectedIndex = 0;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    {
                        timer1.Interval = 1000 * 600;
                        break;
                    }
                case 1:
                    {
                        timer1.Interval = 1000 * 1800;
                        break;
                    }
                case 2:
                    {
                        timer1.Interval = 1000 * 3600;
                        break;
                    }
                case 3:
                    {
                        timer1.Interval = 1000 * 6 * 3600;
                        break;
                    }
                case 4:
                    {
                        timer1.Interval = 1000 * 12 * 3600;
                        break;
                    }
                default:
                    {
                        timer1.Interval = 1000 * 24 * 3600;
                        break;
                    }
            }
        }
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string BigNode, string SmallNode, string def, StringBuilder val, int size, string INIPath);
        private string ReadINI(string BigNode, string SmallNode)
        {
            StringBuilder temp = new StringBuilder(1024);
            GetPrivateProfileString(BigNode, SmallNode, string.Empty, temp, 1024, INIPath);
            return temp.ToString();
        }
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string BigNode, string SmallNode, string val, string filePath);
        private void WriteINI(string BigNode, string SmallNode, string value)
        {
            WritePrivateProfileString(BigNode, SmallNode, value, INIPath);
        }
    }
}
