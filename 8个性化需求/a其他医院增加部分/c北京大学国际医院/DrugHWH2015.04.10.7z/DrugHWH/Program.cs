﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace DrugHWH
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            int ns = Process.GetProcessesByName(Process.GetCurrentProcess().ProcessName).Length;
            if (ns < 2)
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new GetDrugHwh());
            }
        }
    }
}
