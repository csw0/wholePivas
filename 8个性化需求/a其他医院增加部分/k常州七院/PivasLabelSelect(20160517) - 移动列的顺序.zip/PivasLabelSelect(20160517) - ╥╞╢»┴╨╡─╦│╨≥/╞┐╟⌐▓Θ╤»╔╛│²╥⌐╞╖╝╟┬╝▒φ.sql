USE [SFY20160321]
GO

/****** Object:  Table [dbo].[IVRecord_DrugDeleteLog]    Script Date: 04/27/2016 11:10:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[IVRecord_DrugDeleteLog](
	[DeleteID] [bigint] IDENTITY(1,1) NOT NULL,
	[IVRecodedDetaiID] [bigint] NULL,
	[LabelNo] [varchar](16) NOT NULL,
	[DrugCode] [varchar](50) NOT NULL,
	[DemoloyID] [varchar](16) NOT NULL,
	[Insertdt] [datetime] NULL,
	[Dosage] [decimal](12, 4) NULL,
	[DosageUnit] [varchar](8) NULL,
	[DgNo] [int] NULL,
	[ReturnFromHis] [int] NULL,
	[Remark7] [varchar](128) NULL,
	[Remark8] [varchar](128) NULL,
	[Remark9] [varchar](128) NULL,
	[Remark10] [varchar](128) NULL,
	[RecipeNo] [varchar](50) NULL,
 CONSTRAINT [PK_IVRecord_DrugDeleteLog] PRIMARY KEY CLUSTERED 
(
	[DeleteID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[IVRecord_DrugDeleteLog] ADD  CONSTRAINT [DF_IVRecord_DrugDeleteLog_DgNo]  DEFAULT ((0)) FOR [DgNo]
GO

ALTER TABLE [dbo].[IVRecord_DrugDeleteLog] ADD  CONSTRAINT [DF_IVRecord_DrugDeleteLog_ReturnFromHis]  DEFAULT ((-1)) FOR [ReturnFromHis]
GO


