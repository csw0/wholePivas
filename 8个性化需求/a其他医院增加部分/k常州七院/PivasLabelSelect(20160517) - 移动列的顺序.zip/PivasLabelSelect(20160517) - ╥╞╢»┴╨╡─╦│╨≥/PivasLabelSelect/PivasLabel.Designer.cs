﻿namespace PivasLabelSelect
{
    partial class PivasLabel
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PivasLabel));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label42 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.pnlcancel = new System.Windows.Forms.Panel();
            this.txtUname = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.textHeight = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.textEndDT = new System.Windows.Forms.TextBox();
            this.textStartDT = new System.Windows.Forms.TextBox();
            this.textAge = new System.Windows.Forms.TextBox();
            this.textWeight = new System.Windows.Forms.TextBox();
            this.txtCaseID = new System.Windows.Forms.TextBox();
            this.textDrawerName = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.textPatient = new System.Windows.Forms.TextBox();
            this.txtBedNo = new System.Windows.Forms.TextBox();
            this.textWard = new System.Windows.Forms.TextBox();
            this.txtBatch = new System.Windows.Forms.TextBox();
            this.txtSex = new System.Windows.Forms.TextBox();
            this.txtDoctor = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pnlInfo = new System.Windows.Forms.FlowLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Button();
            this.Lb_Print = new System.Windows.Forms.Button();
            this.lbCount = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnPrint = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.dgvDWard = new System.Windows.Forms.DataGridView();
            this.Column2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.WardName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.TQDB = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.Line1 = new System.Windows.Forms.Label();
            this.Line2 = new System.Windows.Forms.Label();
            this.Line4 = new System.Windows.Forms.Label();
            this.dgvPre = new System.Windows.Forms.DataGridView();
            this.txtWard = new System.Windows.Forms.TextBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.flowLayoutPanel7 = new System.Windows.Forms.FlowLayoutPanel();
            this.label21 = new System.Windows.Forms.Label();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.linkLabel18 = new System.Windows.Forms.LinkLabel();
            this.linkLabel16 = new System.Windows.Forms.LinkLabel();
            this.linkLabel17 = new System.Windows.Forms.LinkLabel();
            this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
            this.label29 = new System.Windows.Forms.Label();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.linkLabel13 = new System.Windows.Forms.LinkLabel();
            this.linkLabel15 = new System.Windows.Forms.LinkLabel();
            this.linkLabel14 = new System.Windows.Forms.LinkLabel();
            this.flowLayoutPanel11 = new System.Windows.Forms.FlowLayoutPanel();
            this.label43 = new System.Windows.Forms.Label();
            this.linkLabel29 = new System.Windows.Forms.LinkLabel();
            this.linkLabel30 = new System.Windows.Forms.LinkLabel();
            this.linkLabel34 = new System.Windows.Forms.LinkLabel();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.label30 = new System.Windows.Forms.Label();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.linkLabel31 = new System.Windows.Forms.LinkLabel();
            this.linkLabel20 = new System.Windows.Forms.LinkLabel();
            this.linkLabel19 = new System.Windows.Forms.LinkLabel();
            this.label36 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.linkLabel35 = new System.Windows.Forms.LinkLabel();
            this.linkLabel27 = new System.Windows.Forms.LinkLabel();
            this.linkLabel26 = new System.Windows.Forms.LinkLabel();
            this.linkLabel25 = new System.Windows.Forms.LinkLabel();
            this.linkLabel24 = new System.Windows.Forms.LinkLabel();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.label31 = new System.Windows.Forms.Label();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.flowLayoutPanel10 = new System.Windows.Forms.FlowLayoutPanel();
            this.linkLabel33 = new System.Windows.Forms.LinkLabel();
            this.linkLabel23 = new System.Windows.Forms.LinkLabel();
            this.linkLabel21 = new System.Windows.Forms.LinkLabel();
            this.label37 = new System.Windows.Forms.Label();
            this.flowLayoutPanel9 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.label32 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.linkLabel28 = new System.Windows.Forms.LinkLabel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.cb_ys = new System.Windows.Forms.CheckBox();
            this.cb_yp = new System.Windows.Forms.CheckBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.linkLabel5 = new System.Windows.Forms.LinkLabel();
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.linkLabel7 = new System.Windows.Forms.LinkLabel();
            this.linkLabel8 = new System.Windows.Forms.LinkLabel();
            this.linkLabel9 = new System.Windows.Forms.LinkLabel();
            this.linkLabel10 = new System.Windows.Forms.LinkLabel();
            this.linkLabel11 = new System.Windows.Forms.LinkLabel();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.linkLabel12 = new System.Windows.Forms.LinkLabel();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel8 = new System.Windows.Forms.FlowLayoutPanel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.cb_hour1 = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.cb_hour2 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label18 = new System.Windows.Forms.Label();
            this.Pic_Max = new System.Windows.Forms.Panel();
            this.Pic_Min = new System.Windows.Forms.Panel();
            this.Panel_Close = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.cbbList = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.linkLabel22 = new System.Windows.Forms.LinkLabel();
            this.linkLabel32 = new System.Windows.Forms.LinkLabel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.cbbPrinted = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.Line3 = new System.Windows.Forms.Label();
            this.Select = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.IVStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remark = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LabelNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.remark6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DWard = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BedNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PatName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GroupNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Batch = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Class = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MainDrug = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MenstruumName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrescriptionID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chrgetype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel3.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDWard)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPre)).BeginInit();
            this.flowLayoutPanel7.SuspendLayout();
            this.flowLayoutPanel6.SuspendLayout();
            this.flowLayoutPanel11.SuspendLayout();
            this.flowLayoutPanel5.SuspendLayout();
            this.panel7.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.flowLayoutPanel10.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.panel8.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel8.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.pnlcancel);
            this.panel2.Controls.Add(this.txtUname);
            this.panel2.Controls.Add(this.label41);
            this.panel2.Controls.Add(this.textHeight);
            this.panel2.Controls.Add(this.label35);
            this.panel2.Controls.Add(this.textEndDT);
            this.panel2.Controls.Add(this.textStartDT);
            this.panel2.Controls.Add(this.textAge);
            this.panel2.Controls.Add(this.textWeight);
            this.panel2.Controls.Add(this.txtCaseID);
            this.panel2.Controls.Add(this.textDrawerName);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.textPatient);
            this.panel2.Controls.Add(this.txtBedNo);
            this.panel2.Controls.Add(this.textWard);
            this.panel2.Controls.Add(this.txtBatch);
            this.panel2.Controls.Add(this.txtSex);
            this.panel2.Controls.Add(this.txtDoctor);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.pnlInfo);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Location = new System.Drawing.Point(196, 576);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1032, 228);
            this.panel2.TabIndex = 1013;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.label42);
            this.panel9.Controls.Add(this.button6);
            this.panel9.Controls.Add(this.button5);
            this.panel9.Controls.Add(this.listBox1);
            this.panel9.Location = new System.Drawing.Point(686, 3);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(124, 101);
            this.panel9.TabIndex = 0;
            this.panel9.Visible = false;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(3, 6);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(0, 12);
            this.label42.TabIndex = 1037;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(93, 62);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(29, 36);
            this.button6.TabIndex = 1036;
            this.button6.Text = "▼";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(93, 24);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(29, 36);
            this.button5.TabIndex = 1035;
            this.button5.Text = "▲";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(0, 23);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(93, 76);
            this.listBox1.TabIndex = 1034;
            // 
            // pnlcancel
            // 
            this.pnlcancel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlcancel.Location = new System.Drawing.Point(535, 4);
            this.pnlcancel.Name = "pnlcancel";
            this.pnlcancel.Size = new System.Drawing.Size(495, 223);
            this.pnlcancel.TabIndex = 1017;
            this.toolTip1.SetToolTip(this.pnlcancel, "瓶签扫描记录");
            // 
            // txtUname
            // 
            this.txtUname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.txtUname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUname.Location = new System.Drawing.Point(454, 65);
            this.txtUname.Name = "txtUname";
            this.txtUname.ReadOnly = true;
            this.txtUname.Size = new System.Drawing.Size(81, 14);
            this.txtUname.TabIndex = 1033;
            this.txtUname.Text = "用药途径";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.ForeColor = System.Drawing.Color.Gray;
            this.label41.Location = new System.Drawing.Point(398, 66);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(65, 12);
            this.label41.TabIndex = 1032;
            this.label41.Text = "用药途径：";
            // 
            // textHeight
            // 
            this.textHeight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.textHeight.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textHeight.Location = new System.Drawing.Point(455, 28);
            this.textHeight.Name = "textHeight";
            this.textHeight.ReadOnly = true;
            this.textHeight.Size = new System.Drawing.Size(76, 14);
            this.textHeight.TabIndex = 1031;
            this.textHeight.Text = "身高";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.ForeColor = System.Drawing.Color.Gray;
            this.label35.Location = new System.Drawing.Point(422, 28);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(41, 12);
            this.label35.TabIndex = 1030;
            this.label35.Text = "身高：";
            // 
            // textEndDT
            // 
            this.textEndDT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.textEndDT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textEndDT.Location = new System.Drawing.Point(247, 66);
            this.textEndDT.Name = "textEndDT";
            this.textEndDT.ReadOnly = true;
            this.textEndDT.Size = new System.Drawing.Size(132, 14);
            this.textEndDT.TabIndex = 1029;
            this.textEndDT.Text = "停止日期";
            // 
            // textStartDT
            // 
            this.textStartDT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.textStartDT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textStartDT.Location = new System.Drawing.Point(63, 66);
            this.textStartDT.Name = "textStartDT";
            this.textStartDT.ReadOnly = true;
            this.textStartDT.Size = new System.Drawing.Size(127, 14);
            this.textStartDT.TabIndex = 1028;
            this.textStartDT.Text = "开始日期";
            // 
            // textAge
            // 
            this.textAge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.textAge.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textAge.Location = new System.Drawing.Point(316, 46);
            this.textAge.Name = "textAge";
            this.textAge.ReadOnly = true;
            this.textAge.Size = new System.Drawing.Size(137, 14);
            this.textAge.TabIndex = 1027;
            this.textAge.Text = "年龄";
            // 
            // textWeight
            // 
            this.textWeight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.textWeight.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textWeight.Location = new System.Drawing.Point(316, 28);
            this.textWeight.Name = "textWeight";
            this.textWeight.ReadOnly = true;
            this.textWeight.Size = new System.Drawing.Size(100, 14);
            this.textWeight.TabIndex = 1026;
            this.textWeight.Text = "体重";
            // 
            // txtCaseID
            // 
            this.txtCaseID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.txtCaseID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCaseID.Location = new System.Drawing.Point(183, 30);
            this.txtCaseID.Name = "txtCaseID";
            this.txtCaseID.ReadOnly = true;
            this.txtCaseID.Size = new System.Drawing.Size(100, 14);
            this.txtCaseID.TabIndex = 1019;
            this.txtCaseID.Text = "住院号";
            // 
            // textDrawerName
            // 
            this.textDrawerName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.textDrawerName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textDrawerName.Location = new System.Drawing.Point(316, 11);
            this.textDrawerName.Name = "textDrawerName";
            this.textDrawerName.ReadOnly = true;
            this.textDrawerName.Size = new System.Drawing.Size(100, 14);
            this.textDrawerName.TabIndex = 1025;
            this.textDrawerName.Text = "录入";
            // 
            // label26
            // 
            this.label26.ForeColor = System.Drawing.Color.Gray;
            this.label26.Location = new System.Drawing.Point(137, 29);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(53, 12);
            this.label26.TabIndex = 445;
            this.label26.Text = "住院号：";
            // 
            // textPatient
            // 
            this.textPatient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.textPatient.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textPatient.Location = new System.Drawing.Point(39, 47);
            this.textPatient.Name = "textPatient";
            this.textPatient.ReadOnly = true;
            this.textPatient.Size = new System.Drawing.Size(100, 14);
            this.textPatient.TabIndex = 1024;
            this.textPatient.Text = "患者姓名";
            this.textPatient.TextChanged += new System.EventHandler(this.textPatient_TextChanged);
            // 
            // txtBedNo
            // 
            this.txtBedNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.txtBedNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBedNo.Location = new System.Drawing.Point(39, 29);
            this.txtBedNo.Name = "txtBedNo";
            this.txtBedNo.ReadOnly = true;
            this.txtBedNo.Size = new System.Drawing.Size(100, 14);
            this.txtBedNo.TabIndex = 1023;
            this.txtBedNo.Text = "床号";
            // 
            // textWard
            // 
            this.textWard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.textWard.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textWard.Location = new System.Drawing.Point(40, 11);
            this.textWard.Name = "textWard";
            this.textWard.ReadOnly = true;
            this.textWard.Size = new System.Drawing.Size(100, 14);
            this.textWard.TabIndex = 1022;
            this.textWard.Text = "病区";
            // 
            // txtBatch
            // 
            this.txtBatch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.txtBatch.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBatch.Location = new System.Drawing.Point(457, 11);
            this.txtBatch.Name = "txtBatch";
            this.txtBatch.ReadOnly = true;
            this.txtBatch.Size = new System.Drawing.Size(75, 14);
            this.txtBatch.TabIndex = 1021;
            this.txtBatch.Text = "频次";
            // 
            // txtSex
            // 
            this.txtSex.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.txtSex.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSex.Location = new System.Drawing.Point(184, 48);
            this.txtSex.Name = "txtSex";
            this.txtSex.ReadOnly = true;
            this.txtSex.Size = new System.Drawing.Size(100, 14);
            this.txtSex.TabIndex = 1020;
            this.txtSex.Text = "性别";
            // 
            // txtDoctor
            // 
            this.txtDoctor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.txtDoctor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDoctor.Location = new System.Drawing.Point(185, 11);
            this.txtDoctor.Name = "txtDoctor";
            this.txtDoctor.ReadOnly = true;
            this.txtDoctor.Size = new System.Drawing.Size(100, 14);
            this.txtDoctor.TabIndex = 1018;
            this.txtDoctor.Text = "医生";
            // 
            // label9
            // 
            this.label9.ForeColor = System.Drawing.Color.Gray;
            this.label9.Location = new System.Drawing.Point(278, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 12);
            this.label9.TabIndex = 449;
            this.label9.Text = "录入：";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.BackColor = System.Drawing.Color.Silver;
            this.label6.Location = new System.Drawing.Point(4, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(1094, 1);
            this.label6.TabIndex = 1016;
            // 
            // pnlInfo
            // 
            this.pnlInfo.AutoScroll = true;
            this.pnlInfo.Location = new System.Drawing.Point(6, 114);
            this.pnlInfo.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.pnlInfo.Name = "pnlInfo";
            this.pnlInfo.Size = new System.Drawing.Size(526, 112);
            this.pnlInfo.TabIndex = 468;
            this.toolTip1.SetToolTip(this.pnlInfo, "选中瓶签的用药明细");
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Location = new System.Drawing.Point(7, 87);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(525, 25);
            this.panel3.TabIndex = 467;
            this.toolTip1.SetToolTip(this.panel3, "YYYY");
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.ForeColor = System.Drawing.Color.Gray;
            this.label16.Location = new System.Drawing.Point(452, 4);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 17);
            this.label16.TabIndex = 3;
            this.label16.Text = "皮试";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.ForeColor = System.Drawing.Color.Gray;
            this.label15.Location = new System.Drawing.Point(366, 4);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 17);
            this.label15.TabIndex = 2;
            this.label15.Text = "用量";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.ForeColor = System.Drawing.Color.Gray;
            this.label14.Location = new System.Drawing.Point(318, 4);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(32, 17);
            this.label14.TabIndex = 1;
            this.label14.Text = "规格";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.ForeColor = System.Drawing.Color.Gray;
            this.label12.Location = new System.Drawing.Point(11, 5);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(158, 17);
            this.label12.TabIndex = 0;
            this.label12.Text = "药品名称";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.ForeColor = System.Drawing.Color.Gray;
            this.label13.Location = new System.Drawing.Point(422, 11);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 463;
            this.label13.Text = "频次：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Gray;
            this.label11.Location = new System.Drawing.Point(283, 28);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 462;
            this.label11.Text = "体重：";
            // 
            // label10
            // 
            this.label10.ForeColor = System.Drawing.Color.Gray;
            this.label10.Location = new System.Drawing.Point(283, 46);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 12);
            this.label10.TabIndex = 461;
            this.label10.Text = "年龄：";
            // 
            // label8
            // 
            this.label8.ForeColor = System.Drawing.Color.Gray;
            this.label8.Location = new System.Drawing.Point(4, 66);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 12);
            this.label8.TabIndex = 451;
            this.label8.Text = "开始日期：";
            // 
            // label22
            // 
            this.label22.ForeColor = System.Drawing.Color.Gray;
            this.label22.Location = new System.Drawing.Point(190, 66);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 12);
            this.label22.TabIndex = 450;
            this.label22.Text = "停止日期：";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.Gray;
            this.label23.Location = new System.Drawing.Point(149, 48);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 12);
            this.label23.TabIndex = 448;
            this.label23.Text = "性别：";
            // 
            // label24
            // 
            this.label24.ForeColor = System.Drawing.Color.Gray;
            this.label24.Location = new System.Drawing.Point(5, 29);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(41, 12);
            this.label24.TabIndex = 447;
            this.label24.Text = "床号：";
            // 
            // label25
            // 
            this.label25.ForeColor = System.Drawing.Color.Gray;
            this.label25.Location = new System.Drawing.Point(5, 47);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(47, 12);
            this.label25.TabIndex = 446;
            this.label25.Text = "患者：";
            // 
            // label27
            // 
            this.label27.ForeColor = System.Drawing.Color.Gray;
            this.label27.Location = new System.Drawing.Point(149, 11);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(41, 12);
            this.label27.TabIndex = 444;
            this.label27.Text = "医生：";
            // 
            // label28
            // 
            this.label28.ForeColor = System.Drawing.Color.Gray;
            this.label28.Location = new System.Drawing.Point(5, 11);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(41, 12);
            this.label28.TabIndex = 443;
            this.label28.Text = "病区：";
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.Gainsboro;
            this.panel4.Location = new System.Drawing.Point(-3, 807);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1245, 94);
            this.panel4.TabIndex = 1014;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.label2);
            this.flowLayoutPanel1.Controls.Add(this.label5);
            this.flowLayoutPanel1.Controls.Add(this.Lb_Print);
            this.flowLayoutPanel1.Controls.Add(this.lbCount);
            this.flowLayoutPanel1.Controls.Add(this.button1);
            this.flowLayoutPanel1.Controls.Add(this.button2);
            this.flowLayoutPanel1.Controls.Add(this.button3);
            this.flowLayoutPanel1.Controls.Add(this.button4);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(67, 1);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(598, 30);
            this.flowLayoutPanel1.TabIndex = 1043;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(3, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 26);
            this.label2.TabIndex = 1035;
            this.label2.Text = "核对";
            this.toolTip1.SetToolTip(this.label2, "扫描核对画面调用，扫描瓶签勾选。");
            this.label2.UseVisualStyleBackColor = false;
            this.label2.Visible = false;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(75, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 26);
            this.label5.TabIndex = 1036;
            this.label5.Text = "退药";
            this.toolTip1.SetToolTip(this.label5, "退药：按下后，勾选的瓶签会变成配置取消。需要到配置取消再《审核》瓶签，才能真正退药。                                     审核" +
        "：按下后，配置取消瓶签，真正退药。");
            this.label5.UseVisualStyleBackColor = false;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // Lb_Print
            // 
            this.Lb_Print.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Lb_Print.Location = new System.Drawing.Point(147, 3);
            this.Lb_Print.Name = "Lb_Print";
            this.Lb_Print.Size = new System.Drawing.Size(65, 26);
            this.Lb_Print.TabIndex = 1037;
            this.Lb_Print.Text = "打印";
            this.toolTip1.SetToolTip(this.Lb_Print, "打印：打印勾选的瓶签");
            this.Lb_Print.UseVisualStyleBackColor = false;
            this.Lb_Print.Click += new System.EventHandler(this.lbPrint_Click);
            // 
            // lbCount
            // 
            this.lbCount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbCount.Location = new System.Drawing.Point(218, 3);
            this.lbCount.Name = "lbCount";
            this.lbCount.Size = new System.Drawing.Size(66, 26);
            this.lbCount.TabIndex = 1039;
            this.lbCount.Text = "汇总";
            this.toolTip1.SetToolTip(this.lbCount, "汇总单画面调用");
            this.lbCount.UseVisualStyleBackColor = false;
            this.lbCount.Visible = false;
            this.lbCount.Click += new System.EventHandler(this.lbCount_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button1.Location = new System.Drawing.Point(290, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(66, 26);
            this.button1.TabIndex = 1040;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button2.Location = new System.Drawing.Point(362, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(66, 26);
            this.button2.TabIndex = 1041;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button3.Location = new System.Drawing.Point(434, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(66, 26);
            this.button3.TabIndex = 1042;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button4.Location = new System.Drawing.Point(506, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(66, 26);
            this.button4.TabIndex = 1043;
            this.button4.Text = "导出";
            this.toolTip1.SetToolTip(this.button4, "打印：打印勾选的瓶签");
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.SystemColors.Control;
            this.panel5.Controls.Add(this.btnPrint);
            this.panel5.Controls.Add(this.button7);
            this.panel5.Controls.Add(this.flowLayoutPanel1);
            this.panel5.Controls.Add(this.checkBox2);
            this.panel5.Location = new System.Drawing.Point(196, 544);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1033, 32);
            this.panel5.TabIndex = 1015;
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(844, 4);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(75, 23);
            this.btnPrint.TabIndex = 1045;
            this.btnPrint.Text = "打印预览";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(744, 4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(66, 23);
            this.button7.TabIndex = 1044;
            this.button7.Text = "打印排序";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // checkBox2
            // 
            this.checkBox2.Location = new System.Drawing.Point(13, 9);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(51, 18);
            this.checkBox2.TabIndex = 1040;
            this.checkBox2.Text = "全选";
            this.toolTip1.SetToolTip(this.checkBox2, "全选");
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.Click += new System.EventHandler(this.checkBox2_Click);
            // 
            // dgvDWard
            // 
            this.dgvDWard.AllowUserToAddRows = false;
            this.dgvDWard.AllowUserToResizeRows = false;
            this.dgvDWard.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dgvDWard.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.dgvDWard.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDWard.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDWard.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvDWard.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2,
            this.WardName,
            this.DCount,
            this.Column1});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(210)))), ((int)(((byte)(250)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDWard.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvDWard.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.dgvDWard.Location = new System.Drawing.Point(1, 36);
            this.dgvDWard.MultiSelect = false;
            this.dgvDWard.Name = "dgvDWard";
            this.dgvDWard.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDWard.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvDWard.RowHeadersVisible = false;
            this.dgvDWard.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            this.dgvDWard.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvDWard.RowTemplate.Height = 23;
            this.dgvDWard.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvDWard.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDWard.Size = new System.Drawing.Size(193, 731);
            this.dgvDWard.TabIndex = 988;
            this.toolTip1.SetToolTip(this.dgvDWard, "病区列表   您可以勾选几个病区，或者点击选中一个病区。");
            this.dgvDWard.Click += new System.EventHandler(this.dgvDWard_Click);
            // 
            // Column2
            // 
            this.Column2.HeaderText = "";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 20;
            // 
            // WardName
            // 
            this.WardName.DataPropertyName = "WardName";
            this.WardName.HeaderText = "病区";
            this.WardName.Name = "WardName";
            this.WardName.ReadOnly = true;
            this.WardName.Width = 107;
            // 
            // DCount
            // 
            this.DCount.DataPropertyName = "DCount";
            this.DCount.HeaderText = "数量";
            this.DCount.Name = "DCount";
            this.DCount.ReadOnly = true;
            this.DCount.Width = 50;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "WardSeqNo";
            this.Column1.HeaderText = "Column1";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // TQDB
            // 
            this.TQDB.Name = "TQDB";
            this.TQDB.Size = new System.Drawing.Size(124, 22);
            this.TQDB.Text = "提前打包";
            this.TQDB.Click += new System.EventHandler(this.TQDB_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TQDB});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(125, 26);
            this.contextMenuStrip1.Opened += new System.EventHandler(this.contextMenuStrip1_Opened);
            // 
            // Line1
            // 
            this.Line1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Line1.BackColor = System.Drawing.Color.White;
            this.Line1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.Line1.ForeColor = System.Drawing.Color.Silver;
            this.Line1.Location = new System.Drawing.Point(202, 95);
            this.Line1.Name = "Line1";
            this.Line1.Size = new System.Drawing.Size(1026, 10);
            this.Line1.TabIndex = 1042;
            this.Line1.Text = resources.GetString("Line1.Text");
            this.Line1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Line2
            // 
            this.Line2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Line2.BackColor = System.Drawing.Color.White;
            this.Line2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.Line2.ForeColor = System.Drawing.Color.Silver;
            this.Line2.Location = new System.Drawing.Point(202, 129);
            this.Line2.Name = "Line2";
            this.Line2.Size = new System.Drawing.Size(1025, 10);
            this.Line2.TabIndex = 1043;
            this.Line2.Text = resources.GetString("Line2.Text");
            this.Line2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Line4
            // 
            this.Line4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Line4.BackColor = System.Drawing.Color.White;
            this.Line4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.Line4.ForeColor = System.Drawing.Color.Silver;
            this.Line4.Location = new System.Drawing.Point(3, 32);
            this.Line4.Name = "Line4";
            this.Line4.Size = new System.Drawing.Size(801, 15);
            this.Line4.TabIndex = 1045;
            this.Line4.Text = resources.GetString("Line4.Text");
            this.Line4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Line4.Visible = false;
            // 
            // dgvPre
            // 
            this.dgvPre.AllowUserToAddRows = false;
            this.dgvPre.AllowUserToResizeRows = false;
            this.dgvPre.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvPre.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.dgvPre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPre.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvPre.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Select,
            this.IVStatus,
            this.Remark,
            this.LabelNo,
            this.remark6,
            this.DWard,
            this.BedNo,
            this.PatName,
            this.GroupNo,
            this.Batch,
            this.Class,
            this.MainDrug,
            this.MenstruumName,
            this.PrescriptionID,
            this.chrgetype});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPre.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgvPre.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.dgvPre.Location = new System.Drawing.Point(195, 202);
            this.dgvPre.MultiSelect = false;
            this.dgvPre.Name = "dgvPre";
            this.dgvPre.ReadOnly = true;
            this.dgvPre.RowHeadersVisible = false;
            this.dgvPre.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            this.dgvPre.RowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvPre.RowTemplate.Height = 23;
            this.dgvPre.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPre.Size = new System.Drawing.Size(1035, 340);
            this.dgvPre.TabIndex = 1046;
            this.toolTip1.SetToolTip(this.dgvPre, "YYYY");
            this.dgvPre.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPre_CellClick);
            this.dgvPre.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPre_CellContentClick);
            this.dgvPre.Sorted += new System.EventHandler(this.dgvPre_Sorted);
            this.dgvPre.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgvPre_MouseDown);
            // 
            // txtWard
            // 
            this.txtWard.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtWard.BackColor = System.Drawing.Color.White;
            this.txtWard.ForeColor = System.Drawing.Color.Gray;
            this.txtWard.Location = new System.Drawing.Point(92, 785);
            this.txtWard.Name = "txtWard";
            this.txtWard.Size = new System.Drawing.Size(101, 21);
            this.txtWard.TabIndex = 1047;
            this.txtWard.Text = "病区名/简拼";
            this.toolTip1.SetToolTip(this.txtWard, "病区名与病区简拼的模糊查询");
            this.txtWard.TextChanged += new System.EventHandler(this.txtWard_TextChanged);
            this.txtWard.Enter += new System.EventHandler(this.txtWard_Enter);
            this.txtWard.Leave += new System.EventHandler(this.txtWard_Leave);
            // 
            // comboBox4
            // 
            this.comboBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBox4.BackColor = System.Drawing.Color.White;
            this.comboBox4.ForeColor = System.Drawing.Color.Gray;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(1, 786);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(90, 20);
            this.comboBox4.TabIndex = 1048;
            this.toolTip1.SetToolTip(this.comboBox4, "病区组筛选     根据您在病区维护里维护的病区组，进行筛选。");
            this.comboBox4.SelectionChangeCommitted += new System.EventHandler(this.comboBox4_SelectionChangeCommitted);
            this.comboBox4.Enter += new System.EventHandler(this.comboBox4_Enter);
            this.comboBox4.Leave += new System.EventHandler(this.comboBox4_Leave);
            // 
            // label34
            // 
            this.label34.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label34.Location = new System.Drawing.Point(1230, 73);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(33, 733);
            this.label34.TabIndex = 1049;
            // 
            // checkBox3
            // 
            this.checkBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBox3.AutoSize = true;
            this.checkBox3.Checked = true;
            this.checkBox3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox3.Location = new System.Drawing.Point(3, 767);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(120, 16);
            this.checkBox3.TabIndex = 1050;
            this.checkBox3.Text = "仅显示有数据病区";
            this.toolTip1.SetToolTip(this.checkBox3, "勾上后，您可以隐藏没有瓶签的病区。");
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // flowLayoutPanel7
            // 
            this.flowLayoutPanel7.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.flowLayoutPanel7.BackColor = System.Drawing.Color.White;
            this.flowLayoutPanel7.Controls.Add(this.label21);
            this.flowLayoutPanel7.Controls.Add(this.checkBox7);
            this.flowLayoutPanel7.Controls.Add(this.linkLabel18);
            this.flowLayoutPanel7.Controls.Add(this.linkLabel16);
            this.flowLayoutPanel7.Controls.Add(this.linkLabel17);
            this.flowLayoutPanel7.Controls.Add(this.flowLayoutPanel6);
            this.flowLayoutPanel7.Controls.Add(this.flowLayoutPanel11);
            this.flowLayoutPanel7.Controls.Add(this.Line4);
            this.flowLayoutPanel7.Location = new System.Drawing.Point(7, 134);
            this.flowLayoutPanel7.Margin = new System.Windows.Forms.Padding(7, 3, 10, 0);
            this.flowLayoutPanel7.Name = "flowLayoutPanel7";
            this.flowLayoutPanel7.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.flowLayoutPanel7.Size = new System.Drawing.Size(1025, 32);
            this.flowLayoutPanel7.TabIndex = 11;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(180)))), ((int)(((byte)(43)))));
            this.label21.Location = new System.Drawing.Point(3, 4);
            this.label21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.label21.Name = "label21";
            this.label21.Padding = new System.Windows.Forms.Padding(5, 5, 0, 5);
            this.label21.Size = new System.Drawing.Size(40, 22);
            this.label21.TabIndex = 1045;
            this.label21.Text = "清单:";
            this.toolTip1.SetToolTip(this.label21, "有没有打印过打印清单筛选");
            // 
            // checkBox7
            // 
            this.checkBox7.Checked = true;
            this.checkBox7.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox7.Enabled = false;
            this.checkBox7.Location = new System.Drawing.Point(49, 7);
            this.checkBox7.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(72, 16);
            this.checkBox7.TabIndex = 1038;
            this.checkBox7.Text = "仅此状态";
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.Visible = false;
            // 
            // linkLabel18
            // 
            this.linkLabel18.AutoSize = true;
            this.linkLabel18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel18.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel18.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel18.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel18.Location = new System.Drawing.Point(127, 4);
            this.linkLabel18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel18.Name = "linkLabel18";
            this.linkLabel18.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel18.Size = new System.Drawing.Size(46, 22);
            this.linkLabel18.TabIndex = 1044;
            this.linkLabel18.TabStop = true;
            this.linkLabel18.Text = "<全部>";
            this.linkLabel18.Click += new System.EventHandler(this.linkLabel16_Click);
            // 
            // linkLabel16
            // 
            this.linkLabel16.AutoSize = true;
            this.linkLabel16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel16.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel16.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel16.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel16.Location = new System.Drawing.Point(179, 4);
            this.linkLabel16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel16.Name = "linkLabel16";
            this.linkLabel16.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel16.Size = new System.Drawing.Size(46, 22);
            this.linkLabel16.TabIndex = 1042;
            this.linkLabel16.TabStop = true;
            this.linkLabel16.Text = "已打印";
            this.linkLabel16.Click += new System.EventHandler(this.linkLabel16_Click);
            // 
            // linkLabel17
            // 
            this.linkLabel17.AutoSize = true;
            this.linkLabel17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel17.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel17.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel17.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel17.Location = new System.Drawing.Point(231, 4);
            this.linkLabel17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel17.Name = "linkLabel17";
            this.linkLabel17.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel17.Size = new System.Drawing.Size(46, 22);
            this.linkLabel17.TabIndex = 1043;
            this.linkLabel17.TabStop = true;
            this.linkLabel17.Text = "未打印";
            this.linkLabel17.Click += new System.EventHandler(this.linkLabel16_Click);
            // 
            // flowLayoutPanel6
            // 
            this.flowLayoutPanel6.Controls.Add(this.label29);
            this.flowLayoutPanel6.Controls.Add(this.checkBox4);
            this.flowLayoutPanel6.Controls.Add(this.linkLabel13);
            this.flowLayoutPanel6.Controls.Add(this.linkLabel15);
            this.flowLayoutPanel6.Controls.Add(this.linkLabel14);
            this.flowLayoutPanel6.Location = new System.Drawing.Point(283, 5);
            this.flowLayoutPanel6.Name = "flowLayoutPanel6";
            this.flowLayoutPanel6.Size = new System.Drawing.Size(320, 21);
            this.flowLayoutPanel6.TabIndex = 1051;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(180)))), ((int)(((byte)(43)))));
            this.label29.Location = new System.Drawing.Point(3, 2);
            this.label29.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.label29.Name = "label29";
            this.label29.Padding = new System.Windows.Forms.Padding(5, 5, 0, 5);
            this.label29.Size = new System.Drawing.Size(70, 22);
            this.label29.TabIndex = 1041;
            this.label29.Text = "     瓶签:";
            // 
            // checkBox4
            // 
            this.checkBox4.Checked = true;
            this.checkBox4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox4.Enabled = false;
            this.checkBox4.Location = new System.Drawing.Point(79, 5);
            this.checkBox4.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(72, 16);
            this.checkBox4.TabIndex = 1038;
            this.checkBox4.Text = "仅此状态";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.Visible = false;
            // 
            // linkLabel13
            // 
            this.linkLabel13.AutoSize = true;
            this.linkLabel13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel13.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel13.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel13.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel13.Location = new System.Drawing.Point(157, 2);
            this.linkLabel13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel13.Name = "linkLabel13";
            this.linkLabel13.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel13.Size = new System.Drawing.Size(46, 22);
            this.linkLabel13.TabIndex = 1044;
            this.linkLabel13.TabStop = true;
            this.linkLabel13.Text = "<全部>";
            this.linkLabel13.Click += new System.EventHandler(this.linkLabel13_Click);
            // 
            // linkLabel15
            // 
            this.linkLabel15.AutoSize = true;
            this.linkLabel15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel15.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel15.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel15.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel15.Location = new System.Drawing.Point(209, 2);
            this.linkLabel15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel15.Name = "linkLabel15";
            this.linkLabel15.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel15.Size = new System.Drawing.Size(46, 22);
            this.linkLabel15.TabIndex = 1042;
            this.linkLabel15.TabStop = true;
            this.linkLabel15.Text = "已打印";
            this.linkLabel15.Click += new System.EventHandler(this.linkLabel13_Click);
            // 
            // linkLabel14
            // 
            this.linkLabel14.AutoSize = true;
            this.linkLabel14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel14.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel14.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel14.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel14.Location = new System.Drawing.Point(261, 2);
            this.linkLabel14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel14.Name = "linkLabel14";
            this.linkLabel14.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel14.Size = new System.Drawing.Size(46, 22);
            this.linkLabel14.TabIndex = 1043;
            this.linkLabel14.TabStop = true;
            this.linkLabel14.Text = "未打印";
            this.linkLabel14.Click += new System.EventHandler(this.linkLabel13_Click);
            // 
            // flowLayoutPanel11
            // 
            this.flowLayoutPanel11.Controls.Add(this.label43);
            this.flowLayoutPanel11.Controls.Add(this.linkLabel29);
            this.flowLayoutPanel11.Controls.Add(this.linkLabel30);
            this.flowLayoutPanel11.Controls.Add(this.linkLabel34);
            this.flowLayoutPanel11.Controls.Add(this.checkBox10);
            this.flowLayoutPanel11.Controls.Add(this.panel10);
            this.flowLayoutPanel11.Location = new System.Drawing.Point(609, 5);
            this.flowLayoutPanel11.Name = "flowLayoutPanel11";
            this.flowLayoutPanel11.Size = new System.Drawing.Size(411, 24);
            this.flowLayoutPanel11.TabIndex = 1054;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(180)))), ((int)(((byte)(43)))));
            this.label43.Location = new System.Drawing.Point(3, 2);
            this.label43.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.label43.Name = "label43";
            this.label43.Padding = new System.Windows.Forms.Padding(5, 5, 0, 5);
            this.label43.Size = new System.Drawing.Size(52, 22);
            this.label43.TabIndex = 1042;
            this.label43.Text = "配置费:";
            // 
            // linkLabel29
            // 
            this.linkLabel29.AutoSize = true;
            this.linkLabel29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel29.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel29.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel29.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel29.Location = new System.Drawing.Point(61, 2);
            this.linkLabel29.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel29.Name = "linkLabel29";
            this.linkLabel29.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel29.Size = new System.Drawing.Size(46, 22);
            this.linkLabel29.TabIndex = 1047;
            this.linkLabel29.TabStop = true;
            this.linkLabel29.Text = "<全部>";
            this.linkLabel29.Click += new System.EventHandler(this.linkLabel29_Click);
            // 
            // linkLabel30
            // 
            this.linkLabel30.AutoSize = true;
            this.linkLabel30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel30.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel30.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel30.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel30.Location = new System.Drawing.Point(113, 2);
            this.linkLabel30.Margin = new System.Windows.Forms.Padding(3, 2, 0, 0);
            this.linkLabel30.Name = "linkLabel30";
            this.linkLabel30.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel30.Size = new System.Drawing.Size(46, 22);
            this.linkLabel30.TabIndex = 1045;
            this.linkLabel30.TabStop = true;
            this.linkLabel30.Text = "已计费";
            this.linkLabel30.Click += new System.EventHandler(this.linkLabel30_Click);
            // 
            // linkLabel34
            // 
            this.linkLabel34.AutoSize = true;
            this.linkLabel34.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel34.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel34.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel34.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel34.Location = new System.Drawing.Point(162, 2);
            this.linkLabel34.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel34.Name = "linkLabel34";
            this.linkLabel34.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel34.Size = new System.Drawing.Size(46, 22);
            this.linkLabel34.TabIndex = 1046;
            this.linkLabel34.TabStop = true;
            this.linkLabel34.Text = "未计费";
            this.linkLabel34.Click += new System.EventHandler(this.linkLabel34_Click);
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Checked = true;
            this.checkBox10.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(180)))), ((int)(((byte)(43)))));
            this.checkBox10.Location = new System.Drawing.Point(214, 3);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.checkBox10.Size = new System.Drawing.Size(60, 19);
            this.checkBox10.TabIndex = 1050;
            this.checkBox10.Text = "不计费";
            this.checkBox10.UseVisualStyleBackColor = true;
            this.checkBox10.Visible = false;
            this.checkBox10.Click += new System.EventHandler(this.checkBox10_Click);
            // 
            // panel10
            // 
            this.panel10.Location = new System.Drawing.Point(280, 1);
            this.panel10.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(127, 22);
            this.panel10.TabIndex = 1051;
            this.panel10.Visible = false;
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.flowLayoutPanel5.BackColor = System.Drawing.Color.White;
            this.flowLayoutPanel5.Controls.Add(this.label30);
            this.flowLayoutPanel5.Controls.Add(this.checkBox5);
            this.flowLayoutPanel5.Controls.Add(this.linkLabel31);
            this.flowLayoutPanel5.Controls.Add(this.linkLabel20);
            this.flowLayoutPanel5.Controls.Add(this.linkLabel19);
            this.flowLayoutPanel5.Controls.Add(this.label36);
            this.flowLayoutPanel5.Controls.Add(this.panel7);
            this.flowLayoutPanel5.Location = new System.Drawing.Point(7, 103);
            this.flowLayoutPanel5.Margin = new System.Windows.Forms.Padding(7, 3, 10, 0);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.flowLayoutPanel5.Size = new System.Drawing.Size(1023, 28);
            this.flowLayoutPanel5.TabIndex = 9;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(180)))), ((int)(((byte)(43)))));
            this.label30.Location = new System.Drawing.Point(3, 4);
            this.label30.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.label30.Name = "label30";
            this.label30.Padding = new System.Windows.Forms.Padding(5, 5, 0, 5);
            this.label30.Size = new System.Drawing.Size(64, 22);
            this.label30.TabIndex = 1031;
            this.label30.Text = "空包筛选:";
            this.toolTip1.SetToolTip(this.label30, "是否空包筛选");
            // 
            // checkBox5
            // 
            this.checkBox5.Checked = true;
            this.checkBox5.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox5.Enabled = false;
            this.checkBox5.Location = new System.Drawing.Point(73, 7);
            this.checkBox5.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(72, 16);
            this.checkBox5.TabIndex = 1038;
            this.checkBox5.Text = "仅此状态";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.Visible = false;
            // 
            // linkLabel31
            // 
            this.linkLabel31.AutoSize = true;
            this.linkLabel31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel31.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel31.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel31.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel31.Location = new System.Drawing.Point(151, 4);
            this.linkLabel31.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel31.Name = "linkLabel31";
            this.linkLabel31.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel31.Size = new System.Drawing.Size(46, 22);
            this.linkLabel31.TabIndex = 1039;
            this.linkLabel31.TabStop = true;
            this.linkLabel31.Tag = "";
            this.linkLabel31.Text = "<全部>";
            this.linkLabel31.Click += new System.EventHandler(this.linkLabel31_Click);
            // 
            // linkLabel20
            // 
            this.linkLabel20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel20.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel20.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel20.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel20.Location = new System.Drawing.Point(203, 4);
            this.linkLabel20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel20.Name = "linkLabel20";
            this.linkLabel20.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel20.Size = new System.Drawing.Size(22, 22);
            this.linkLabel20.TabIndex = 1044;
            this.linkLabel20.TabStop = true;
            this.linkLabel20.Tag = "";
            this.linkLabel20.Text = "#";
            this.linkLabel20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.linkLabel20.Click += new System.EventHandler(this.linkLabel31_Click);
            // 
            // linkLabel19
            // 
            this.linkLabel19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel19.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel19.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel19.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel19.Location = new System.Drawing.Point(231, 4);
            this.linkLabel19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel19.Name = "linkLabel19";
            this.linkLabel19.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel19.Size = new System.Drawing.Size(30, 22);
            this.linkLabel19.TabIndex = 1043;
            this.linkLabel19.TabStop = true;
            this.linkLabel19.Tag = "";
            this.linkLabel19.Text = "K";
            this.linkLabel19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.linkLabel19.Click += new System.EventHandler(this.linkLabel31_Click);
            // 
            // label36
            // 
            this.label36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(180)))), ((int)(((byte)(43)))));
            this.label36.Location = new System.Drawing.Point(267, 4);
            this.label36.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.label36.Name = "label36";
            this.label36.Padding = new System.Windows.Forms.Padding(5, 5, 0, 5);
            this.label36.Size = new System.Drawing.Size(114, 22);
            this.label36.TabIndex = 1048;
            this.label36.Text = "药品筛选:";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolTip1.SetToolTip(this.label36, "药品筛选   您可以选择查看 普抗化营 中的一种或几种瓶签");
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.linkLabel35);
            this.panel7.Controls.Add(this.linkLabel27);
            this.panel7.Controls.Add(this.linkLabel26);
            this.panel7.Controls.Add(this.linkLabel25);
            this.panel7.Controls.Add(this.linkLabel24);
            this.panel7.Location = new System.Drawing.Point(387, 5);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(240, 28);
            this.panel7.TabIndex = 1051;
            // 
            // linkLabel35
            // 
            this.linkLabel35.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel35.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel35.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.linkLabel35.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel35.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel35.Location = new System.Drawing.Point(117, -1);
            this.linkLabel35.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel35.Name = "linkLabel35";
            this.linkLabel35.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel35.Size = new System.Drawing.Size(24, 26);
            this.linkLabel35.TabIndex = 1048;
            this.linkLabel35.TabStop = true;
            this.linkLabel35.Tag = "4";
            this.linkLabel35.Text = "中";
            this.linkLabel35.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.linkLabel35.Click += new System.EventHandler(this.linkLabel35_Click);
            // 
            // linkLabel27
            // 
            this.linkLabel27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel27.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel27.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.linkLabel27.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel27.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel27.Location = new System.Drawing.Point(86, -1);
            this.linkLabel27.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel27.Name = "linkLabel27";
            this.linkLabel27.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel27.Size = new System.Drawing.Size(25, 29);
            this.linkLabel27.TabIndex = 1047;
            this.linkLabel27.TabStop = true;
            this.linkLabel27.Tag = "4";
            this.linkLabel27.Text = "营";
            this.linkLabel27.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.linkLabel27.Click += new System.EventHandler(this.linkLabel24_Click);
            // 
            // linkLabel26
            // 
            this.linkLabel26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel26.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel26.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.linkLabel26.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel26.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel26.Location = new System.Drawing.Point(58, -1);
            this.linkLabel26.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel26.Name = "linkLabel26";
            this.linkLabel26.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel26.Size = new System.Drawing.Size(25, 29);
            this.linkLabel26.TabIndex = 1046;
            this.linkLabel26.TabStop = true;
            this.linkLabel26.Tag = "3";
            this.linkLabel26.Text = "化";
            this.linkLabel26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.linkLabel26.Click += new System.EventHandler(this.linkLabel24_Click);
            // 
            // linkLabel25
            // 
            this.linkLabel25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel25.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel25.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.linkLabel25.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel25.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel25.Location = new System.Drawing.Point(30, -1);
            this.linkLabel25.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel25.Name = "linkLabel25";
            this.linkLabel25.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel25.Size = new System.Drawing.Size(25, 29);
            this.linkLabel25.TabIndex = 1045;
            this.linkLabel25.TabStop = true;
            this.linkLabel25.Tag = "2";
            this.linkLabel25.Text = "抗";
            this.linkLabel25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.linkLabel25.Click += new System.EventHandler(this.linkLabel24_Click);
            // 
            // linkLabel24
            // 
            this.linkLabel24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel24.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel24.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.linkLabel24.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel24.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel24.Location = new System.Drawing.Point(2, -1);
            this.linkLabel24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel24.Name = "linkLabel24";
            this.linkLabel24.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel24.Size = new System.Drawing.Size(25, 29);
            this.linkLabel24.TabIndex = 1044;
            this.linkLabel24.TabStop = true;
            this.linkLabel24.Tag = "1";
            this.linkLabel24.Text = "普";
            this.linkLabel24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.linkLabel24.Click += new System.EventHandler(this.linkLabel24_Click);
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.BackColor = System.Drawing.Color.White;
            this.flowLayoutPanel4.Controls.Add(this.label31);
            this.flowLayoutPanel4.Controls.Add(this.checkBox6);
            this.flowLayoutPanel4.Controls.Add(this.flowLayoutPanel10);
            this.flowLayoutPanel4.Controls.Add(this.label37);
            this.flowLayoutPanel4.Controls.Add(this.flowLayoutPanel9);
            this.flowLayoutPanel4.Location = new System.Drawing.Point(7, 69);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(7, 3, 10, 0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.flowLayoutPanel4.Size = new System.Drawing.Size(1020, 31);
            this.flowLayoutPanel4.TabIndex = 8;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(180)))), ((int)(((byte)(43)))));
            this.label31.Location = new System.Drawing.Point(3, 4);
            this.label31.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.label31.Name = "label31";
            this.label31.Padding = new System.Windows.Forms.Padding(5, 5, 0, 5);
            this.label31.Size = new System.Drawing.Size(70, 22);
            this.label31.TabIndex = 1029;
            this.label31.Text = "长临/临时:";
            this.toolTip1.SetToolTip(this.label31, "长期临时筛选");
            // 
            // checkBox6
            // 
            this.checkBox6.Checked = true;
            this.checkBox6.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox6.Enabled = false;
            this.checkBox6.Location = new System.Drawing.Point(79, 7);
            this.checkBox6.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(72, 16);
            this.checkBox6.TabIndex = 1038;
            this.checkBox6.Text = "仅此状态";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.Visible = false;
            // 
            // flowLayoutPanel10
            // 
            this.flowLayoutPanel10.Controls.Add(this.linkLabel33);
            this.flowLayoutPanel10.Controls.Add(this.linkLabel23);
            this.flowLayoutPanel10.Controls.Add(this.linkLabel21);
            this.flowLayoutPanel10.Location = new System.Drawing.Point(154, 2);
            this.flowLayoutPanel10.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel10.Name = "flowLayoutPanel10";
            this.flowLayoutPanel10.Size = new System.Drawing.Size(162, 23);
            this.flowLayoutPanel10.TabIndex = 1042;
            // 
            // linkLabel33
            // 
            this.linkLabel33.AutoSize = true;
            this.linkLabel33.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel33.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel33.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel33.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel33.Location = new System.Drawing.Point(3, 2);
            this.linkLabel33.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel33.Name = "linkLabel33";
            this.linkLabel33.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel33.Size = new System.Drawing.Size(46, 22);
            this.linkLabel33.TabIndex = 1039;
            this.linkLabel33.TabStop = true;
            this.linkLabel33.Text = "<全部>";
            this.linkLabel33.Click += new System.EventHandler(this.linkLabel21_Click);
            // 
            // linkLabel23
            // 
            this.linkLabel23.AutoSize = true;
            this.linkLabel23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel23.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel23.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel23.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel23.Location = new System.Drawing.Point(55, 2);
            this.linkLabel23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel23.Name = "linkLabel23";
            this.linkLabel23.Padding = new System.Windows.Forms.Padding(0, 5, 0, 5);
            this.linkLabel23.Size = new System.Drawing.Size(41, 22);
            this.linkLabel23.TabIndex = 1040;
            this.linkLabel23.TabStop = true;
            this.linkLabel23.Text = "<长期>";
            this.linkLabel23.Click += new System.EventHandler(this.linkLabel21_Click);
            // 
            // linkLabel21
            // 
            this.linkLabel21.AutoSize = true;
            this.linkLabel21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel21.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel21.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel21.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel21.Location = new System.Drawing.Point(102, 2);
            this.linkLabel21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel21.Name = "linkLabel21";
            this.linkLabel21.Padding = new System.Windows.Forms.Padding(0, 5, 0, 5);
            this.linkLabel21.Size = new System.Drawing.Size(41, 22);
            this.linkLabel21.TabIndex = 1039;
            this.linkLabel21.TabStop = true;
            this.linkLabel21.Text = "<临时>";
            this.linkLabel21.Click += new System.EventHandler(this.linkLabel21_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(180)))), ((int)(((byte)(43)))));
            this.label37.Location = new System.Drawing.Point(319, 4);
            this.label37.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.label37.Name = "label37";
            this.label37.Padding = new System.Windows.Forms.Padding(5, 5, 0, 5);
            this.label37.Size = new System.Drawing.Size(40, 22);
            this.label37.TabIndex = 1043;
            this.label37.Text = "批次:";
            this.toolTip1.SetToolTip(this.label37, "批次筛选   您可以勾选你想查看的制定批次");
            // 
            // flowLayoutPanel9
            // 
            this.flowLayoutPanel9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel9.Location = new System.Drawing.Point(362, 2);
            this.flowLayoutPanel9.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel9.Name = "flowLayoutPanel9";
            this.flowLayoutPanel9.Size = new System.Drawing.Size(321, 23);
            this.flowLayoutPanel9.TabIndex = 1041;
            this.toolTip1.SetToolTip(this.flowLayoutPanel9, "批次选择");
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.BackColor = System.Drawing.Color.White;
            this.flowLayoutPanel3.Controls.Add(this.label32);
            this.flowLayoutPanel3.Controls.Add(this.checkBox1);
            this.flowLayoutPanel3.Controls.Add(this.checkBox9);
            this.flowLayoutPanel3.Controls.Add(this.linkLabel1);
            this.flowLayoutPanel3.Controls.Add(this.linkLabel2);
            this.flowLayoutPanel3.Controls.Add(this.linkLabel3);
            this.flowLayoutPanel3.Controls.Add(this.linkLabel28);
            this.flowLayoutPanel3.Controls.Add(this.panel8);
            this.flowLayoutPanel3.Controls.Add(this.linkLabel4);
            this.flowLayoutPanel3.Controls.Add(this.linkLabel5);
            this.flowLayoutPanel3.Controls.Add(this.linkLabel6);
            this.flowLayoutPanel3.Controls.Add(this.linkLabel7);
            this.flowLayoutPanel3.Controls.Add(this.linkLabel8);
            this.flowLayoutPanel3.Controls.Add(this.linkLabel9);
            this.flowLayoutPanel3.Controls.Add(this.linkLabel10);
            this.flowLayoutPanel3.Controls.Add(this.linkLabel11);
            this.flowLayoutPanel3.Controls.Add(this.checkBox8);
            this.flowLayoutPanel3.Controls.Add(this.linkLabel12);
            this.flowLayoutPanel3.Location = new System.Drawing.Point(7, 38);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(7, 3, 10, 0);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.flowLayoutPanel3.Size = new System.Drawing.Size(1023, 28);
            this.flowLayoutPanel3.TabIndex = 7;
            this.toolTip1.SetToolTip(this.flowLayoutPanel3, "瓶签状态筛选");
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(180)))), ((int)(((byte)(43)))));
            this.label32.Location = new System.Drawing.Point(3, 4);
            this.label32.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.label32.Name = "label32";
            this.label32.Padding = new System.Windows.Forms.Padding(5, 5, 0, 5);
            this.label32.Size = new System.Drawing.Size(40, 22);
            this.label32.TabIndex = 1033;
            this.label32.Text = "状态:";
            // 
            // checkBox1
            // 
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(49, 7);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(72, 16);
            this.checkBox1.TabIndex = 1038;
            this.checkBox1.Text = "仅此状态";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox9
            // 
            this.checkBox9.Location = new System.Drawing.Point(127, 5);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(104, 21);
            this.checkBox9.TabIndex = 1052;
            this.checkBox9.Text = "包含配置取消";
            this.checkBox9.UseVisualStyleBackColor = true;
            this.checkBox9.Visible = false;
            this.checkBox9.CheckedChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
            this.checkBox9.Click += new System.EventHandler(this.checkBox9_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel1.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel1.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel1.Location = new System.Drawing.Point(237, 4);
            this.linkLabel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Padding = new System.Windows.Forms.Padding(0, 5, 5, 0);
            this.linkLabel1.Size = new System.Drawing.Size(46, 17);
            this.linkLabel1.TabIndex = 1039;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "<全部>";
            this.linkLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.linkLabel1.Click += new System.EventHandler(this.linkLabel1_Click);
            // 
            // linkLabel2
            // 
            this.linkLabel2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel2.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel2.ForeColor = System.Drawing.Color.Transparent;
            this.linkLabel2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel2.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel2.Location = new System.Drawing.Point(289, 4);
            this.linkLabel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Padding = new System.Windows.Forms.Padding(0, 5, 5, 0);
            this.linkLabel2.Size = new System.Drawing.Size(56, 18);
            this.linkLabel2.TabIndex = 1039;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "未打印";
            this.linkLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkLabel2.Click += new System.EventHandler(this.linkLabel1_Click);
            // 
            // linkLabel3
            // 
            this.linkLabel3.BackColor = System.Drawing.Color.White;
            this.linkLabel3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel3.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel3.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel3.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel3.Location = new System.Drawing.Point(351, 4);
            this.linkLabel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Padding = new System.Windows.Forms.Padding(0, 5, 5, 0);
            this.linkLabel3.Size = new System.Drawing.Size(46, 17);
            this.linkLabel3.TabIndex = 1039;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "已打印";
            this.linkLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.linkLabel3.Click += new System.EventHandler(this.linkLabel1_Click);
            // 
            // linkLabel28
            // 
            this.linkLabel28.AutoSize = true;
            this.linkLabel28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel28.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel28.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel28.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel28.Location = new System.Drawing.Point(403, 4);
            this.linkLabel28.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel28.Name = "linkLabel28";
            this.linkLabel28.Padding = new System.Windows.Forms.Padding(0, 5, 5, 0);
            this.linkLabel28.Size = new System.Drawing.Size(46, 17);
            this.linkLabel28.TabIndex = 1040;
            this.linkLabel28.TabStop = true;
            this.linkLabel28.Text = "已摆药";
            this.linkLabel28.Click += new System.EventHandler(this.linkLabel1_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.cb_ys);
            this.panel8.Controls.Add(this.cb_yp);
            this.panel8.Controls.Add(this.label39);
            this.panel8.Controls.Add(this.label38);
            this.panel8.Location = new System.Drawing.Point(455, 5);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(133, 19);
            this.panel8.TabIndex = 1051;
            this.panel8.Visible = false;
            // 
            // cb_ys
            // 
            this.cb_ys.AutoSize = true;
            this.cb_ys.Checked = true;
            this.cb_ys.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_ys.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(180)))), ((int)(((byte)(43)))));
            this.cb_ys.Location = new System.Drawing.Point(68, 1);
            this.cb_ys.Name = "cb_ys";
            this.cb_ys.Size = new System.Drawing.Size(48, 16);
            this.cb_ys.TabIndex = 3;
            this.cb_ys.Text = "溶媒";
            this.cb_ys.UseVisualStyleBackColor = true;
            this.cb_ys.CheckedChanged += new System.EventHandler(this.cb_ys_CheckedChanged);
            // 
            // cb_yp
            // 
            this.cb_yp.AutoSize = true;
            this.cb_yp.Checked = true;
            this.cb_yp.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_yp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(180)))), ((int)(((byte)(43)))));
            this.cb_yp.Location = new System.Drawing.Point(20, 1);
            this.cb_yp.Name = "cb_yp";
            this.cb_yp.Size = new System.Drawing.Size(48, 16);
            this.cb_yp.TabIndex = 2;
            this.cb_yp.Text = "药品";
            this.cb_yp.UseVisualStyleBackColor = true;
            this.cb_yp.CheckedChanged += new System.EventHandler(this.cb_yp_CheckedChanged);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label39.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label39.Location = new System.Drawing.Point(2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(16, 16);
            this.label39.TabIndex = 1;
            this.label39.Text = "(";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label38.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label38.Location = new System.Drawing.Point(113, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(16, 16);
            this.label38.TabIndex = 0;
            this.label38.Text = ")";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // linkLabel4
            // 
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel4.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel4.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel4.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel4.Location = new System.Drawing.Point(594, 4);
            this.linkLabel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Padding = new System.Windows.Forms.Padding(0, 5, 5, 0);
            this.linkLabel4.Size = new System.Drawing.Size(46, 17);
            this.linkLabel4.TabIndex = 1039;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "已排药";
            this.linkLabel4.Click += new System.EventHandler(this.linkLabel1_Click);
            // 
            // linkLabel5
            // 
            this.linkLabel5.AutoSize = true;
            this.linkLabel5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel5.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel5.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel5.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel5.Location = new System.Drawing.Point(646, 4);
            this.linkLabel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Padding = new System.Windows.Forms.Padding(0, 5, 5, 0);
            this.linkLabel5.Size = new System.Drawing.Size(46, 17);
            this.linkLabel5.TabIndex = 1039;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Text = "已进仓";
            this.linkLabel5.Click += new System.EventHandler(this.linkLabel1_Click);
            // 
            // linkLabel6
            // 
            this.linkLabel6.AutoSize = true;
            this.linkLabel6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel6.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel6.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel6.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel6.Location = new System.Drawing.Point(698, 4);
            this.linkLabel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Padding = new System.Windows.Forms.Padding(0, 5, 5, 0);
            this.linkLabel6.Size = new System.Drawing.Size(46, 17);
            this.linkLabel6.TabIndex = 1039;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Text = "已配置";
            this.linkLabel6.Click += new System.EventHandler(this.linkLabel1_Click);
            // 
            // linkLabel7
            // 
            this.linkLabel7.AutoSize = true;
            this.linkLabel7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel7.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel7.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel7.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel7.Location = new System.Drawing.Point(750, 4);
            this.linkLabel7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel7.Name = "linkLabel7";
            this.linkLabel7.Padding = new System.Windows.Forms.Padding(0, 5, 5, 0);
            this.linkLabel7.Size = new System.Drawing.Size(46, 17);
            this.linkLabel7.TabIndex = 1039;
            this.linkLabel7.TabStop = true;
            this.linkLabel7.Text = "已出仓";
            this.linkLabel7.Click += new System.EventHandler(this.linkLabel1_Click);
            // 
            // linkLabel8
            // 
            this.linkLabel8.AutoSize = true;
            this.linkLabel8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel8.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel8.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel8.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel8.Location = new System.Drawing.Point(802, 4);
            this.linkLabel8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel8.Name = "linkLabel8";
            this.linkLabel8.Padding = new System.Windows.Forms.Padding(0, 5, 5, 0);
            this.linkLabel8.Size = new System.Drawing.Size(46, 17);
            this.linkLabel8.TabIndex = 1039;
            this.linkLabel8.TabStop = true;
            this.linkLabel8.Text = "已打包";
            this.linkLabel8.Click += new System.EventHandler(this.linkLabel1_Click);
            // 
            // linkLabel9
            // 
            this.linkLabel9.AutoSize = true;
            this.linkLabel9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel9.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel9.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel9.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel9.Location = new System.Drawing.Point(854, 4);
            this.linkLabel9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel9.Name = "linkLabel9";
            this.linkLabel9.Padding = new System.Windows.Forms.Padding(0, 5, 5, 0);
            this.linkLabel9.Size = new System.Drawing.Size(46, 17);
            this.linkLabel9.TabIndex = 1039;
            this.linkLabel9.TabStop = true;
            this.linkLabel9.Text = "已退药";
            this.linkLabel9.Click += new System.EventHandler(this.linkLabel1_Click);
            // 
            // linkLabel10
            // 
            this.linkLabel10.AutoSize = true;
            this.linkLabel10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel10.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel10.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel10.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel10.Location = new System.Drawing.Point(906, 4);
            this.linkLabel10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel10.Name = "linkLabel10";
            this.linkLabel10.Padding = new System.Windows.Forms.Padding(0, 5, 5, 0);
            this.linkLabel10.Size = new System.Drawing.Size(46, 17);
            this.linkLabel10.TabIndex = 1039;
            this.linkLabel10.TabStop = true;
            this.linkLabel10.Text = "已签收";
            this.linkLabel10.Click += new System.EventHandler(this.linkLabel1_Click);
            // 
            // linkLabel11
            // 
            this.linkLabel11.AutoSize = true;
            this.linkLabel11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel11.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel11.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel11.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel11.Location = new System.Drawing.Point(958, 4);
            this.linkLabel11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel11.Name = "linkLabel11";
            this.linkLabel11.Padding = new System.Windows.Forms.Padding(0, 5, 5, 0);
            this.linkLabel11.Size = new System.Drawing.Size(58, 17);
            this.linkLabel11.TabIndex = 1039;
            this.linkLabel11.TabStop = true;
            this.linkLabel11.Text = "配置取消";
            this.linkLabel11.Click += new System.EventHandler(this.linkLabel1_Click);
            // 
            // checkBox8
            // 
            this.checkBox8.Checked = true;
            this.checkBox8.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(180)))), ((int)(((byte)(43)))));
            this.checkBox8.Location = new System.Drawing.Point(3, 32);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(50, 20);
            this.checkBox8.TabIndex = 0;
            this.checkBox8.Text = "计费";
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.Visible = false;
            this.checkBox8.CheckedChanged += new System.EventHandler(this.checkBox8_CheckedChanged);
            // 
            // linkLabel12
            // 
            this.linkLabel12.AutoSize = true;
            this.linkLabel12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel12.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel12.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel12.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel12.Location = new System.Drawing.Point(59, 31);
            this.linkLabel12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel12.Name = "linkLabel12";
            this.linkLabel12.Padding = new System.Windows.Forms.Padding(0, 5, 5, 0);
            this.linkLabel12.Size = new System.Drawing.Size(58, 17);
            this.linkLabel12.TabIndex = 1039;
            this.linkLabel12.TabStop = true;
            this.linkLabel12.Text = "提前打包";
            this.linkLabel12.Click += new System.EventHandler(this.linkLabel1_Click);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.flowLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.flowLayoutPanel2.Controls.Add(this.flowLayoutPanel8);
            this.flowLayoutPanel2.Controls.Add(this.flowLayoutPanel3);
            this.flowLayoutPanel2.Controls.Add(this.flowLayoutPanel4);
            this.flowLayoutPanel2.Controls.Add(this.flowLayoutPanel5);
            this.flowLayoutPanel2.Controls.Add(this.flowLayoutPanel7);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(196, 36);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(1031, 166);
            this.flowLayoutPanel2.TabIndex = 1016;
            // 
            // flowLayoutPanel8
            // 
            this.flowLayoutPanel8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel8.BackColor = System.Drawing.Color.Transparent;
            this.flowLayoutPanel8.BackgroundImage = global::PivasLabelSelect.Properties.Resources._15;
            this.flowLayoutPanel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.flowLayoutPanel8.Controls.Add(this.dateTimePicker1);
            this.flowLayoutPanel8.Controls.Add(this.cb_hour1);
            this.flowLayoutPanel8.Controls.Add(this.label40);
            this.flowLayoutPanel8.Controls.Add(this.cb_hour2);
            this.flowLayoutPanel8.Controls.Add(this.textBox1);
            this.flowLayoutPanel8.Controls.Add(this.comboBox5);
            this.flowLayoutPanel8.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel8.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel8.Name = "flowLayoutPanel8";
            this.flowLayoutPanel8.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.flowLayoutPanel8.Size = new System.Drawing.Size(1031, 35);
            this.flowLayoutPanel8.TabIndex = 6;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(12, 6);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(9, 6, 3, 3);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(115, 21);
            this.dateTimePicker1.TabIndex = 1028;
            this.toolTip1.SetToolTip(this.dateTimePicker1, "瓶签时间");
            this.dateTimePicker1.CloseUp += new System.EventHandler(this.dateTimePicker1_CloseUp);
            // 
            // cb_hour1
            // 
            this.cb_hour1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_hour1.FormattingEnabled = true;
            this.cb_hour1.Items.AddRange(new object[] {
            "",
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24"});
            this.cb_hour1.Location = new System.Drawing.Point(134, 7);
            this.cb_hour1.Margin = new System.Windows.Forms.Padding(4, 7, 3, 3);
            this.cb_hour1.Name = "cb_hour1";
            this.cb_hour1.Size = new System.Drawing.Size(40, 20);
            this.cb_hour1.TabIndex = 1031;
            this.cb_hour1.SelectionChangeCommitted += new System.EventHandler(this.cb_hour1_SelectionChangeCommitted);
            // 
            // label40
            // 
            this.label40.Location = new System.Drawing.Point(177, 6);
            this.label40.Margin = new System.Windows.Forms.Padding(0, 6, 0, 3);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(12, 23);
            this.label40.TabIndex = 1032;
            this.label40.Text = "～";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cb_hour2
            // 
            this.cb_hour2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_hour2.FormattingEnabled = true;
            this.cb_hour2.Items.AddRange(new object[] {
            "",
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24"});
            this.cb_hour2.Location = new System.Drawing.Point(189, 7);
            this.cb_hour2.Margin = new System.Windows.Forms.Padding(0, 7, 3, 3);
            this.cb_hour2.Name = "cb_hour2";
            this.cb_hour2.Size = new System.Drawing.Size(40, 20);
            this.cb_hour2.TabIndex = 1033;
            this.cb_hour2.SelectionChangeCommitted += new System.EventHandler(this.cb_hour2_SelectionChangeCommitted);
            // 
            // textBox1
            // 
            this.textBox1.ForeColor = System.Drawing.Color.Silver;
            this.textBox1.Location = new System.Drawing.Point(236, 6);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 6, 3, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(313, 21);
            this.textBox1.TabIndex = 1029;
            this.textBox1.Text = "瓶签号/患者姓名/患者ID/床号/主药/溶媒/医嘱号";
            this.toolTip1.SetToolTip(this.textBox1, "模糊查询");
            this.textBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox1_MouseClick);
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            this.textBox1.Leave += new System.EventHandler(this.textBox1_Leave);
            this.textBox1.MouseLeave += new System.EventHandler(this.textBox1_MouseLeave);
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(555, 3);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(111, 20);
            this.comboBox5.TabIndex = 1030;
            this.comboBox5.Visible = false;
            this.comboBox5.TextChanged += new System.EventHandler(this.Combox5_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Teal;
            this.label18.Location = new System.Drawing.Point(120, 17);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 1015;
            this.label18.Text = "工号";
            this.toolTip1.SetToolTip(this.label18, "当前登录的员工号");
            // 
            // Pic_Max
            // 
            this.Pic_Max.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Pic_Max.BackColor = System.Drawing.Color.Transparent;
            this.Pic_Max.BackgroundImage = global::PivasLabelSelect.Properties.Resources._2;
            this.Pic_Max.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Pic_Max.Location = new System.Drawing.Point(1184, 0);
            this.Pic_Max.Name = "Pic_Max";
            this.Pic_Max.Size = new System.Drawing.Size(22, 25);
            this.Pic_Max.TabIndex = 1013;
            this.toolTip1.SetToolTip(this.Pic_Max, "改变窗体大小");
            this.Pic_Max.Click += new System.EventHandler(this.Pic_Max_Click);
            this.Pic_Max.MouseLeave += new System.EventHandler(this.Pic_Max_MouseLeave);
            this.Pic_Max.MouseHover += new System.EventHandler(this.Pic_Max_MouseHover);
            // 
            // Pic_Min
            // 
            this.Pic_Min.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Pic_Min.BackColor = System.Drawing.Color.Transparent;
            this.Pic_Min.BackgroundImage = global::PivasLabelSelect.Properties.Resources._1;
            this.Pic_Min.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Pic_Min.Location = new System.Drawing.Point(1163, 0);
            this.Pic_Min.Name = "Pic_Min";
            this.Pic_Min.Size = new System.Drawing.Size(21, 25);
            this.Pic_Min.TabIndex = 1012;
            this.toolTip1.SetToolTip(this.Pic_Min, "最小化");
            this.Pic_Min.Click += new System.EventHandler(this.Pic_Min_Click);
            this.Pic_Min.MouseLeave += new System.EventHandler(this.Pic_Min_MouseLeave);
            this.Pic_Min.MouseHover += new System.EventHandler(this.Pic_Min_MouseHover);
            // 
            // Panel_Close
            // 
            this.Panel_Close.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Panel_Close.BackColor = System.Drawing.Color.Transparent;
            this.Panel_Close.BackgroundImage = global::PivasLabelSelect.Properties.Resources._4;
            this.Panel_Close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Panel_Close.Location = new System.Drawing.Point(1206, 0);
            this.Panel_Close.Name = "Panel_Close";
            this.Panel_Close.Size = new System.Drawing.Size(21, 25);
            this.Panel_Close.TabIndex = 1011;
            this.toolTip1.SetToolTip(this.Panel_Close, "关闭画面");
            this.Panel_Close.Click += new System.EventHandler(this.Panel_Close_Click);
            this.Panel_Close.MouseLeave += new System.EventHandler(this.Panel_Close_MouseLeave);
            this.Panel_Close.MouseHover += new System.EventHandler(this.Panel_Close_MouseHover);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = global::PivasLabelSelect.Properties.Resources._14;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.label33);
            this.panel1.Controls.Add(this.cbbList);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.linkLabel22);
            this.panel1.Controls.Add(this.linkLabel32);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.Pic_Max);
            this.panel1.Controls.Add(this.Pic_Min);
            this.panel1.Controls.Add(this.cbbPrinted);
            this.panel1.Controls.Add(this.Panel_Close);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1228, 36);
            this.panel1.TabIndex = 1012;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "",
            "K",
            "#"});
            this.comboBox2.Location = new System.Drawing.Point(733, 2);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(95, 20);
            this.comboBox2.TabIndex = 1032;
            this.comboBox2.Visible = false;
            this.comboBox2.TextChanged += new System.EventHandler(this.comboBox2_TextChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "",
            "<临时>"});
            this.comboBox1.Location = new System.Drawing.Point(596, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(131, 20);
            this.comboBox1.TabIndex = 1030;
            this.comboBox1.Visible = false;
            this.comboBox1.TextChanged += new System.EventHandler(this.comboBox1_TextChanged);
            // 
            // label33
            // 
            this.label33.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label33.BackColor = System.Drawing.Color.LightGray;
            this.label33.Location = new System.Drawing.Point(194, 34);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(1218, 11);
            this.label33.TabIndex = 1029;
            // 
            // cbbList
            // 
            this.cbbList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbList.FormattingEnabled = true;
            this.cbbList.Items.AddRange(new object[] {
            "<全部>",
            "已打印",
            "未打印"});
            this.cbbList.Location = new System.Drawing.Point(208, 4);
            this.cbbList.Name = "cbbList";
            this.cbbList.Size = new System.Drawing.Size(76, 20);
            this.cbbList.TabIndex = 1046;
            this.cbbList.Visible = false;
            this.cbbList.TextChanged += new System.EventHandler(this.cbbList_TextChanged);
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(175, 8);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(40, 16);
            this.label20.TabIndex = 1045;
            this.label20.Text = "清单:";
            this.label20.Visible = false;
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("宋体", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label17.Location = new System.Drawing.Point(1203, 34);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(20, 9);
            this.label17.TabIndex = 1014;
            this.label17.Text = "300";
            // 
            // linkLabel22
            // 
            this.linkLabel22.AutoSize = true;
            this.linkLabel22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel22.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel22.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel22.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabel22.Location = new System.Drawing.Point(288, -1);
            this.linkLabel22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.linkLabel22.Name = "linkLabel22";
            this.linkLabel22.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.linkLabel22.Size = new System.Drawing.Size(52, 22);
            this.linkLabel22.TabIndex = 1039;
            this.linkLabel22.TabStop = true;
            this.linkLabel22.Text = "长期:1#";
            this.linkLabel22.Visible = false;
            // 
            // linkLabel32
            // 
            this.linkLabel32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel32.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabel32.LinkColor = System.Drawing.Color.BlueViolet;
            this.linkLabel32.Location = new System.Drawing.Point(200, 21);
            this.linkLabel32.Name = "linkLabel32";
            this.linkLabel32.Padding = new System.Windows.Forms.Padding(0, 5, 0, 5);
            this.linkLabel32.Size = new System.Drawing.Size(82, 22);
            this.linkLabel32.TabIndex = 1039;
            this.linkLabel32.TabStop = true;
            this.linkLabel32.Tag = "0";
            this.linkLabel32.Text = "▼";
            this.linkLabel32.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.linkLabel32.Visible = false;
            this.linkLabel32.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel32_LinkClicked);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Silver;
            this.panel6.Controls.Add(this.label1);
            this.panel6.Controls.Add(this.comboBox3);
            this.panel6.Location = new System.Drawing.Point(350, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(204, 24);
            this.panel6.TabIndex = 1044;
            this.panel6.Visible = false;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.Location = new System.Drawing.Point(5, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 1033;
            this.label1.Text = "状态：";
            // 
            // comboBox3
            // 
            this.comboBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.ItemHeight = 12;
            this.comboBox3.Items.AddRange(new object[] {
            "<全部>",
            "未打印",
            "已打印",
            "已摆药",
            "已排药",
            "已进仓",
            "已配置",
            "已出仓",
            "已打包",
            "已退药",
            "已签收",
            "配置取消",
            "提前打包"});
            this.comboBox3.Location = new System.Drawing.Point(47, 2);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(107, 20);
            this.comboBox3.TabIndex = 1034;
            this.comboBox3.Text = "<全部>";
            this.comboBox3.TextChanged += new System.EventHandler(this.comboBox3_TextChanged);
            // 
            // cbbPrinted
            // 
            this.cbbPrinted.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbPrinted.FormattingEnabled = true;
            this.cbbPrinted.Items.AddRange(new object[] {
            "<全部>",
            "已打印",
            "未打印"});
            this.cbbPrinted.Location = new System.Drawing.Point(843, 4);
            this.cbbPrinted.Name = "cbbPrinted";
            this.cbbPrinted.Size = new System.Drawing.Size(90, 20);
            this.cbbPrinted.TabIndex = 1042;
            this.cbbPrinted.Visible = false;
            this.cbbPrinted.SelectedIndexChanged += new System.EventHandler(this.cbbPrinted_SelectedIndexChanged);
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(812, 8);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(38, 13);
            this.label19.TabIndex = 1041;
            this.label19.Text = "瓶签:";
            this.label19.Visible = false;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label7.Location = new System.Drawing.Point(10, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(122, 22);
            this.label7.TabIndex = 1010;
            this.label7.Text = "瓶签查询";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(559, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 1029;
            this.label3.Text = "批次:";
            this.label3.Visible = false;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(668, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 1031;
            this.label4.Text = "筛选:";
            this.label4.Visible = false;
            // 
            // Line3
            // 
            this.Line3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Line3.BackColor = System.Drawing.Color.White;
            this.Line3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.Line3.ForeColor = System.Drawing.Color.Silver;
            this.Line3.Location = new System.Drawing.Point(202, 162);
            this.Line3.Name = "Line3";
            this.Line3.Size = new System.Drawing.Size(1021, 10);
            this.Line3.TabIndex = 1044;
            this.Line3.Text = resources.GetString("Line3.Text");
            this.Line3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Select
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.NullValue = false;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.Select.DefaultCellStyle = dataGridViewCellStyle5;
            this.Select.HeaderText = "";
            this.Select.Name = "Select";
            this.Select.ReadOnly = true;
            this.Select.Width = 30;
            // 
            // IVStatus
            // 
            this.IVStatus.HeaderText = "状态";
            this.IVStatus.MinimumWidth = 54;
            this.IVStatus.Name = "IVStatus";
            this.IVStatus.ReadOnly = true;
            this.IVStatus.Width = 54;
            // 
            // Remark
            // 
            this.Remark.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Remark.FillWeight = 30F;
            this.Remark.HeaderText = "记账";
            this.Remark.MinimumWidth = 60;
            this.Remark.Name = "Remark";
            this.Remark.ReadOnly = true;
            // 
            // LabelNo
            // 
            this.LabelNo.HeaderText = "瓶签号";
            this.LabelNo.MinimumWidth = 66;
            this.LabelNo.Name = "LabelNo";
            this.LabelNo.ReadOnly = true;
            // 
            // remark6
            // 
            this.remark6.HeaderText = "His瓶签";
            this.remark6.MinimumWidth = 72;
            this.remark6.Name = "remark6";
            this.remark6.ReadOnly = true;
            this.remark6.Visible = false;
            this.remark6.Width = 120;
            // 
            // DWard
            // 
            this.DWard.HeaderText = "病区";
            this.DWard.MinimumWidth = 100;
            this.DWard.Name = "DWard";
            this.DWard.ReadOnly = true;
            this.DWard.Width = 150;
            // 
            // BedNo
            // 
            this.BedNo.HeaderText = "床号";
            this.BedNo.MinimumWidth = 54;
            this.BedNo.Name = "BedNo";
            this.BedNo.ReadOnly = true;
            this.BedNo.Width = 54;
            // 
            // PatName
            // 
            this.PatName.HeaderText = "姓名";
            this.PatName.MinimumWidth = 54;
            this.PatName.Name = "PatName";
            this.PatName.ReadOnly = true;
            this.PatName.Width = 80;
            // 
            // GroupNo
            // 
            this.GroupNo.HeaderText = "组";
            this.GroupNo.MinimumWidth = 42;
            this.GroupNo.Name = "GroupNo";
            this.GroupNo.ReadOnly = true;
            this.GroupNo.Width = 80;
            // 
            // Batch
            // 
            this.Batch.HeaderText = "批次";
            this.Batch.MinimumWidth = 54;
            this.Batch.Name = "Batch";
            this.Batch.ReadOnly = true;
            this.Batch.Width = 54;
            // 
            // Class
            // 
            this.Class.HeaderText = "分类";
            this.Class.MinimumWidth = 42;
            this.Class.Name = "Class";
            this.Class.ReadOnly = true;
            this.Class.Width = 50;
            // 
            // MainDrug
            // 
            this.MainDrug.HeaderText = "主药";
            this.MainDrug.MinimumWidth = 54;
            this.MainDrug.Name = "MainDrug";
            this.MainDrug.ReadOnly = true;
            this.MainDrug.Width = 200;
            // 
            // MenstruumName
            // 
            this.MenstruumName.HeaderText = "溶媒";
            this.MenstruumName.MinimumWidth = 54;
            this.MenstruumName.Name = "MenstruumName";
            this.MenstruumName.ReadOnly = true;
            this.MenstruumName.Width = 200;
            // 
            // PrescriptionID
            // 
            this.PrescriptionID.HeaderText = "处方号";
            this.PrescriptionID.Name = "PrescriptionID";
            this.PrescriptionID.ReadOnly = true;
            this.PrescriptionID.Visible = false;
            this.PrescriptionID.Width = 66;
            // 
            // chrgetype
            // 
            this.chrgetype.DataPropertyName = "chargetype";
            this.chrgetype.FillWeight = 80F;
            this.chrgetype.HeaderText = "配置费";
            this.chrgetype.Name = "chrgetype";
            this.chrgetype.ReadOnly = true;
            // 
            // PivasLabel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(239)))), ((int)(((byte)(246)))));
            this.ClientSize = new System.Drawing.Size(1231, 810);
            this.Controls.Add(this.txtWard);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.dgvDWard);
            this.Controls.Add(this.dgvPre);
            this.Controls.Add(this.Line2);
            this.Controls.Add(this.Line1);
            this.Controls.Add(this.flowLayoutPanel2);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Line3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PivasLabel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "瓶签状态";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.SizeChanged += new System.EventHandler(this.PivasLabel_SizeChanged);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDWard)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPre)).EndInit();
            this.flowLayoutPanel7.ResumeLayout(false);
            this.flowLayoutPanel7.PerformLayout();
            this.flowLayoutPanel6.ResumeLayout(false);
            this.flowLayoutPanel6.PerformLayout();
            this.flowLayoutPanel11.ResumeLayout(false);
            this.flowLayoutPanel11.PerformLayout();
            this.flowLayoutPanel5.ResumeLayout(false);
            this.flowLayoutPanel5.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel4.PerformLayout();
            this.flowLayoutPanel10.ResumeLayout(false);
            this.flowLayoutPanel10.PerformLayout();
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel3.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel8.ResumeLayout(false);
            this.flowLayoutPanel8.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel pnlcancel;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.FlowLayoutPanel pnlInfo;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button label2;
        private System.Windows.Forms.Button label5;
        private System.Windows.Forms.Button Lb_Print;
        private System.Windows.Forms.Button lbCount;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.CheckBox checkBox2;
        public System.Windows.Forms.DataGridView dgvDWard;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel Panel_Close;
        private System.Windows.Forms.ComboBox cbbPrinted;
        private System.Windows.Forms.Panel Pic_Min;
        private System.Windows.Forms.Panel Pic_Max;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cbbList;
        private System.Windows.Forms.LinkLabel linkLabel32;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem TQDB;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.LinkLabel linkLabel22;
        private System.Windows.Forms.Label Line1;
        private System.Windows.Forms.Label Line2;
        private System.Windows.Forms.Label Line4;
        private System.Windows.Forms.Label label33;
        public System.Windows.Forms.DataGridView dgvPre;
        private System.Windows.Forms.TextBox txtWard;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.TextBox txtDoctor;
        private System.Windows.Forms.TextBox txtCaseID;
        private System.Windows.Forms.TextBox txtSex;
        private System.Windows.Forms.TextBox txtBatch;
        private System.Windows.Forms.TextBox textWard;
        private System.Windows.Forms.TextBox txtBedNo;
        private System.Windows.Forms.TextBox textPatient;
        private System.Windows.Forms.TextBox textDrawerName;
        private System.Windows.Forms.TextBox textWeight;
        private System.Windows.Forms.TextBox textAge;
        private System.Windows.Forms.TextBox textStartDT;
        private System.Windows.Forms.TextBox textEndDT;
        private System.Windows.Forms.TextBox textHeight;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn WardName;
        private System.Windows.Forms.DataGridViewTextBoxColumn DCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel7;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.LinkLabel linkLabel18;
        private System.Windows.Forms.LinkLabel linkLabel16;
        private System.Windows.Forms.LinkLabel linkLabel17;
        private System.Windows.Forms.LinkLabel linkLabel13;
        private System.Windows.Forms.LinkLabel linkLabel14;
        private System.Windows.Forms.LinkLabel linkLabel15;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.LinkLabel linkLabel31;
        private System.Windows.Forms.LinkLabel linkLabel20;
        private System.Windows.Forms.LinkLabel linkLabel19;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel10;
        private System.Windows.Forms.LinkLabel linkLabel33;
        private System.Windows.Forms.LinkLabel linkLabel23;
        private System.Windows.Forms.LinkLabel linkLabel21;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel9;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.LinkLabel linkLabel5;
        private System.Windows.Forms.LinkLabel linkLabel6;
        private System.Windows.Forms.LinkLabel linkLabel7;
        private System.Windows.Forms.LinkLabel linkLabel8;
        private System.Windows.Forms.LinkLabel linkLabel9;
        private System.Windows.Forms.LinkLabel linkLabel10;
        private System.Windows.Forms.LinkLabel linkLabel11;
        private System.Windows.Forms.LinkLabel linkLabel12;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.LinkLabel linkLabel27;
        private System.Windows.Forms.LinkLabel linkLabel26;
        private System.Windows.Forms.LinkLabel linkLabel25;
        private System.Windows.Forms.LinkLabel linkLabel24;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.LinkLabel linkLabel28;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.CheckBox cb_ys;
        private System.Windows.Forms.CheckBox cb_yp;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox cb_hour1;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.ComboBox cb_hour2;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtUname;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label Line3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel11;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.LinkLabel linkLabel29;
        private System.Windows.Forms.LinkLabel linkLabel30;
        private System.Windows.Forms.LinkLabel linkLabel34;
        private System.Windows.Forms.LinkLabel linkLabel35;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Select;
        private System.Windows.Forms.DataGridViewTextBoxColumn IVStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remark;
        private System.Windows.Forms.DataGridViewTextBoxColumn LabelNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn remark6;
        private System.Windows.Forms.DataGridViewTextBoxColumn DWard;
        private System.Windows.Forms.DataGridViewTextBoxColumn BedNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn PatName;
        private System.Windows.Forms.DataGridViewTextBoxColumn GroupNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Batch;
        private System.Windows.Forms.DataGridViewTextBoxColumn Class;
        private System.Windows.Forms.DataGridViewTextBoxColumn MainDrug;
        private System.Windows.Forms.DataGridViewTextBoxColumn MenstruumName;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrescriptionID;
        private System.Windows.Forms.DataGridViewTextBoxColumn chrgetype;

    }
}

