USE [Pivas2015] 
GO

/****** Object:  Table [dbo].[OrderLog]    Script Date: 2016/5/12 ������ 9:34:02 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[OrderLog](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[LogID] [varchar](32) NOT NULL,
	[CopyOver] [bit] NULL CONSTRAINT [DF_OrderLog_CopyOver]  DEFAULT ((0)),
	[AllCount] [int] NULL,
	[Docount] [varchar](50) NULL CONSTRAINT [DF_OrderLog_Docount]  DEFAULT ((0)),
	[End] [bit] NOT NULL CONSTRAINT [DF_OrderLog_End]  DEFAULT ((0)),
	[StartTime] [datetime] NOT NULL,
	[EndTime] [datetime] NULL,
	[Discard] [varchar](32) NULL CONSTRAINT [DF_OrderLog_Discard]  DEFAULT ((0)),
	[WardCode] [varchar](32) NOT NULL CONSTRAINT [DF_OrderLog_WardCode]  DEFAULT (''),
	[PatCode] [varchar](64) NOT NULL CONSTRAINT [DF_OrderLog_PatCode]  DEFAULT (''),
	[Dat] [date] NOT NULL,
 CONSTRAINT [PK_OrderLog] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY],
 CONSTRAINT [IX_LogID] UNIQUE NONCLUSTERED 
(
	[LogID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ִ�кţ��������ɲ��룬�������洢���̣�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'OrderLog', @level2type=N'COLUMN',@level2name=N'LogID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ƿǩ����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'OrderLog', @level2type=N'COLUMN',@level2name=N'CopyOver'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�����������������洢�������ɣ�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'OrderLog', @level2type=N'COLUMN',@level2name=N'AllCount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��������������洢�������ɣ�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'OrderLog', @level2type=N'COLUMN',@level2name=N'Docount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�����Ƿ����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'OrderLog', @level2type=N'COLUMN',@level2name=N'End'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��ʼʱ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'OrderLog', @level2type=N'COLUMN',@level2name=N'StartTime'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ʱ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'OrderLog', @level2type=N'COLUMN',@level2name=N'EndTime'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'OrderLog', @level2type=N'COLUMN',@level2name=N'Discard'
GO


