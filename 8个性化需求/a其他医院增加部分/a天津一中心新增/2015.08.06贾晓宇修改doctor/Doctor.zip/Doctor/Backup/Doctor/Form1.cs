﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PIVAsDBhelp;
using System.Runtime.InteropServices;

namespace Doctor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            listview1Init();
            this.label3.Text = getWardName();
        }
        string checkID = "17785";
        string prescriptionid = "243239";

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string Database, string key, string val, string filePath);

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.notifyIcon1.Visible = true;
                this.Hide();
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                this.WindowState = FormWindowState.Minimized;
                this.notifyIcon1.Visible = true;
                this.Hide();
                return;
            }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.notifyIcon1.Visible = false;
            this.Show();
            this.WindowState = FormWindowState.Normal;
            this.Focus();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Dispose();
            this.Close();
        }

        private void 显示ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            StringBuilder stringBuilder1 = new StringBuilder();
            GetPrivateProfileString("Ward", "WardCode", "", stringBuilder1, 255, ".\\Doctor.ini");
            string wardcode = stringBuilder1.ToString();
            string sql = "SELECT DISTINCT p.BedNo, p.PatientCode, p.GroupNo, pa.PatName, d.DEmployeeName, p.InceptDT, '', CONVERT(varchar(30), cp.InsertDT, 120) FROM Prescription p " +
                         "INNER JOIN CPResultRG cp ON p.PrescriptionID = cp.PrescriptionID " +
                         "INNER JOIN Patient pa ON p.PatientCode = pa.PatCode " +
                         "INNER JOIN DEmployee d ON p.DoctorCode = d.DEmployeeCode " +
                         "WHERE cp.statu IS NULL AND p.WardCode = '" + wardcode + "'";
            DB_Help db = new DB_Help();
            DataSet ds = db.GetPIVAsDB(sql);
            if (ds != null && ds.Tables[0].Rows.Count > 0)
            {
                if (this.WindowState == FormWindowState.Minimized)
                {
                    this.Show();
                    this.WindowState = FormWindowState.Normal;
                    this.listView1.Clear();
                    listview1Init();
                }
                else
                    return;
            }
        }

        private void listview1Init()
        {

            listView1.View = View.Details;
            listView1.GridLines = false;
            listView1.FullRowSelect = true;

            ColumnHeader header1 = new ColumnHeader();
            ColumnHeader header2 = new ColumnHeader();
            ColumnHeader header3 = new ColumnHeader();
            ColumnHeader header4 = new ColumnHeader();
            ColumnHeader header5 = new ColumnHeader();
            ColumnHeader header6 = new ColumnHeader();
            ColumnHeader header7 = new ColumnHeader();
            ColumnHeader header8 = new ColumnHeader();
            ColumnHeader header9 = new ColumnHeader();
            //ColumnHeader header9 = new ColumnHeader();
            //ColumnHeader header10 = new ColumnHeader();
            header1.Text = "";
            header2.Text = "床号";
            header3.Text = "住院号";
            header4.Text = "病人";
            header5.Text = "组号";
            header6.Text = "医生";
            header7.Text = "开始时间";
            header8.Text = "审方药师";
            header9.Text = "退药时间";
            //header9.Text = "";
            //header10.Text = "";
            header1.Width = 20;
            header2.Width = 60;
            header3.Width = 60;
            header4.Width = 60;
            header5.Width = 60;
            header6.Width = 60;
            header7.Width = 135;
            header8.Width = 80;
            header9.Width = 135;
            //header9.Width = 20;
            //header10.Width = 22;
            listView1.Columns.Add(header1);
            listView1.Columns.Add(header2);
            listView1.Columns.Add(header3);
            listView1.Columns.Add(header4);
            listView1.Columns.Add(header5);
            listView1.Columns.Add(header6);
            listView1.Columns.Add(header7);
            listView1.Columns.Add(header8);
            listView1.Columns.Add(header9);
            //listView1.Columns.Add(header9);
            //listView1.Columns.Add(header10);

            ImageList imagelist = new ImageList();
            imagelist.ImageSize = new Size(1,20);
            listView1.SmallImageList = imagelist;

            StringBuilder stringBuilder1 = new StringBuilder();
            GetPrivateProfileString("Ward", "WardCode", "", stringBuilder1, 255, ".\\Doctor.ini");
            string wardcode = stringBuilder1.ToString();
            PrescriptionBack(wardcode);
        }

        private void PrescriptionBack(string wardcode)
        {
            string sql = "SELECT DISTINCT cp.CheckRecID, cp.PrescriptionID, p.BedNo, p.PatientCode, p.GroupNo, pa.PatName, d.DEmployeeName, p.InceptDT, '', CONVERT(varchar(30), cp.InsertDT, 120) FROM Prescription p " +
                         "INNER JOIN CPResultRG cp ON p.PrescriptionID = cp.PrescriptionID " +
                         "INNER JOIN Patient pa ON p.PatientCode = pa.PatCode " +
                         "INNER JOIN DEmployee d ON p.DoctorCode = d.DEmployeeCode " +
                         "WHERE cp.statu IS NULL AND p.WardCode = '" + wardcode + "'";
            //sql = string.Format(sql, wardcode);
            DB_Help db = new DB_Help();
            DataSet ds = db.GetPIVAsDB(sql);
            if (ds != null && ds.Tables[0].Rows.Count > 0)
            {
                for (int a = 0; a < ds.Tables[0].Rows.Count; a++)
                {
                    ListViewItem lv1 = new ListViewItem(ds.Tables[0].Rows[a][0].ToString().Trim());
                    lv1.SubItems.Add(ds.Tables[0].Rows[a][2].ToString().Trim());
                    lv1.SubItems.Add(ds.Tables[0].Rows[a][3].ToString().Trim());
                    lv1.SubItems.Add(ds.Tables[0].Rows[a][4].ToString().Trim());
                    lv1.SubItems.Add(ds.Tables[0].Rows[a][5].ToString().Trim());
                    lv1.SubItems.Add(ds.Tables[0].Rows[a][6].ToString().Trim());
                    lv1.SubItems.Add(ds.Tables[0].Rows[a][7].ToString().Trim());
                    lv1.SubItems.Add(ds.Tables[0].Rows[a][8].ToString().Trim());
                    //lv1.SubItems.Add(ds.Tables[0].Rows[a][0].ToString().Trim());
                    //lv1.SubItems.Add(ds.Tables[0].Rows[a][1].ToString().Trim());
                    listView1.Items.Add(lv1);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            StringBuilder stringBuilder1 = new StringBuilder();
            GetPrivateProfileString("Ward", "WardCode", "", stringBuilder1, 255, ".\\Doctor.ini");
            string wardcode = stringBuilder1.ToString();
            if ("" == wardcode)
                this.panel2.Visible = true;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WritePrivateProfileString("Ward", "WardCode", this.textBox1.Text, ".\\Doctor.ini");
            this.panel2.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Confirm confirm = new Confirm(checkID, prescriptionid);
            confirm.Show();
        }

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
            checkID = this.listView1.SelectedItems[0].Text;
            DB_Help db = new DB_Help();
            try
            {
                DataSet ds = db.GetPIVAsDB("SELECT DISTINCT PrescriptionID FROM CPResultRG WHERE CheckRecID = '" + checkID + "'");
                prescriptionid = ds.Tables[0].Rows[0]["PrescriptionID"].ToString();
            }
            catch { }
            //prescriptionid = this.listView1.SelectedItems[9].Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.listView1.Clear();
            listview1Init();
            this.label3.Text = getWardName();
        }

        private string getWardName()
        {
            StringBuilder stringBuilder1 = new StringBuilder();
            GetPrivateProfileString("Ward", "WardCode", "", stringBuilder1, 255, ".\\Doctor.ini");
            string wardcode = stringBuilder1.ToString();
            DB_Help db = new DB_Help();
            DataSet ds = db.GetPIVAsDB("SELECT WardSimName FROM DWard WHERE WardCode = '"+wardcode+"'");
            string wn = ds.Tables[0].Rows[0]["WardSimName"].ToString();
            return wn;
        }
    }
}
