﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PIVAsDBhelp;

namespace Doctor
{
    public partial class Confirm : Form
    {
        string id = "";
        string pid = "";
        public Confirm(string checkID, string prescriptionID)
        {
            InitializeComponent();
            this.richTextBox1.Text = getMess(checkID);
            id = checkID;
            pid = prescriptionID;
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.textBox2.Text == "" || this.textBox3.Text == "")
                MessageBox.Show("用户名，密码不能为空");
            else
            {
                DB_Help db = new DB_Help();
                string status = "";
                string explain = "";
                string checkCode = this.textBox2.Text;
                if (this.radioButton1.Checked)
                {
                    status = "1";
                    explain = this.radioButton1.Text;
                }
                else
                {
                    status = "2";
                    explain = this.radioButton2.Text;
                }
                string sql = "IF EXISTS (SELECT * FROM CPRecord WHERE CPRecordID = {0} ) " +
                             "UPDATE CPRecord SET DoctorExplain = '{1}',CheckDCode = '{2}', DoctorOperate = {3}  WHERE CPRecordID = {4} " +
                             "ELSE " +
                             "INSERT INTO CPRecord VALUES ('{5}',0,GETDATE(),'{6}','{7}',GETDATE(),1,{8}) " +
                             "UPDATE CPResultRG SET statu = 1 WHERE CheckRecID = '{9}'";
                try
                {
                    db.GetPIVAsDB(string.Format(sql, id, explain, checkCode, status, id, pid, explain, checkCode, status, id));
                }
                catch (Exception ex) { MessageBox.Show("******"); }
                this.Dispose();
                this.Hide();
            }
        }

        private string getMess(string checkid)
        {
            DB_Help db = new DB_Help();
            DataSet ds = new DataSet();
            string mess = "";
            try 
            {
                ds = db.GetPIVAsDB("SELECT DISTINCT CensorItem, Description FROM CPResultRG WHERE CheckRecID = " + checkid);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    mess += ds.Tables[0].Rows[i]["CensorItem"].ToString() + "_" + ds.Tables[0].Rows[i]["Description"].ToString() + "\r\n";
                }
            }
            catch (Exception e) { MessageBox.Show("@@@@@@"); }
            return mess;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButton1.Checked)
                this.comboBox1.Enabled = false;
            else
                this.comboBox1.Enabled = true;
        }
    }
}
