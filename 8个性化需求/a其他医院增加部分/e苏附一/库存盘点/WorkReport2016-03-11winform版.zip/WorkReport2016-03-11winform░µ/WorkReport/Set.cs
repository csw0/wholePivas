﻿using PIVAsDBhelp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WorkReport
{
    public partial class Set : Form
    {
        DB_Help db = new DB_Help();
        public Set()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                db.IniWriteValue("WorkReport", "TotalBed", textBox1.Text);

                MessageBox.Show("保存成功！");
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show("保存失败！");
            }
        }

        private void Set_Load(object sender, EventArgs e)
        {
            textBox1.Text = db.IniReadValue("WorkReport", "TotalBed");
        }
    }
}
