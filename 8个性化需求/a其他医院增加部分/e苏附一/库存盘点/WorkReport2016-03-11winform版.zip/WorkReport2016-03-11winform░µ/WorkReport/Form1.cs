﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace WorkReport
{
    public partial class Form1 : Form
    {
        PIVAsDBhelp.DB_Help db = new PIVAsDBhelp.DB_Help();
        string totalbed = "1000";
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 填充datagridview
        /// </summary>
        private void CreateForm()
        {
            dgv.Rows.Add(9);
            dgv.Rows[0].Cells["Itema"].Value = "1.现承担输液加药调配床位";
            dgv.Rows[1].Cells["Itema"].Value = "2.每位患者日均轮流用量（含不需调配的治疗性输液和静配滴注给药中药注射液）";
            dgv.Rows[2].Cells["Itema"].Value = "3.本6个月加药调配输液总量";
            dgv.Rows[3].Cells["Itema"].Value = "4.本6个月发出治疗性输液总量";
            dgv.Rows[4].Cells["Itema"].Value = "5.静脉滴注给药中药注射液";
            dgv.Rows[5].Cells["Itema"].Value = "6.每人（药学+护理）每日平均调配工作量";
            dgv.Rows[6].Cells["Itema"].Value = "7.本6个月审核发现不适宜用药";
            dgv.Rows[7].Cells["Itema"].Value = "8.不适宜用药医嘱分析";
            dgv.Rows[8].Cells["Itema"].Value = "9，其中输液情况";

            dgv.Rows[0].Cells["result"].Value = "______张，占总床位_____%";
            dgv.Rows[1].Cells["result"].Value = "___________（袋/瓶）";
            dgv.Rows[2].Cells["result"].Value = "___________（袋/瓶）";
            dgv.Rows[3].Cells["result"].Value = "___________（袋/瓶）";
            dgv.Rows[4].Cells["result"].Value = "___________（袋/瓶）";
            dgv.Rows[5].Cells["result"].Value = "___________（袋/瓶）";
            dgv.Rows[6].Cells["result"].Value = "________条，其中医师同意修改医嘱______条，占______%,不同意修改________条，占______%";
            dgv.Rows[7].Cells["result"].Value = " 用法用量不符 _____例 \r\n \r\n 溶媒不适合   _____例 \r\n \r\n 配伍禁忌     _____例 \r\n \r\n 其他         _____例";
            dgv.Rows[8].Cells["result"].Value = "点击查看";
            dgv.Rows[0].Height = 40;
            dgv.Rows[1].Height = 60;
            dgv.Rows[2].Height = 40;
            dgv.Rows[3].Height = 40;
            dgv.Rows[4].Height = 40;
            dgv.Rows[5].Height = 40;
            dgv.Rows[6].Height = 80;
            dgv.Rows[7].Height = 140;
            dgv.Rows[8].Height =130;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CreateForm();
            totalbed = db.IniReadValue("WorkReport", "TotalBed");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string startdt = dtp.Value.ToString("yyyyMMdd");
                string enddt = dtp.Value.AddMonths(6).ToString("yyyyMMdd");
                int days = (dtp.Value.AddMonths(6) - dtp.Value).Days;
                string sql = File.ReadAllText("wrsql.txt", Encoding.Default);
                string sql1 = sql.Substring(sql.IndexOf("TreeNode1")+9, sql.IndexOf("TreeNode2")-9);
                DataSet ds1 = db.GetPIVAsDB(string.Format( sql1,startdt,enddt));
                if (ds1 != null && ds1.Tables[0].Rows.Count > 0)
                {
                    string bedcount = ds1.Tables[0].Rows.Count.ToString();
                    string bedpercent = (Math.Round(float.Parse(bedcount) / float.Parse(totalbed), 3) * 100).ToString();
                    dgv.Rows[0].Cells["result"].Value =bedcount+ "  张，占总床位"+bedpercent +"   %";
                }

                string sql2 = sql.Substring(sql.IndexOf("TreeNode2") + 9, sql.IndexOf("TreeNode3") - sql.IndexOf("TreeNode2") - 9);
                DataSet ds2 = db.GetPIVAsDB(string.Format(sql2, startdt, enddt));
                if (ds2 != null && ds2.Tables[0].Rows.Count > 0)
                {
                    string evrypeple = ds2.Tables[0].Rows[0][0].ToString();
                    dgv.Rows[2].Cells["result"].Value = evrypeple + " （袋/瓶）";

                }
               
                string sql3 = sql.Substring(sql.IndexOf("TreeNode3") + 9, sql.IndexOf("TreeNode4") - sql.IndexOf("TreeNode3") - 9);
                DataSet ds3 = db.GetPIVAsDB(string.Format(sql3, startdt, enddt));
                if (ds3 != null && ds3.Tables[0].Rows.Count > 0 && ds2 != null && ds2.Tables[0].Rows.Count > 0)
                {
                    string totallabel = ds2.Tables[0].Rows[0][0].ToString();
                    string evrypeple = ds3.Tables[0].Rows[0][0].ToString(); 
                    dgv.Rows[1].Cells["result"].Value =float.Parse(totallabel)/float.Parse(  evrypeple)/days + " （袋/瓶）";
                }

             
                string sql4 = sql.Substring(sql.IndexOf("TreeNode4") + 9, sql.IndexOf("TreeNode5") - sql.IndexOf("TreeNode4") - 9);
                DataSet ds4 = db.GetPIVAsDB(string.Format(sql4, startdt, enddt));
                if (ds4 != null && ds4.Tables[0].Rows.Count > 0)
                {
                    string evrypeple = ds4.Tables[0].Rows[0][0].ToString();
                    dgv.Rows[3].Cells["result"].Value = evrypeple + " （袋/瓶）";
                }
                string sql5 = sql.Substring(sql.IndexOf("TreeNode5") + 9, sql.IndexOf("TreeNode6") - sql.IndexOf("TreeNode5") - 9);
                DataSet ds5 = db.GetPIVAsDB(string.Format(sql5, startdt, enddt));
                if (ds5 != null && ds5.Tables[0].Rows.Count > 0)
                {
                    string evrypeple = ds5.Tables[0].Rows[0][0].ToString();
                    dgv.Rows[4].Cells["result"].Value = evrypeple + " （袋/瓶）";
                }

                string sql6 = sql.Substring(sql.IndexOf("TreeNode6") + 9, sql.IndexOf("TreeNode7")-sql.IndexOf("TreeNode6") - 9);
                DataSet ds6 = db.GetPIVAsDB(string.Format(sql6, startdt, enddt));
                if (ds6 != null && ds6.Tables[0].Rows.Count > 0)
                {
                    string evrypeple = ds6.Tables[0].Rows[0][0].ToString();
                    dgv.Rows[5].Cells["result"].Value = evrypeple + " （袋/瓶）";
                }

                string sql7 = sql.Substring(sql.IndexOf("TreeNode7") + 9, sql.IndexOf("TreeNode8") - sql.IndexOf("TreeNode7") - 9);
                DataSet ds7 = db.GetPIVAsDB(string.Format(sql7, startdt, enddt));
                if (ds7 != null && ds7.Tables[0].Rows.Count > 0)
                {
                    string evrypeple = ds7.Tables[0].Rows[0][0].ToString();
                    dgv.Rows[6].Cells["result"].Value = evrypeple+ " 条，其中医师同意修改医嘱______条，占______%,不同意修改________条，占______%";
                }

                string sql8 = sql.Substring(sql.IndexOf("TreeNode8") + 9, sql.IndexOf("TreeNode9") - sql.IndexOf("TreeNode8") - 9);
                DataSet ds8 = db.GetPIVAsDB(string.Format(sql8, startdt, enddt));
                if (ds8 != null && ds8.Tables.Count > 3)
                {
                    string evrypeple = ds8.Tables[0].Rows[0][0].ToString();
                    string evrypeple1 = ds8.Tables[1].Rows[0][0].ToString();
                    string evrypeple2 = ds8.Tables[2].Rows[0][0].ToString();
                    string evrypeple3 = ds8.Tables[3].Rows[0][0].ToString();
                    dgv.Rows[7].Cells["result"].Value =" 用法用量不符 "+evrypeple+"  例 \r\n \r\n 溶媒不适合   "+evrypeple1+" 例 \r\n \r\n 配伍禁忌     "+evrypeple2+"  例 \r\n \r\n 其他         "+evrypeple3+"  例";
                }

                string sql9 = sql.Substring(sql.IndexOf("TreeNode9") + 9, sql.IndexOf("TreeNode10") - sql.IndexOf("TreeNode9") - 9);
                DataSet ds9 = db.GetPIVAsDB(string.Format(sql9, startdt, enddt));
                if (ds9 != null && ds9.Tables[0].Rows.Count > 0)
                {
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Set s = new Set();
            s.ShowDialog();
            if (s.DialogResult == DialogResult.OK)
            {
                totalbed = db.IniReadValue("WorkReport", "TotalBed");
            }
        }
     

     
    }
}
