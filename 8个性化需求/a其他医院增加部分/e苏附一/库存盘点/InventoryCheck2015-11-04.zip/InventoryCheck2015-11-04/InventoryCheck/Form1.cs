﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HisInventoryCheck;
using PIVAsDBhelp;

namespace InventoryCheck
{
    public partial class Form1 : Form
    {
        DB_Help db = new DB_Help();
        sql mysql = new sql();
        string demployname = string.Empty;
        string DemployId = string.Empty;
        DataTable dtDrug = new DataTable(); //存放总数据
        string DrugType = string.Empty;
       
        public Form1()
        {
            InitializeComponent();
        }
        public Form1(string demployId)
        {
            InitializeComponent();
            this.DemployId = demployId;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
            comboBox3.SelectedIndex = 0;
            dateTimePicker1.Enabled = false;
            dateTimePicker2.Enabled = false;
            //label1.Visible = false;
            DataSet ds = db.GetPIVAsDB("select DEmployeeName from DEmployee where DEmployeeID='" + this.DemployId + "'");
            if(ds!=null&&ds.Tables[0].Rows.Count>0)
            {
            this.demployname=ds.Tables[0].Rows[0][0].ToString();
            }

        }

        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                dateTimePicker1.Enabled = false;
                dateTimePicker2.Enabled = false;
                //label1.Visible = false;
            }
            else
            {
                dateTimePicker1.Enabled = true;
                dateTimePicker2.Enabled = true;
                //label1.Visible = true;
            }
        }
        /// <summary>
        /// 得到当前的药品编码
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private string GetDrugCode(DataTable dt)
        {
            string DrugCodes = string.Empty;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DrugCodes = DrugCodes +"'"+ dt.Rows[i]["drugcode"].ToString()+"',";         
            }
            DrugCodes = DrugCodes.TrimEnd(',');
                return DrugCodes;        
        }
        /// <summary>
        /// 打印当日 根据HIs给的药计算
        /// </summary>
        private void  UsedDrugCount()
        {
            try
            {
                DataTable dt2 = GetHisCount("");//His数据
                DataSet ds = db.GetPIVAsDB(mysql.GetDayDrug());  //我们的数据
                DataSet ds1 = db.GetPIVAsDB(mysql.GetLC());
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt3 = ds.Tables[0].Copy();
                    dt3.Rows.Clear();
                    for (int i = 0; i < dt2.Rows.Count; i++)
                    {
                        dt3.Rows.Add(1);
                        dt3.Rows[i]["drugcode"] = dt2.Rows[i]["drugcode"].ToString();
                        dt3.Rows[i]["hiscount"] = dt2.Rows[i]["hiscount"].ToString();
                        DataRow[] dr = ds.Tables[0].Select("drugcode='" + dt2.Rows[i]["DrugCode"].ToString() + "'");
                        if (dr.Length > 0)
                        {
                            dt3.Rows[i]["DrugName"] = dr[0]["DrugName"].ToString();
                            dt3.Rows[i]["PortNo"] = dr[0]["PortNo"].ToString();
                            dt3.Rows[i]["spec"] = dr[0]["spec"].ToString();
                            dt3.Rows[i]["dcount"] = dr[0]["dcount"].ToString();
                            dt3.Rows[i]["TheDrugType"] = dr[0]["TheDrugType"].ToString();
                            dt3.Rows[i]["Precious"] = dr[0]["Precious"].ToString();
                            dt3.Rows[i]["scount"] = (Convert.ToDecimal(dt3.Rows[i]["hiscount"].ToString()) - Convert.ToDecimal(dt3.Rows[i]["dcount"].ToString()));
                            dt3.Rows[i]["SpellCode"] = dr[0]["SpellCode"].ToString();
                            //冷藏
                            if (ds1 != null && ds1.Tables.Count > 0)
                            {
                                DataRow[] dr1 = ds1.Tables[0].Select("drugcode='" + dt2.Rows[i]["DrugCode"].ToString() + "' and DrugPlusConditionName='冷藏'");
                                if (dr1.Length > 0)
                                {
                                    dt3.Rows[i]["LC"] = "冷藏";
                                }
                            }
                        }
                        else
                        {
                            dt3.Rows[i]["DrugName"] = "未知";
                            dt3.Rows[i]["PortNo"] = "";
                            dt3.Rows[i]["spec"] = "";
                            dt3.Rows[i]["dcount"] = "0";
                            dt3.Rows[i]["TheDrugType"] = "1";
                            dt3.Rows[i]["Precious"] = "1";
                            dt3.Rows[i]["scount"] = dt3.Rows[i]["hiscount"].ToString();
                            dt3.Rows[i]["SpellCode"] = "未知";
                        }

                    }
                    dtDrug = dt3;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }           
                
        }
    
        /// <summary>
        /// 调用His接口 
        /// </summary>
        /// <param name="DrugCodes"></param>
        /// <returns></returns>
        private DataTable GetHisCount(string DrugCodes)
        {
            HisInventory hi = new HisInventory();
            DataTable dt = hi.GetHis(DrugCodes);
           
          return dt;
        }
        /// <summary>
        /// 获取药品的历史数据
        /// </summary>
        private void  GetGrugHistory()
        {
            DataTable dt1 = new DataTable();
            DataSet ds = db.GetPIVAsDB(mysql.GetHistoyDrug(dateTimePicker1.Value.ToString(), dateTimePicker2.Value.ToString(),GetDrugType(),comboBox2.SelectedIndex));
            if (ds != null && ds.Tables.Count > 0)
            {
                dt1 = ds.Tables[0];
                dtDrug = dt1;
                printer1(dt1);
            }
        }
        /// <summary>
        /// 打印历史数据 
        /// </summary>
        /// <param name="dt"></param>
        private void printer1(DataTable dt)
        {
            previewQD.Visible = true;
            report.Clear();
            report.Preview = previewQD;
            report.Load(".\\Crystal\\InventoryUsed.frx");
            report.GetParameter("PrintDT").Value = dateTimePicker1.Value.ToString("yyyy-MM-dd")+" - "+dateTimePicker2.Value.ToString("yyyy-MM-dd");
            report.GetParameter("Total").Value = dt.Rows.Count;
            report.GetParameter("DemployName").Value = this.demployname;
            report.RegisterData(dt, "dt");
            ((report.FindObject("Data1")) as FastReport.DataBand).DataSource = report.GetDataSource("dt");
            report.Show();
        
        }
        /// <summary>
        /// 打印当日数据
        /// </summary>
        /// <param name="dt"></param>
        private void printer2(DataTable dt)
        {
            previewQD.Visible = true;
            report.Clear();
            if (dt != null)
            {
                report.Preview = previewQD;
                report.Load(".\\Crystal\\InventoryTodayUsed.frx");
                report.GetParameter("PrintDT").Value = DateTime.Now.ToString("");
                report.GetParameter("Total").Value = dt.Rows.Count;
                report.GetParameter("DemployName").Value = this.demployname;
                report.RegisterData(dt, "dt");
                ((report.FindObject("Data1")) as FastReport.DataBand).DataSource = report.GetDataSource("dt");
                report.Show();
            }
            else
            {
                previewQD.Clear();
            
            }
        }
        /// <summary>
        /// 筛选
        /// </summary>
        /// <returns></returns>
        private DataTable SelectInfor()
        {
            DataTable dt = new DataTable();
            string Precious = string.Empty;
            if (comboBox2.SelectedIndex == 0)
            {
                Precious = "1,2";
            }
            else if (comboBox2.SelectedIndex == 1)
            {
                Precious = "2";
            }
            else
            {
                Precious = "1"; 
            }
            if (comboBox3.SelectedIndex==1)
            {

                DataRow[] dr = dtDrug.Select("TheDrugType in(" + GetDrugType() + ") and Precious in (" + Precious + ") and LC='冷藏'");
                dt = ToDataTable(dr);
            }
            else if (comboBox3.SelectedIndex == 2)
            {
                DataRow[] dr = dtDrug.Select("TheDrugType in(" + GetDrugType() + ") and Precious in (" + Precious + ") and LC is null ");
                dt = ToDataTable(dr);
            }
            else
            {
                DataRow[] dr = dtDrug.Select("TheDrugType in(" + GetDrugType() + ") and Precious in (" + Precious + ") ");
                dt = ToDataTable(dr);
            }
            return dt;
        }
        public DataTable ToDataTable(DataRow[] rows)
        {
            if (rows == null || rows.Length == 0) return null;
            DataTable tmp = rows[0].Table.Clone(); // 复制DataRow的表结构
            for (int i = 0; i < rows.Length; i++)
            {
                tmp.ImportRow(rows[i]);
            } 
            return tmp;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //string a = mysql.GetDayDrug("");
            if (comboBox1.SelectedIndex == 0)
            {
                UsedDrugCount();
                
                    DataTable dt = SelectInfor();
                    printer2(dt);
                
              
            }
            else
            {
                GetGrugHistory();
            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "药品名/药品编码")
            {
                textBox1.Text = "";
                textBox1.ForeColor = Color.Black;
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "药品名/药品编码";
                textBox1.ForeColor = Color.Silver;
            }
        }

      

        private string GetDrugType()
        {
            string drugT = string.Empty;
          
            if (checkBox1.Checked)
            {
                drugT += ",1";
            }

            if (checkBox2.Checked)
            {
                drugT += ",2";
            }

            if (checkBox3.Checked)
            {
                drugT += ",3";
            }
            if (checkBox4.Checked)
            {
                drugT += ",4";
            }
            drugT = drugT.TrimStart(',');
            return drugT;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13&&dtDrug.Rows.Count>0)
            {
                DataTable dt = dtDrug.Copy();
                dt.Rows.Clear();
                if (textBox1.Text != "药品名/药品编码" && textBox1.Text != "")
                {
                    DataRow[] dr = dtDrug.Select("drugcode  like '%" + textBox1.Text + "%' or DrugName like '%" + textBox1.Text + "%'or SpellCode like '%"+textBox1.Text+"%' ");
                    for (int i = 0; i < dr.Length; i++)
                    {
                        dt.ImportRow(dr[i]);
                    }
                }
                else
                {
                    dt = dtDrug;
                }

                if (comboBox1.SelectedIndex == 0)
                {
                    printer2(dt);
                }
                else
                {
                    printer1(dt);

                }
            
            }
        }

   
    }
}
