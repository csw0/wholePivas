﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;
using PIVAsDBhelp;

namespace SynWebSer
{
    internal sealed partial class MainForm : Form
    {
        //更新cs
        private DataSet Lds = new DataSet();
        private DataTable res = new DataTable();
        private bool CanRun = false;
        private bool RunUP = false;
        private DB_Help db = new DB_Help();

        internal MainForm()
        {
            if (!Directory.Exists(".\\ErrLog\\"))
            {
                Directory.CreateDirectory(".\\ErrLog\\");
            }
            if (!Directory.Exists(".\\SendLog\\"))
            {
                Directory.CreateDirectory(".\\SendLog\\");
            }
            if (!Directory.Exists(".\\SyncDatBack\\"))
            {
                Directory.CreateDirectory(".\\SyncDatBack\\");
            }
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                StringBuilder SB = new StringBuilder();
                SB.AppendLine(" IF OBJECT_ID('IVRecordToFC') IS NULL BEGIN ");
                SB.AppendLine(" CREATE TABLE[dbo].[IVRecordToFC]([LabelNo][varchar](32) NOT NULL,[FCDT][datetime] NULL,CONSTRAINT[PK_IVRecordToFC] PRIMARY KEY CLUSTERED ");
                SB.AppendLine(" ([LabelNo] ASC)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]) ON[PRIMARY] ");
                SB.AppendLine(" END");

                db.SetPIVAsDB(SB.ToString());

                if (File.Exists(".\\SynWebDat.dat"))
                {
                    Lds.ReadXml(".\\SynWebDat.dat", XmlReadMode.ReadSchema);
                    CheckDLL();
                }
                else
                {
                    DataTable dt = new DataTable();
                    dt.TableName = "SynWebDat";
                    dt.Columns.Add("地址", typeof(string));
                    dt.Columns.Add("参数", typeof(string));
                    dt.Columns.Add("回传更新", typeof(string));
                    dt.Columns.Add("自动更新", typeof(string));
                    dt.Columns.Add("Running", typeof(bool));
                    dt.PrimaryKey = new DataColumn[] { dt.Columns["地址"], dt.Columns["参数"] };
                    Lds.Tables.Add(dt);
                    DataTable dt2 = new DataTable();
                    dt2.TableName = "";
                    dt2.Columns.Add("DLL名称", typeof(string));
                    dt2.Columns.Add("命名空间", typeof(string));
                    dt2.Columns.Add("类名", typeof(string));
                    dt2.Columns.Add("方法名", typeof(string));
                    dt2.PrimaryKey = new DataColumn[] { dt2.Columns["DLL名称"], dt2.Columns["类名"], dt2.Columns["方法名"] };
                    Lds.Tables.Add(dt2);
                }
                dataGridView1.DataSource = Lds.Tables[0];
                dataGridView1.Columns[0].Width = 150;
                dataGridView1.Columns[1].Width = 150;
                dataGridView1.Columns[2].Width = 150;
                dataGridView1.Columns[3].Width = 150;
                dataGridView1.Columns["Running"].Visible = false;

                dataGridView3.DataSource = Lds.Tables[1];
                dataGridView3.Columns[0].Width = 150;
                dataGridView3.Columns[1].Width = 150;
                dataGridView3.Columns[2].Width = 150;
                dataGridView3.Columns[3].Width = 150;


                res.TableName = "res";
                res.Columns.Add("time", typeof(string));
                res.Columns.Add("ret", typeof(string));
                dataGridView2.DataSource = res;
                dataGridView2.Columns[0].Width = 60;
                dataGridView2.Columns[1].Width = 180;
                if (Lds.Tables[0].Rows.Count > 0)
                {
                    button1_Click(sender, e);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void CheckDLL()
        {
            try
            {
                foreach (DataRow dr in Lds.Tables[0].Rows)
                {
                    dr["Running"] = false;
                }
                foreach(DataRow dr in Lds.Tables[1].Rows)
                {
                    if(string.IsNullOrEmpty(dr[1].ToString()))
                    {
                        dr[1] = dr[0].ToString().Split('.')[0];
                    }
                }
                Lds.WriteXml(".\\SynWebDat.dat", XmlWriteMode.WriteSchema);
                Lds.WriteXml(".\\SyncDatBack\\SynWebDat(" + DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss") + ").dat.bak", XmlWriteMode.WriteSchema);
            }
            catch (Exception ex)
            {
                SaveErrLog("CheckDLL", ex.Message);
            }
        }

        private void SaveErrLog(string Func, string ErrMsg)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("【" + DateTime.Now.ToString("HH:mm:ss") + "】" + Func);
                sb.AppendLine(ErrMsg);
                sb.AppendLine(" ");
                File.AppendAllText(".\\ErrLog\\" + DateTime.Now.ToString("yyyy-MM-dd") + ".log", sb.ToString());
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
        }

        private void timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (!CanRun)
            {
                CanRun = true;
                try
                {
                    foreach (DataRow dr in Lds.Tables[0].Rows)
                    {
                        try
                        {
                            if (false.Equals(dr["Running"]))
                            {
                                string xmlstr = string.Empty;
                                DataSet dss = new DataSet();
                                string[] values = dr["参数"].ToString().Split('|');
                                if (values.Length == 2 && values[1].ToUpper().Contains("SELECT") && values[1].ToUpper().Contains("FROM"))
                                {
                                    dss = db.GetPIVAsDB(values[1]);
                                    if (dss != null && dss.Tables.Count > 0 && dss.Tables[0].Rows.Count > 0)
                                    {
                                        using (StringWriter sw = new StringWriter())
                                        {
                                            dss.WriteXml(sw, XmlWriteMode.IgnoreSchema);
                                            StringBuilder sb = new StringBuilder();
                                            sb.AppendLine("<ROOT>");
                                            sb.AppendLine(values[0].Trim());
                                            sb.AppendLine(sw.ToString().Replace("NewDataSet", "ROOT").Replace("Table", "CONSIS_ORDER_MSTVW").Replace("<ROOT>", string.Empty).Trim());
                                            xmlstr = sb.ToString();
                                        }
                                    }
                                }
                                if (!string.IsNullOrEmpty(xmlstr))
                                {
                                    WrLog(xmlstr);
                                    Thread TH = new Thread(() =>
                                    {
                                        try
                                        {
                                            dr["Running"] = true;
                                            //HPSClientProxyHis40.HisWcfProxy hwcf = new HPSClientProxyHis40.HisWcfProxy(dr["地址"].ToString(),5);
                                            string Retmsg = RunMethodofWebSer(Lds.Tables[1].Rows[0][0].ToString(), Lds.Tables[1].Rows[0][1].ToString(), Lds.Tables[1].Rows[0][2].ToString(), Lds.Tables[1].Rows[0][3].ToString(), new object[] { dr["地址"].ToString(), 45 }, new object[] { xmlstr }) as string;   //hwcf.HisTransData(xmlstr);
                                            res.Rows.Add(DateTime.Now.ToString("HH:mm:ss"), Retmsg);
                                            if (!string.IsNullOrEmpty(Retmsg))
                                            {
                                                StringBuilder sb = new StringBuilder();
                                                sb.AppendLine("<NewDataSet>");
                                                sb.AppendLine(Retmsg);
                                                sb.AppendLine("</NewDataSet>");
                                                using (DataSet dts = new DataSet())
                                                {
                                                    dts.ReadXml(new StringReader(sb.ToString()));
                                                    string[] RetCZ = dr["回传更新"].ToString().Split('|');
                                                    if (dts.Tables[0].Rows[0]["RETCODE"].ToString().Trim() == RetCZ[0].Trim())
                                                    {
                                                        foreach (string s in RetCZ)
                                                        {
                                                            if (s.ToUpper().Contains("UPDATE") && s.ToUpper().Contains("SET") && s.ToUpper().Contains("WHERE"))
                                                            {
                                                                db.SetPIVAsDB(s);
                                                            }
                                                            else if (s.ToUpper().Contains("SELECT") && s.ToUpper().Contains("FROM") && s.ToUpper().Contains("WHERE"))
                                                            {
                                                                using (DataSet ds = new DataSet())
                                                                {
                                                                    using (SqlConnection sc = new SqlConnection(db.DatebasePIVAsInfo()))
                                                                    {
                                                                        using (SqlDataAdapter sda = new SqlDataAdapter(s, sc))
                                                                        {
                                                                            sda.Fill(ds);
                                                                            ds.Tables[0].PrimaryKey = new DataColumn[] { ds.Tables[0].Columns[0] };
                                                                            string pKey = ds.Tables[0].Columns[0].ColumnName;
                                                                            foreach (DataRow drs in dss.Tables[0].DefaultView.ToTable(true, pKey).Rows)
                                                                            {
                                                                                if (!ds.Tables[0].Rows.Contains(drs[pKey]))
                                                                                {
                                                                                    DataRow dsdr = ds.Tables[0].NewRow();
                                                                                    dsdr[0] = drs[pKey];
                                                                                    dsdr[1] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                                                                                    ds.Tables[0].Rows.Add(dsdr);
                                                                                }
                                                                                else
                                                                                {
                                                                                    ds.Tables[0].Rows.Find(drs[pKey])[1] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                                                                                }
                                                                            }
                                                                            using (DataSet cds = ds.GetChanges(DataRowState.Added))
                                                                            {
                                                                                if (cds != null && cds.Tables.Count > 0 && cds.Tables[0].Rows.Count > 0)
                                                                                {
                                                                                    using (SqlCommandBuilder scb = new SqlCommandBuilder(sda))
                                                                                    {
                                                                                        scb.GetInsertCommand();
                                                                                        scb.DataAdapter.Update(ds.GetChanges(DataRowState.Added));
                                                                                    }
                                                                                }
                                                                            }
                                                                            using (DataSet cds = ds.GetChanges(DataRowState.Modified))
                                                                            {
                                                                                if (cds != null && cds.Tables.Count > 0 && cds.Tables[0].Rows.Count > 0)
                                                                                {
                                                                                    using (SqlCommandBuilder scb = new SqlCommandBuilder(sda))
                                                                                    {
                                                                                        scb.GetUpdateCommand();
                                                                                        scb.DataAdapter.Update(ds.GetChanges(DataRowState.Modified));
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            dss.Dispose();
                                        }
                                        catch (Exception ex)
                                        {
                                            SaveErrLog("timer1_Elapsed_Thread", ex.Message);
                                        }
                                        finally
                                        {
                                            dr["Running"] = false;
                                        }
                                    });
                                    TH.IsBackground = true;
                                    TH.Start();
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SaveErrLog("timer1_Elapsed", ex.Message);
                        }
                    }
                }
                catch (Exception ex)
                {
                    SaveErrLog("timer1_Elapsed", ex.Message);
                }
                CanRun = false;
            }
        }
        private void WrLog(string Val)
        {
            Thread th = new Thread(() =>
            {
                try
                {
                    foreach (string s in Directory.GetFiles(Application.StartupPath + "\\SendLog\\"))
                    {
                        if (File.GetCreationTime(s).AddDays(15) < DateTime.Now)
                        {
                            File.Delete(s);
                        }
                    }
                    File.WriteAllText(".\\SendLog\\" + DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss") + ".Log", Val);
                }
                catch (Exception ex)
                {
                    SaveErrLog("WrLog", ex.Message);
                }
            });
            th.IsBackground = true;
            th.Start();
        }

        private object RunMethodofWebSer(string dllname, string ns, string classname, string methodname, object[] cargs, object[] args)
        {
            object ret = string.Empty;
            try
            {
                Assembly assembly = Assembly.LoadFrom(".\\" + (dllname.Contains(".dll") ? dllname : dllname + ".dll"));
                Type t = assembly.GetType(ns + "." + classname, true, true);
                object obj = cargs.Length == 0 ? Activator.CreateInstance(t) : Activator.CreateInstance(t, cargs);
                MethodInfo mi = t.GetMethod(methodname, new Type[] { typeof(string) });
                ret = mi.Invoke(obj, args);
            }
            catch (Exception ex)
            {
                SaveErrLog("RunMethodofWebSer", ex.Message);
            }
            return ret;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!timer1.Enabled)
            {
                CheckDLL();
                dataGridView1.ReadOnly =
                dataGridView3.ReadOnly = true;
                timer1.Enabled = true;
                button1.Text = "停止";
                timer1_Elapsed(sender, null);
            }
            else
            {
                dataGridView1.ReadOnly =
                dataGridView3.ReadOnly = false;
                timer1.Enabled = false;
                button1.Text = "启动";
            }
        }

        private void 删除ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!timer1.Enabled)
            {
                MessageBox.Show(sender.ToString());
                if (dataGridView1.RowCount > 0 && !dataGridView1.CurrentRow.IsNewRow)
                {
                    dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
                }
                if (dataGridView3.RowCount > 0 && !dataGridView3.CurrentRow.IsNewRow)
                {
                    dataGridView3.Rows.Remove(dataGridView3.CurrentRow);
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0: { timer1.Interval = 1000 * 60; break; }
                case 1: { timer1.Interval = 1000 * 180; break; }
                case 2: { timer1.Interval = 1000 * 600; break; }
                case 3: { timer1.Interval = 1000 * 1800; break; }
                case 4: { timer1.Interval = 1000 * 3600; break; }
                default: { break; }
            }
        }

        private void dataGridView1_SizeChanged(object sender, EventArgs e)
        {
            dataGridView1.Columns[0].Width =
            dataGridView1.Columns[1].Width =
            dataGridView1.Columns[2].Width = dataGridView1.Width / 3;
        }

        private void timer2_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (!RunUP)
            {
                try
                {
                    RunUP = true;
                    string[] RetCZ = Lds.Tables[0].Rows[0]["自动更新"].ToString().Split('|');
                    foreach (string s in RetCZ)
                    {
                        if (!string.IsNullOrEmpty(s.Trim()))
                        {
                            try
                            {
                                db.SetPIVAsDB(s);
                            }
                            catch(Exception ex)
                            {
                                SaveErrLog("RunForeachUPDATA", ex.Message);
                            }
                        }
                    }
                }
                catch (Exception EX)
                {
                    SaveErrLog("RunUPDATA", EX.Message);
                }
                finally
                {
                    RunUP = false;
                }
            }
            if (res.Rows.Count > 14)
            {
                res.Rows.RemoveAt(0);
            }
            dataGridView2.Refresh();
        }

        private bool SetAutoRun(bool isAutoRun)
        {
            try
            {
                string fileName = Application.StartupPath + "\\SynWebSer.exe";
                if (File.Exists(fileName))
                {
                    using (RegistryKey reg = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true))
                    {
                        if (isAutoRun)
                        {
                            reg.SetValue("SynServer", fileName);
                            reg.Flush();
                        }
                        else
                        {
                            reg.DeleteValue("SynServer", false);
                        }
                    }
                    return true;
                }
                else
                {
                    MessageBox.Show("执行文件不存在!");
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        private void dataGridView3_SizeChanged(object sender, EventArgs e)
        {
            dataGridView3.Columns[0].Width =
            dataGridView3.Columns[1].Width =
            dataGridView3.Columns[2].Width =
            dataGridView3.Columns[3].Width = dataGridView3.Width / 4;
        }
    }
}
