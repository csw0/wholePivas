﻿using System;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using ChargeInterface;

namespace PivasDrugBackToHIS
{
    internal sealed partial class DrugBack : Form
    {
        private string UserID = string.Empty;
        private Charge CH = new Charge();
        public DrugBack(string ID)
        {
            this.UserID = ID;
            InitializeComponent();
        }

        private void DrugBack_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(textBox1.Text.Trim()))
                {
                    ulong i = 0;
                    if (textBox1.Text.Trim().Length > 10 && ulong.TryParse(textBox1.Text.Trim(), out i))
                    {
                        string Val = textBox1.Text.Trim();
                        StringBuilder sb = new StringBuilder();
                        sb.AppendLine(Val);
                        sb.AppendLine("正在进行退药...");
                        textBox2.Text = sb.ToString();
                        TextBox.CheckForIllegalCrossThreadCalls = false;
                        Thread th = new Thread(() =>
                        {
                            string RET = string.Empty;
                            sb.AppendLine(CH.DrugBackToHIS(Val, UserID, out RET) ? "退药成功！" : RET);
                            textBox2.Text = sb.ToString();
                        });
                        th.IsBackground = true;
                        th.Start();
                    }
                    else
                    {
                        MessageBox.Show("请输入正确的瓶签");
                    }
                }
            }
            catch (Exception ex)
            {
                textBox2.Text = ex.Message;
            }
        }
    }
}
