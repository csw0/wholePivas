USE [Pivas20130630]
GO

/****** Object:  Table [dbo].[RevPreFormSet]    Script Date: 07/10/2014 14:36:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[RevPreFormSet](
	[DEmployeeID] [int] NULL,
	[WardIdle] [smallint] NULL,
	[WardOpen] [smallint] NULL,
	[RevPreOver] [smallint] NULL,
	[PreviewMode] [smallint] NULL,
	[Confirm] [smallint] NULL,
	[SelectAll] [smallint] NULL,
	[NameList] [smallint] NULL,
	[Level3Color] [varchar](16) NOT NULL,
	[Level5Color] [varchar](16) NOT NULL,
	[RightColor] [varchar](16) NOT NULL,
	[SelectedColor] [varchar](16) NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[RevPreFormSet] ADD  CONSTRAINT [DF_RevPreFormSet_NameList]  DEFAULT ((0)) FOR [NameList]
GO

ALTER TABLE [dbo].[RevPreFormSet] ADD  CONSTRAINT [DF_RevPreFormSet_Level3Color]  DEFAULT ((0)) FOR [Level3Color]
GO

ALTER TABLE [dbo].[RevPreFormSet] ADD  CONSTRAINT [DF_RevPreFormSet_Level5Color]  DEFAULT ((0)) FOR [Level5Color]
GO

ALTER TABLE [dbo].[RevPreFormSet] ADD  CONSTRAINT [DF_RevPreFormSet_RightColor]  DEFAULT ((0)) FOR [RightColor]
GO

ALTER TABLE [dbo].[RevPreFormSet] ADD  CONSTRAINT [DF_RevPreFormSet_SelectedColor]  DEFAULT ((0)) FOR [SelectedColor]
GO


