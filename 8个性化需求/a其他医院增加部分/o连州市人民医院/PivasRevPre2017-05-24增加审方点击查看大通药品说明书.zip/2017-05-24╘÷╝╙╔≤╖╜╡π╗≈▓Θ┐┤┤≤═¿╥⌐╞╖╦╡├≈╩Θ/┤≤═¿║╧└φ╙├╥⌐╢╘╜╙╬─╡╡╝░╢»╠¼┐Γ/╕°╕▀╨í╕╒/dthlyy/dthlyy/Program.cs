﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace dthlyy
{
    static class Program
    {
        [DllImport("dtywzxUI.dll")]          //请注意不要使用unicode，大通使用ANSI（默认）
        public static extern int dtywzxUI(int i_code, int i_param, string s_buffer);

        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        { 
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length < 1)
            {
                return;
            }
            string xml = args[0];

            //string xml = "<safe><general_name>123</general_name><license_number>1051</license_number><type>0</type></safe> ";

            int rt = dtywzxUI(0, 0, "");
            if (0 == rt)
                MessageBox.Show("服务未运行");
            else
            {
                rt = dtywzxUI(12, 0, xml);
                if (-1 == rt)
                    MessageBox.Show("调用大通药品说明书失败." + rt.ToString());
            }

            //Application.Run(new Form1());
        }
    }
}
