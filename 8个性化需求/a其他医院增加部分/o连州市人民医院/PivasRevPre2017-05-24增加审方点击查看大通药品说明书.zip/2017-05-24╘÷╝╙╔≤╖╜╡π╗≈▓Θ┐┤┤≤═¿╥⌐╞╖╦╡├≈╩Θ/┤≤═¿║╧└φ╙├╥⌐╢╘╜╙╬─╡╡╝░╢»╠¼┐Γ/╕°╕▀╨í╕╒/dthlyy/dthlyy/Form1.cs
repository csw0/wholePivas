﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;

using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace dthlyy
{
    public partial class Form1 : Form
    {
        string ypmc;
        string ypbh;
        [DllImport("dtywzxUI.dll")]          //请注意不要使用unicode，大通使用ANSI（默认）
        public static extern int dtywzxUI(int i_code, int i_param, string s_buffer);

        public Form1()
        {
            InitializeComponent();
        }

        private string getANSI(string _xml)
        {
            byte[] buf = System.Text.Encoding.Unicode.GetBytes(_xml);
            return Encoding.ASCII.GetString(buf, 0, buf.Length);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ypmc = textBox1.Text;
            ypbh = textBox2.Text;
            string xml = "<safe><general_name>"+ ypmc + "</general_name><license_number>"+ ypbh + "</license_number><type>0</type></safe> ";

            int rt = dtywzxUI(0, 0, "");
            if (0 == rt)
                MessageBox.Show("服务未运行");
            else
            {
                rt = dtywzxUI(12, 0, xml);
                //MessageBox.Show(rt.ToString());
            }
            this.Close();
        }


    }
}
