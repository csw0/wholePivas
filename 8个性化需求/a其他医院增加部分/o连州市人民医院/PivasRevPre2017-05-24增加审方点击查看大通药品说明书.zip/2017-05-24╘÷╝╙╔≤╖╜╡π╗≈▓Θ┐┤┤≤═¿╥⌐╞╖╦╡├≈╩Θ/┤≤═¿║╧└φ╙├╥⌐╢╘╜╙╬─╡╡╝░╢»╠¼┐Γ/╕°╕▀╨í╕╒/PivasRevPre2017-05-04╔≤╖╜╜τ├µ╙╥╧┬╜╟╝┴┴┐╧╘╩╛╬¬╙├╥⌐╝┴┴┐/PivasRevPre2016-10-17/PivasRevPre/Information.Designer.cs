﻿namespace PivasRevPre
{
    partial class Information
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label3 = new System.Windows.Forms.Label();
            this.pnlInfo = new System.Windows.Forms.FlowLayoutPanel();
            this.lblDoctor = new System.Windows.Forms.TextBox();
            this.lblPatient = new System.Windows.Forms.TextBox();
            this.lblWard = new System.Windows.Forms.TextBox();
            this.lblAge = new System.Windows.Forms.TextBox();
            this.lblWeight = new System.Windows.Forms.TextBox();
            this.lblBedNo = new System.Windows.Forms.TextBox();
            this.lblSex = new System.Windows.Forms.TextBox();
            this.lblCaseID = new System.Windows.Forms.TextBox();
            this.tboxDiagnosis = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnRecheck = new System.Windows.Forms.Button();
            this.dgvDrugs = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnTuiDan = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.lblBatch = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.lblCPtime = new System.Windows.Forms.TextBox();
            this.lblEndDT = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblGroupNo = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.lblexplain = new System.Windows.Forms.TextBox();
            this.lblCPer = new System.Windows.Forms.TextBox();
            this.lblyongfa = new System.Windows.Forms.TextBox();
            this.lblStartDT = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.ColDrugName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColDrugSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColYongLiang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColPiShi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remark7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColUniPreparationID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColRemark8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColRemark9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColRemark10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColDrugCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDrugs)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Silver;
            this.label3.Location = new System.Drawing.Point(11, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "No.";
            // 
            // pnlInfo
            // 
            this.pnlInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlInfo.AutoScroll = true;
            this.pnlInfo.BackColor = System.Drawing.Color.White;
            this.pnlInfo.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.pnlInfo.Location = new System.Drawing.Point(0, -1);
            this.pnlInfo.Margin = new System.Windows.Forms.Padding(0);
            this.pnlInfo.Name = "pnlInfo";
            this.pnlInfo.Size = new System.Drawing.Size(482, 173);
            this.pnlInfo.TabIndex = 30;
            this.toolTip1.SetToolTip(this.pnlInfo, "系统审方结果");
            this.pnlInfo.WrapContents = false;
            this.pnlInfo.SizeChanged += new System.EventHandler(this.pnlInfo_SizeChanged);
            // 
            // lblDoctor
            // 
            this.lblDoctor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDoctor.BackColor = System.Drawing.Color.White;
            this.lblDoctor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblDoctor.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblDoctor.Location = new System.Drawing.Point(354, 64);
            this.lblDoctor.Name = "lblDoctor";
            this.lblDoctor.ReadOnly = true;
            this.lblDoctor.Size = new System.Drawing.Size(125, 16);
            this.lblDoctor.TabIndex = 41;
            this.lblDoctor.Text = "医生";
            // 
            // lblPatient
            // 
            this.lblPatient.BackColor = System.Drawing.Color.White;
            this.lblPatient.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblPatient.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblPatient.Location = new System.Drawing.Point(158, 15);
            this.lblPatient.Name = "lblPatient";
            this.lblPatient.ReadOnly = true;
            this.lblPatient.Size = new System.Drawing.Size(97, 22);
            this.lblPatient.TabIndex = 42;
            this.lblPatient.Text = "患者姓名";
            this.toolTip1.SetToolTip(this.lblPatient, "患者姓名");
            this.lblPatient.Click += new System.EventHandler(this.lblPatient_Click);
            // 
            // lblWard
            // 
            this.lblWard.BackColor = System.Drawing.Color.White;
            this.lblWard.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblWard.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWard.Location = new System.Drawing.Point(40, 67);
            this.lblWard.Name = "lblWard";
            this.lblWard.ReadOnly = true;
            this.lblWard.Size = new System.Drawing.Size(172, 16);
            this.lblWard.TabIndex = 43;
            this.lblWard.Text = "病区";
            this.toolTip1.SetToolTip(this.lblWard, "患者所在病区");
            // 
            // lblAge
            // 
            this.lblAge.BackColor = System.Drawing.Color.White;
            this.lblAge.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblAge.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblAge.Location = new System.Drawing.Point(307, 17);
            this.lblAge.Name = "lblAge";
            this.lblAge.ReadOnly = true;
            this.lblAge.Size = new System.Drawing.Size(62, 16);
            this.lblAge.TabIndex = 44;
            this.lblAge.Text = "年龄";
            this.toolTip1.SetToolTip(this.lblAge, "患者年龄");
            // 
            // lblWeight
            // 
            this.lblWeight.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblWeight.BackColor = System.Drawing.Color.White;
            this.lblWeight.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblWeight.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWeight.Location = new System.Drawing.Point(283, 44);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.ReadOnly = true;
            this.lblWeight.Size = new System.Drawing.Size(50, 16);
            this.lblWeight.TabIndex = 45;
            this.lblWeight.Text = "体重";
            this.toolTip1.SetToolTip(this.lblWeight, "患者体重");
            // 
            // lblBedNo
            // 
            this.lblBedNo.BackColor = System.Drawing.Color.White;
            this.lblBedNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblBedNo.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblBedNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblBedNo.Location = new System.Drawing.Point(9, 7);
            this.lblBedNo.Name = "lblBedNo";
            this.lblBedNo.ReadOnly = true;
            this.lblBedNo.Size = new System.Drawing.Size(136, 34);
            this.lblBedNo.TabIndex = 46;
            this.lblBedNo.Text = "床号";
            this.lblBedNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.toolTip1.SetToolTip(this.lblBedNo, "患者床号");
            // 
            // lblSex
            // 
            this.lblSex.BackColor = System.Drawing.Color.White;
            this.lblSex.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblSex.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblSex.Location = new System.Drawing.Point(264, 17);
            this.lblSex.Name = "lblSex";
            this.lblSex.ReadOnly = true;
            this.lblSex.Size = new System.Drawing.Size(37, 16);
            this.lblSex.TabIndex = 47;
            this.lblSex.Text = "性别";
            this.toolTip1.SetToolTip(this.lblSex, "患者性别");
            // 
            // lblCaseID
            // 
            this.lblCaseID.BackColor = System.Drawing.Color.White;
            this.lblCaseID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblCaseID.Location = new System.Drawing.Point(36, 46);
            this.lblCaseID.Name = "lblCaseID";
            this.lblCaseID.ReadOnly = true;
            this.lblCaseID.Size = new System.Drawing.Size(100, 14);
            this.lblCaseID.TabIndex = 48;
            this.lblCaseID.Text = "住院号";
            this.toolTip1.SetToolTip(this.lblCaseID, "患者住院号");
            // 
            // tboxDiagnosis
            // 
            this.tboxDiagnosis.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tboxDiagnosis.BackColor = System.Drawing.Color.White;
            this.tboxDiagnosis.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tboxDiagnosis.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tboxDiagnosis.Location = new System.Drawing.Point(40, 88);
            this.tboxDiagnosis.Multiline = true;
            this.tboxDiagnosis.Name = "tboxDiagnosis";
            this.tboxDiagnosis.ReadOnly = true;
            this.tboxDiagnosis.Size = new System.Drawing.Size(437, 33);
            this.tboxDiagnosis.TabIndex = 58;
            this.tboxDiagnosis.Text = "诊断结果";
            this.toolTip1.SetToolTip(this.tboxDiagnosis, "诊断结果");
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label23.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.ForeColor = System.Drawing.Color.Silver;
            this.label23.Location = new System.Drawing.Point(5, 90);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(29, 12);
            this.label23.TabIndex = 60;
            this.label23.Text = "诊断";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.lblBedNo);
            this.panel2.Controls.Add(this.lblPatient);
            this.panel2.Controls.Add(this.lblSex);
            this.panel2.Controls.Add(this.lblAge);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.lblHeight);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.tboxDiagnosis);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.lblCaseID);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.lblWeight);
            this.panel2.Controls.Add(this.lblDoctor);
            this.panel2.Controls.Add(this.lblWard);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(482, 105);
            this.panel2.TabIndex = 61;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.ForeColor = System.Drawing.Color.Silver;
            this.label5.Location = new System.Drawing.Point(323, 66);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 62;
            this.label5.Text = "医生";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.ForeColor = System.Drawing.Color.Silver;
            this.label4.Location = new System.Drawing.Point(5, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 61;
            this.label4.Text = "病区";
            // 
            // lblHeight
            // 
            this.lblHeight.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHeight.BackColor = System.Drawing.Color.White;
            this.lblHeight.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblHeight.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblHeight.Location = new System.Drawing.Point(354, 43);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.ReadOnly = true;
            this.lblHeight.Size = new System.Drawing.Size(50, 16);
            this.lblHeight.TabIndex = 59;
            this.lblHeight.Text = "身高";
            this.toolTip1.SetToolTip(this.lblHeight, "患者身高");
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.Color.Silver;
            this.label2.Location = new System.Drawing.Point(252, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 58;
            this.label2.Text = "体重";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.Silver;
            this.label1.Location = new System.Drawing.Point(323, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 57;
            this.label1.Text = "身高";
            // 
            // btnRecheck
            // 
            this.btnRecheck.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnRecheck.Location = new System.Drawing.Point(6, 2);
            this.btnRecheck.Name = "btnRecheck";
            this.btnRecheck.Size = new System.Drawing.Size(61, 27);
            this.btnRecheck.TabIndex = 61;
            this.btnRecheck.Text = "重审";
            this.toolTip1.SetToolTip(this.btnRecheck, "重审");
            this.btnRecheck.UseVisualStyleBackColor = true;
            this.btnRecheck.Visible = false;
            this.btnRecheck.Click += new System.EventHandler(this.btnRecheck_Click);
            this.btnRecheck.MouseLeave += new System.EventHandler(this.btnRecheck_MouseLeave);
            // 
            // dgvDrugs
            // 
            this.dgvDrugs.AllowUserToAddRows = false;
            this.dgvDrugs.AllowUserToDeleteRows = false;
            this.dgvDrugs.AllowUserToResizeRows = false;
            this.dgvDrugs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDrugs.BackgroundColor = System.Drawing.Color.White;
            this.dgvDrugs.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDrugs.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDrugs.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDrugs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColDrugName,
            this.ColDrugSize,
            this.ColYongLiang,
            this.ColCount,
            this.ColPiShi,
            this.Remark7,
            this.ColUniPreparationID,
            this.ColRemark8,
            this.ColRemark9,
            this.ColRemark10,
            this.ColDrugCode});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDrugs.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvDrugs.Location = new System.Drawing.Point(0, 0);
            this.dgvDrugs.Margin = new System.Windows.Forms.Padding(0);
            this.dgvDrugs.Name = "dgvDrugs";
            this.dgvDrugs.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDrugs.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvDrugs.RowHeadersVisible = false;
            this.dgvDrugs.RowTemplate.Height = 23;
            this.dgvDrugs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvDrugs.Size = new System.Drawing.Size(482, 154);
            this.dgvDrugs.TabIndex = 63;
            this.toolTip1.SetToolTip(this.dgvDrugs, "处方中的药物");
            this.dgvDrugs.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDrugs_CellClick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Location = new System.Drawing.Point(5, 517);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(21, 23);
            this.panel1.TabIndex = 28;
            this.panel1.Visible = false;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label16.ForeColor = System.Drawing.Color.Gray;
            this.label16.Location = new System.Drawing.Point(415, 2);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(50, 17);
            this.label16.TabIndex = 3;
            this.label16.Text = "皮试";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label15.ForeColor = System.Drawing.Color.Gray;
            this.label15.Location = new System.Drawing.Point(363, 2);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(51, 17);
            this.label15.TabIndex = 2;
            this.label15.Text = "用量";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label14.ForeColor = System.Drawing.Color.Gray;
            this.label14.Location = new System.Drawing.Point(262, 2);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 17);
            this.label14.TabIndex = 1;
            this.label14.Text = "规格";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label12.ForeColor = System.Drawing.Color.Gray;
            this.label12.Location = new System.Drawing.Point(2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(259, 19);
            this.label12.TabIndex = 0;
            this.label12.Text = "药品名称";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.btnTuiDan);
            this.panel3.Controls.Add(this.linkLabel1);
            this.panel3.Controls.Add(this.lblBatch);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.lblCPtime);
            this.panel3.Controls.Add(this.lblEndDT);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.btnRecheck);
            this.panel3.Controls.Add(this.lblGroupNo);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.lblexplain);
            this.panel3.Controls.Add(this.lblCPer);
            this.panel3.Controls.Add(this.lblyongfa);
            this.panel3.Controls.Add(this.lblStartDT);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(482, 117);
            this.panel3.TabIndex = 68;
            // 
            // btnTuiDan
            // 
            this.btnTuiDan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTuiDan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnTuiDan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTuiDan.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnTuiDan.Location = new System.Drawing.Point(400, 6);
            this.btnTuiDan.Name = "btnTuiDan";
            this.btnTuiDan.Size = new System.Drawing.Size(75, 39);
            this.btnTuiDan.TabIndex = 80;
            this.btnTuiDan.Text = "退单";
            this.toolTip1.SetToolTip(this.btnTuiDan, "审方不合格处理");
            this.btnTuiDan.UseVisualStyleBackColor = false;
            this.btnTuiDan.Click += new System.EventHandler(this.btnTuiDan_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.linkLabel1.Location = new System.Drawing.Point(409, 91);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(53, 12);
            this.linkLabel1.TabIndex = 79;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "删除处方";
            this.linkLabel1.Click += new System.EventHandler(this.linkLabel1_Click);
            // 
            // lblBatch
            // 
            this.lblBatch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblBatch.BackColor = System.Drawing.Color.White;
            this.lblBatch.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblBatch.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblBatch.Location = new System.Drawing.Point(321, 93);
            this.lblBatch.Name = "lblBatch";
            this.lblBatch.ReadOnly = true;
            this.lblBatch.Size = new System.Drawing.Size(100, 16);
            this.lblBatch.TabIndex = 67;
            this.lblBatch.Text = "频次";
            this.toolTip1.SetToolTip(this.lblBatch, "频次");
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.ForeColor = System.Drawing.Color.Silver;
            this.label13.Location = new System.Drawing.Point(274, 96);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 60;
            this.label13.Text = "频次：";
            // 
            // lblCPtime
            // 
            this.lblCPtime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCPtime.BackColor = System.Drawing.Color.White;
            this.lblCPtime.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblCPtime.Location = new System.Drawing.Point(289, 51);
            this.lblCPtime.Name = "lblCPtime";
            this.lblCPtime.ReadOnly = true;
            this.lblCPtime.Size = new System.Drawing.Size(181, 14);
            this.lblCPtime.TabIndex = 70;
            this.lblCPtime.Text = "审方时间";
            this.toolTip1.SetToolTip(this.lblCPtime, "审方时间");
            // 
            // lblEndDT
            // 
            this.lblEndDT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEndDT.BackColor = System.Drawing.Color.White;
            this.lblEndDT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblEndDT.Location = new System.Drawing.Point(288, 31);
            this.lblEndDT.Name = "lblEndDT";
            this.lblEndDT.ReadOnly = true;
            this.lblEndDT.Size = new System.Drawing.Size(109, 14);
            this.lblEndDT.TabIndex = 66;
            this.lblEndDT.Text = "停止日期";
            this.toolTip1.SetToolTip(this.lblEndDT, "医嘱停止日期");
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.White;
            this.label20.ForeColor = System.Drawing.Color.Silver;
            this.label20.Location = new System.Drawing.Point(172, 51);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(119, 12);
            this.label20.TabIndex = 64;
            this.label20.Text = "系统/人工审方时间：";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.ForeColor = System.Drawing.Color.Silver;
            this.label7.Location = new System.Drawing.Point(226, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 58;
            this.label7.Text = "停止日期：";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label6.Location = new System.Drawing.Point(5, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(469, 1);
            this.label6.TabIndex = 74;
            // 
            // lblGroupNo
            // 
            this.lblGroupNo.BackColor = System.Drawing.Color.White;
            this.lblGroupNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblGroupNo.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblGroupNo.Location = new System.Drawing.Point(73, 6);
            this.lblGroupNo.Name = "lblGroupNo";
            this.lblGroupNo.ReadOnly = true;
            this.lblGroupNo.Size = new System.Drawing.Size(226, 19);
            this.lblGroupNo.TabIndex = 73;
            this.lblGroupNo.Text = "组号";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.White;
            this.label21.ForeColor = System.Drawing.Color.Silver;
            this.label21.Location = new System.Drawing.Point(16, 8);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 12);
            this.label21.TabIndex = 72;
            this.label21.Text = "医嘱号：";
            this.label21.MouseHover += new System.EventHandler(this.label21_MouseHover);
            // 
            // lblexplain
            // 
            this.lblexplain.BackColor = System.Drawing.Color.White;
            this.lblexplain.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblexplain.Location = new System.Drawing.Point(67, 72);
            this.lblexplain.Name = "lblexplain";
            this.lblexplain.ReadOnly = true;
            this.lblexplain.Size = new System.Drawing.Size(385, 14);
            this.lblexplain.TabIndex = 71;
            this.lblexplain.Text = "医师意见";
            this.toolTip1.SetToolTip(this.lblexplain, "药师意见");
            // 
            // lblCPer
            // 
            this.lblCPer.BackColor = System.Drawing.Color.White;
            this.lblCPer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblCPer.Location = new System.Drawing.Point(68, 52);
            this.lblCPer.Name = "lblCPer";
            this.lblCPer.ReadOnly = true;
            this.lblCPer.Size = new System.Drawing.Size(98, 14);
            this.lblCPer.TabIndex = 69;
            this.lblCPer.Text = "审方人";
            this.toolTip1.SetToolTip(this.lblCPer, "审方人");
            // 
            // lblyongfa
            // 
            this.lblyongfa.BackColor = System.Drawing.Color.White;
            this.lblyongfa.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblyongfa.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblyongfa.Location = new System.Drawing.Point(73, 92);
            this.lblyongfa.Name = "lblyongfa";
            this.lblyongfa.ReadOnly = true;
            this.lblyongfa.Size = new System.Drawing.Size(100, 16);
            this.lblyongfa.TabIndex = 68;
            this.lblyongfa.Text = "用法";
            this.toolTip1.SetToolTip(this.lblyongfa, "用法");
            // 
            // lblStartDT
            // 
            this.lblStartDT.BackColor = System.Drawing.Color.White;
            this.lblStartDT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblStartDT.Location = new System.Drawing.Point(68, 31);
            this.lblStartDT.Name = "lblStartDT";
            this.lblStartDT.ReadOnly = true;
            this.lblStartDT.Size = new System.Drawing.Size(120, 14);
            this.lblStartDT.TabIndex = 65;
            this.lblStartDT.Text = "开始日期";
            this.toolTip1.SetToolTip(this.lblStartDT, "医嘱开始日期");
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.ForeColor = System.Drawing.Color.Silver;
            this.label19.Location = new System.Drawing.Point(16, 51);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 63;
            this.label19.Text = "审方人：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.ForeColor = System.Drawing.Color.Silver;
            this.label9.Location = new System.Drawing.Point(4, 72);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 12);
            this.label9.TabIndex = 62;
            this.label9.Text = "医师意见：";
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.ForeColor = System.Drawing.Color.Silver;
            this.label18.Location = new System.Drawing.Point(28, 94);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 12);
            this.label18.TabIndex = 61;
            this.label18.Text = "用法：";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.ForeColor = System.Drawing.Color.Silver;
            this.label8.Location = new System.Drawing.Point(4, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 12);
            this.label8.TabIndex = 59;
            this.label8.Text = "开始日期：";
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.BackColor = System.Drawing.Color.DarkGray;
            this.label11.Location = new System.Drawing.Point(0, 140);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(482, 2);
            this.label11.TabIndex = 69;
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.BackColor = System.Drawing.Color.DarkGray;
            this.label17.Location = new System.Drawing.Point(0, 300);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(482, 2);
            this.label17.TabIndex = 70;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.splitContainer1.Location = new System.Drawing.Point(0, 117);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dgvDrugs);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.pnlInfo);
            this.splitContainer1.Size = new System.Drawing.Size(483, 317);
            this.splitContainer1.SplitterDistance = 156;
            this.splitContainer1.SplitterWidth = 1;
            this.splitContainer1.TabIndex = 71;
            this.splitContainer1.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitContainer1_SplitterMoved);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.panel2);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.panel3);
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer1);
            this.splitContainer2.Size = new System.Drawing.Size(484, 541);
            this.splitContainer2.SplitterDistance = 106;
            this.splitContainer2.SplitterWidth = 1;
            this.splitContainer2.TabIndex = 63;
            // 
            // ColDrugName
            // 
            this.ColDrugName.HeaderText = "药品名称";
            this.ColDrugName.MinimumWidth = 168;
            this.ColDrugName.Name = "ColDrugName";
            this.ColDrugName.ReadOnly = true;
            this.ColDrugName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ColDrugName.Width = 168;
            // 
            // ColDrugSize
            // 
            this.ColDrugSize.HeaderText = "规格";
            this.ColDrugSize.Name = "ColDrugSize";
            this.ColDrugSize.ReadOnly = true;
            this.ColDrugSize.Width = 90;
            // 
            // ColYongLiang
            // 
            this.ColYongLiang.HeaderText = "用量";
            this.ColYongLiang.Name = "ColYongLiang";
            this.ColYongLiang.ReadOnly = true;
            this.ColYongLiang.Width = 60;
            // 
            // ColCount
            // 
            this.ColCount.HeaderText = "数量";
            this.ColCount.Name = "ColCount";
            this.ColCount.ReadOnly = true;
            // 
            // ColPiShi
            // 
            this.ColPiShi.HeaderText = "皮试";
            this.ColPiShi.Name = "ColPiShi";
            this.ColPiShi.ReadOnly = true;
            this.ColPiShi.Width = 59;
            // 
            // Remark7
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.Remark7.DefaultCellStyle = dataGridViewCellStyle2;
            this.Remark7.HeaderText = "备注7";
            this.Remark7.Name = "Remark7";
            this.Remark7.ReadOnly = true;
            this.Remark7.Width = 120;
            // 
            // ColUniPreparationID
            // 
            this.ColUniPreparationID.HeaderText = "";
            this.ColUniPreparationID.Name = "ColUniPreparationID";
            this.ColUniPreparationID.ReadOnly = true;
            this.ColUniPreparationID.Visible = false;
            // 
            // ColRemark8
            // 
            this.ColRemark8.HeaderText = "备注8";
            this.ColRemark8.Name = "ColRemark8";
            this.ColRemark8.ReadOnly = true;
            // 
            // ColRemark9
            // 
            this.ColRemark9.HeaderText = "备注9";
            this.ColRemark9.Name = "ColRemark9";
            this.ColRemark9.ReadOnly = true;
            // 
            // ColRemark10
            // 
            this.ColRemark10.HeaderText = "备注10";
            this.ColRemark10.Name = "ColRemark10";
            this.ColRemark10.ReadOnly = true;
            // 
            // ColDrugCode
            // 
            this.ColDrugCode.HeaderText = "药品编号";
            this.ColDrugCode.Name = "ColDrugCode";
            this.ColDrugCode.ReadOnly = true;
            this.ColDrugCode.Visible = false;
            // 
            // Information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Controls.Add(this.splitContainer2);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "Information";
            this.Size = new System.Drawing.Size(483, 543);
            this.Load += new System.EventHandler(this.Information_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDrugs)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.FlowLayoutPanel pnlInfo;
        private System.Windows.Forms.TextBox lblDoctor;
        private System.Windows.Forms.TextBox lblPatient;
        private System.Windows.Forms.TextBox lblWard;
        private System.Windows.Forms.TextBox lblAge;
        private System.Windows.Forms.TextBox lblWeight;
        private System.Windows.Forms.TextBox lblBedNo;
        private System.Windows.Forms.TextBox lblSex;
        private System.Windows.Forms.TextBox lblCaseID;
        private System.Windows.Forms.TextBox tboxDiagnosis;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox lblHeight;
        private System.Windows.Forms.Button btnRecheck;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox lblGroupNo;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox lblexplain;
        private System.Windows.Forms.TextBox lblCPtime;
        private System.Windows.Forms.TextBox lblCPer;
        private System.Windows.Forms.TextBox lblyongfa;
        private System.Windows.Forms.TextBox lblBatch;
        private System.Windows.Forms.TextBox lblEndDT;
        private System.Windows.Forms.TextBox lblStartDT;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ToolTip toolTip1;
        public System.Windows.Forms.DataGridView dgvDrugs;
        public System.Windows.Forms.LinkLabel linkLabel1;
        public System.Windows.Forms.Button btnTuiDan;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColDrugName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColDrugSize;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColYongLiang;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColPiShi;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remark7;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColUniPreparationID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColRemark8;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColRemark9;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColRemark10;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColDrugCode;
    }
}
