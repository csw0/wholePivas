USE [Pivas2013]
GO

/****** Object:  View [dbo].[Customcode]    Script Date: 02/13/2014 15:23:37 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[Customcode]'))
DROP VIEW [dbo].[Customcode]
GO

USE [Pivas2013]
GO

/****** Object:  View [dbo].[Customcode]    Script Date: 02/13/2014 15:23:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create view [dbo].[CustomCode]
as select [DrugCode] CustomCode
      ,[DrugName] CustomName
      ,[DrugNameJC]
      ,[Spec]
      ,[Dosage]
      ,[DosageUnit]
      ,[Major]
      ,[MajorUnit]
      ,[Capacity]
      ,[CapacityUnit]
      ,[Form]
      ,[FormUnit]
      ,[Conversion]
      ,[SpellCode]
      ,[UniPreparationID]
      ,[IsMenstruum]
      ,[withmenstruum]
      ,[PreConfigure]
      ,[PiShi]
      ,[NotCompound]
      ,[Precious]
      ,[AsMajorDrug]
      ,[BigUnit]
      ,[PortNo]
      ,[Symbol]
      ,[IsValid]
      ,[Difficulty]
      ,[Species]
      ,[Positions1]
      ,[Positions2]
      ,[NoName] from DDrug
GO


