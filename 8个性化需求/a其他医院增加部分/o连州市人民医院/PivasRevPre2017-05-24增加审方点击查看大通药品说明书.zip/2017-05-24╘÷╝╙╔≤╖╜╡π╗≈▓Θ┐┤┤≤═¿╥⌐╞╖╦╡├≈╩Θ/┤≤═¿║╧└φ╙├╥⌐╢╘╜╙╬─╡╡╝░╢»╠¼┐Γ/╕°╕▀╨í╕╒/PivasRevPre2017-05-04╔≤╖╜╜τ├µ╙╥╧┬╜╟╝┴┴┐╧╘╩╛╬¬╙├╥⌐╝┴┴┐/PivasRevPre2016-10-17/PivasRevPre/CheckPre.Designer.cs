﻿namespace PivasRevPre
{
    partial class CheckPre
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlTitle = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.DT = new System.Windows.Forms.DateTimePicker();
            this.btnhistory = new System.Windows.Forms.Button();
            this.btnPass = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.ckBoxZhong = new System.Windows.Forms.CheckBox();
            this.ckBoxYin = new System.Windows.Forms.CheckBox();
            this.ckBoxPu = new System.Windows.Forms.CheckBox();
            this.ckBoxKang = new System.Windows.Forms.CheckBox();
            this.ckBoxHua = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.pnlHongqi = new System.Windows.Forms.Panel();
            this.pnlbaiqi = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.CPType = new System.Windows.Forms.ComboBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.SysType = new System.Windows.Forms.ComboBox();
            this.pnlPER = new System.Windows.Forms.Panel();
            this.lblPerTui = new System.Windows.Forms.Label();
            this.lblPerYi = new System.Windows.Forms.Label();
            this.lblPerWei = new System.Windows.Forms.Label();
            this.lblPerWeiAndTui = new System.Windows.Forms.Label();
            this.pnlSYS = new System.Windows.Forms.Panel();
            this.lblSysUnPass = new System.Windows.Forms.Label();
            this.lblSysPass = new System.Windows.Forms.Label();
            this.lblSysAll = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.PreType = new System.Windows.Forms.ComboBox();
            this.lblLingCount = new System.Windows.Forms.Label();
            this.chkBoxSTShort = new System.Windows.Forms.CheckBox();
            this.lblLongCount = new System.Windows.Forms.Label();
            this.chkBoxStLong = new System.Windows.Forms.CheckBox();
            this.cbbPer = new System.Windows.Forms.ComboBox();
            this.cbbSys = new System.Windows.Forms.ComboBox();
            this.pnlTable = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.dgvResult = new System.Windows.Forms.DataGridView();
            this.RowNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Care = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Check = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.IsPass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvSysResult = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WardName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BedNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PatName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GroupNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StartDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.InceptDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DoctorExplain = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remark1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remark2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remark3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remark4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remark5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remark6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rev1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.PrescriptionID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Level = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PatientCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rev2 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlUp = new System.Windows.Forms.Panel();
            this.med1 = new PivasRevPre.Med();
            this.information1 = new PivasRevPre.Information();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlDetail = new System.Windows.Forms.Panel();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewImageColumn2 = new System.Windows.Forms.DataGridViewImageColumn();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.ckBoxSelAll = new System.Windows.Forms.CheckBox();
            this.lblUnchecks = new System.Windows.Forms.Label();
            this.lblAllChecks = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.txtWard = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cmBoxWardArea = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtName = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dgvWards = new System.Windows.Forms.DataGridView();
            this.cbBoxSel = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colWardCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colWardName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colUnchecks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAllChecks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pnlTitle.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel9.SuspendLayout();
            this.pnlPER.SuspendLayout();
            this.pnlSYS.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel8.SuspendLayout();
            this.pnlTable.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWards)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTitle
            // 
            this.pnlTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(210)))), ((int)(((byte)(251)))));
            this.pnlTitle.Controls.Add(this.panel3);
            this.pnlTitle.Controls.Add(this.btnPass);
            this.pnlTitle.Controls.Add(this.panel6);
            this.pnlTitle.Controls.Add(this.button2);
            this.pnlTitle.Controls.Add(this.pnlHongqi);
            this.pnlTitle.Controls.Add(this.pnlbaiqi);
            this.pnlTitle.Controls.Add(this.label1);
            this.pnlTitle.Controls.Add(this.txtSearch);
            this.pnlTitle.Controls.Add(this.checkBox1);
            this.pnlTitle.Controls.Add(this.panel4);
            this.pnlTitle.Controls.Add(this.panel10);
            this.pnlTitle.Location = new System.Drawing.Point(199, 0);
            this.pnlTitle.Name = "pnlTitle";
            this.pnlTitle.Size = new System.Drawing.Size(920, 49);
            this.pnlTitle.TabIndex = 6;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.DT);
            this.panel3.Controls.Add(this.btnhistory);
            this.panel3.Location = new System.Drawing.Point(668, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(250, 45);
            this.panel3.TabIndex = 215;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(131, 6);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(40, 33);
            this.button3.TabIndex = 207;
            this.button3.Text = "医嘱同步";
            this.toolTip1.SetToolTip(this.button3, "快捷医嘱同步");
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Image = global::PivasRevPre.Properties.Resources.gear_16;
            this.button1.Location = new System.Drawing.Point(209, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(40, 33);
            this.button1.TabIndex = 206;
            this.toolTip1.SetToolTip(this.button1, "设置");
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnSet_Click);
            // 
            // DT
            // 
            this.DT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DT.CalendarFont = new System.Drawing.Font("宋体", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DT.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DT.CustomFormat = "yyyy-MM-dd";
            this.DT.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DT.Location = new System.Drawing.Point(3, 8);
            this.DT.Name = "DT";
            this.DT.Size = new System.Drawing.Size(127, 29);
            this.DT.TabIndex = 6;
            this.toolTip1.SetToolTip(this.DT, "日期选择");
            this.DT.Value = new System.DateTime(2014, 7, 1, 17, 5, 26, 0);
            this.DT.CloseUp += new System.EventHandler(this.DT_CloseUp);
            // 
            // btnhistory
            // 
            this.btnhistory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnhistory.Location = new System.Drawing.Point(170, 6);
            this.btnhistory.Name = "btnhistory";
            this.btnhistory.Size = new System.Drawing.Size(40, 33);
            this.btnhistory.TabIndex = 205;
            this.btnhistory.Text = "历史医嘱";
            this.toolTip1.SetToolTip(this.btnhistory, "历史医嘱查询");
            this.btnhistory.UseVisualStyleBackColor = true;
            this.btnhistory.Click += new System.EventHandler(this.btnhistory_Click);
            // 
            // btnPass
            // 
            this.btnPass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnPass.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnPass.Location = new System.Drawing.Point(191, 1);
            this.btnPass.Name = "btnPass";
            this.btnPass.Size = new System.Drawing.Size(62, 46);
            this.btnPass.TabIndex = 3;
            this.btnPass.Text = "通过";
            this.toolTip1.SetToolTip(this.btnPass, "人工通过（处方）");
            this.btnPass.UseVisualStyleBackColor = false;
            this.btnPass.Click += new System.EventHandler(this.btnPass_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.ckBoxZhong);
            this.panel6.Controls.Add(this.ckBoxYin);
            this.panel6.Controls.Add(this.ckBoxPu);
            this.panel6.Controls.Add(this.ckBoxKang);
            this.panel6.Controls.Add(this.ckBoxHua);
            this.panel6.Location = new System.Drawing.Point(1, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(186, 21);
            this.panel6.TabIndex = 16;
            // 
            // ckBoxZhong
            // 
            this.ckBoxZhong.AutoSize = true;
            this.ckBoxZhong.Checked = true;
            this.ckBoxZhong.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckBoxZhong.Location = new System.Drawing.Point(149, 2);
            this.ckBoxZhong.Name = "ckBoxZhong";
            this.ckBoxZhong.Size = new System.Drawing.Size(36, 16);
            this.ckBoxZhong.TabIndex = 213;
            this.ckBoxZhong.Text = "中";
            this.toolTip1.SetToolTip(this.ckBoxZhong, "中药筛选");
            this.ckBoxZhong.UseVisualStyleBackColor = true;
            this.ckBoxZhong.CheckedChanged += new System.EventHandler(this.ckBoxPu_CheckedChanged);
            // 
            // ckBoxYin
            // 
            this.ckBoxYin.AutoSize = true;
            this.ckBoxYin.Checked = true;
            this.ckBoxYin.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckBoxYin.Location = new System.Drawing.Point(113, 3);
            this.ckBoxYin.Name = "ckBoxYin";
            this.ckBoxYin.Size = new System.Drawing.Size(36, 16);
            this.ckBoxYin.TabIndex = 212;
            this.ckBoxYin.Text = "营";
            this.toolTip1.SetToolTip(this.ckBoxYin, "营养药物筛选");
            this.ckBoxYin.UseVisualStyleBackColor = true;
            this.ckBoxYin.CheckedChanged += new System.EventHandler(this.ckBoxPu_CheckedChanged);
            // 
            // ckBoxPu
            // 
            this.ckBoxPu.AutoSize = true;
            this.ckBoxPu.Checked = true;
            this.ckBoxPu.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckBoxPu.Location = new System.Drawing.Point(6, 3);
            this.ckBoxPu.Name = "ckBoxPu";
            this.ckBoxPu.Size = new System.Drawing.Size(36, 16);
            this.ckBoxPu.TabIndex = 209;
            this.ckBoxPu.Text = "普";
            this.toolTip1.SetToolTip(this.ckBoxPu, "普通药物筛选");
            this.ckBoxPu.UseVisualStyleBackColor = true;
            this.ckBoxPu.CheckedChanged += new System.EventHandler(this.ckBoxPu_CheckedChanged);
            // 
            // ckBoxKang
            // 
            this.ckBoxKang.AutoSize = true;
            this.ckBoxKang.Checked = true;
            this.ckBoxKang.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckBoxKang.Location = new System.Drawing.Point(42, 3);
            this.ckBoxKang.Name = "ckBoxKang";
            this.ckBoxKang.Size = new System.Drawing.Size(36, 16);
            this.ckBoxKang.TabIndex = 210;
            this.ckBoxKang.Text = "抗";
            this.toolTip1.SetToolTip(this.ckBoxKang, "抗肿瘤药物筛选");
            this.ckBoxKang.UseVisualStyleBackColor = true;
            this.ckBoxKang.CheckedChanged += new System.EventHandler(this.ckBoxPu_CheckedChanged);
            // 
            // ckBoxHua
            // 
            this.ckBoxHua.AutoSize = true;
            this.ckBoxHua.Checked = true;
            this.ckBoxHua.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckBoxHua.Location = new System.Drawing.Point(78, 3);
            this.ckBoxHua.Name = "ckBoxHua";
            this.ckBoxHua.Size = new System.Drawing.Size(36, 16);
            this.ckBoxHua.TabIndex = 211;
            this.ckBoxHua.Text = "化";
            this.toolTip1.SetToolTip(this.ckBoxHua, "化疗药物筛选");
            this.ckBoxHua.UseVisualStyleBackColor = true;
            this.ckBoxHua.CheckedChanged += new System.EventHandler(this.ckBoxPu_CheckedChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1, 25);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(46, 23);
            this.button2.TabIndex = 216;
            this.button2.Text = "刷新";
            this.toolTip1.SetToolTip(this.button2, "画面刷新");
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.lblFlush_Click);
            this.button2.MouseLeave += new System.EventHandler(this.button2_MouseLeave);
            // 
            // pnlHongqi
            // 
            this.pnlHongqi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlHongqi.BackgroundImage = global::PivasRevPre.Properties.Resources._1;
            this.pnlHongqi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnlHongqi.Location = new System.Drawing.Point(48, 28);
            this.pnlHongqi.Name = "pnlHongqi";
            this.pnlHongqi.Size = new System.Drawing.Size(15, 18);
            this.pnlHongqi.TabIndex = 12;
            this.toolTip1.SetToolTip(this.pnlHongqi, "加关注");
            this.pnlHongqi.Visible = false;
            this.pnlHongqi.Click += new System.EventHandler(this.panel2_Click);
            // 
            // pnlbaiqi
            // 
            this.pnlbaiqi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlbaiqi.BackgroundImage = global::PivasRevPre.Properties.Resources._2;
            this.pnlbaiqi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnlbaiqi.Location = new System.Drawing.Point(48, 28);
            this.pnlbaiqi.Name = "pnlbaiqi";
            this.pnlbaiqi.Size = new System.Drawing.Size(15, 18);
            this.pnlbaiqi.TabIndex = 204;
            this.pnlbaiqi.Visible = false;
            this.pnlbaiqi.Click += new System.EventHandler(this.pnlbaiqi_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(7, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 12);
            this.label1.TabIndex = 203;
            this.label1.Text = "180";
            this.label1.MouseHover += new System.EventHandler(this.label1_MouseHover);
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.txtSearch.ForeColor = System.Drawing.Color.Gray;
            this.txtSearch.Location = new System.Drawing.Point(255, 25);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(134, 21);
            this.txtSearch.TabIndex = 200;
            this.txtSearch.Text = "患者姓名/住院号/床号";
            this.toolTip1.SetToolTip(this.txtSearch, "查询");
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            this.txtSearch.DoubleClick += new System.EventHandler(this.txtSearch_DoubleClick);
            this.txtSearch.Enter += new System.EventHandler(this.txtSearch_Enter);
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            this.txtSearch.Leave += new System.EventHandler(this.txtSearch_Leave);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(77, 28);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(48, 16);
            this.checkBox1.TabIndex = 1;
            this.checkBox1.Text = "全选";
            this.toolTip1.SetToolTip(this.checkBox1, "全选所有处方");
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.Click += new System.EventHandler(this.checkBox1_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.panel9);
            this.panel4.Controls.Add(this.pnlPER);
            this.panel4.Controls.Add(this.pnlSYS);
            this.panel4.Location = new System.Drawing.Point(397, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(316, 54);
            this.panel4.TabIndex = 214;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.label4);
            this.panel7.Controls.Add(this.CPType);
            this.panel7.Location = new System.Drawing.Point(18, 21);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(190, 26);
            this.panel7.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "人工审方";
            // 
            // CPType
            // 
            this.CPType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CPType.FormattingEnabled = true;
            this.CPType.Items.AddRange(new object[] {
            "人工未审/退单",
            "人工未审",
            "人工已审",
            "人工退单"});
            this.CPType.Location = new System.Drawing.Point(64, 3);
            this.CPType.Name = "CPType";
            this.CPType.Size = new System.Drawing.Size(113, 20);
            this.CPType.TabIndex = 1;
            this.CPType.SelectionChangeCommitted += new System.EventHandler(this.CPType_SelectionChangeCommitted);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.label3);
            this.panel9.Controls.Add(this.SysType);
            this.panel9.Location = new System.Drawing.Point(17, -2);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(190, 25);
            this.panel9.TabIndex = 18;
            this.panel9.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "系统审方";
            // 
            // SysType
            // 
            this.SysType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SysType.FormattingEnabled = true;
            this.SysType.Items.AddRange(new object[] {
            "系统全部",
            "系统通过",
            "系统未过"});
            this.SysType.Location = new System.Drawing.Point(65, 2);
            this.SysType.Name = "SysType";
            this.SysType.Size = new System.Drawing.Size(113, 20);
            this.SysType.TabIndex = 0;
            this.SysType.SelectionChangeCommitted += new System.EventHandler(this.SysType_SelectionChangeCommitted);
            // 
            // pnlPER
            // 
            this.pnlPER.Controls.Add(this.lblPerTui);
            this.pnlPER.Controls.Add(this.lblPerYi);
            this.pnlPER.Controls.Add(this.lblPerWei);
            this.pnlPER.Controls.Add(this.lblPerWeiAndTui);
            this.pnlPER.Location = new System.Drawing.Point(16, 24);
            this.pnlPER.Name = "pnlPER";
            this.pnlPER.Size = new System.Drawing.Size(293, 23);
            this.pnlPER.TabIndex = 214;
            // 
            // lblPerTui
            // 
            this.lblPerTui.AutoSize = true;
            this.lblPerTui.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblPerTui.ForeColor = System.Drawing.Color.Black;
            this.lblPerTui.Location = new System.Drawing.Point(236, 6);
            this.lblPerTui.Name = "lblPerTui";
            this.lblPerTui.Size = new System.Drawing.Size(53, 12);
            this.lblPerTui.TabIndex = 3;
            this.lblPerTui.Text = "人工退单";
            this.toolTip1.SetToolTip(this.lblPerTui, "人工退单的处方");
            this.lblPerTui.Click += new System.EventHandler(this.lblPerWei_Click);
            // 
            // lblPerYi
            // 
            this.lblPerYi.AutoSize = true;
            this.lblPerYi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblPerYi.ForeColor = System.Drawing.Color.Black;
            this.lblPerYi.Location = new System.Drawing.Point(167, 6);
            this.lblPerYi.Name = "lblPerYi";
            this.lblPerYi.Size = new System.Drawing.Size(53, 12);
            this.lblPerYi.TabIndex = 2;
            this.lblPerYi.Text = "人工已审";
            this.toolTip1.SetToolTip(this.lblPerYi, "人工已审的处方");
            this.lblPerYi.Click += new System.EventHandler(this.lblPerWei_Click);
            // 
            // lblPerWei
            // 
            this.lblPerWei.AutoSize = true;
            this.lblPerWei.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblPerWei.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblPerWei.ForeColor = System.Drawing.Color.Blue;
            this.lblPerWei.Location = new System.Drawing.Point(98, 6);
            this.lblPerWei.Name = "lblPerWei";
            this.lblPerWei.Size = new System.Drawing.Size(53, 12);
            this.lblPerWei.TabIndex = 1;
            this.lblPerWei.Text = "人工未审";
            this.toolTip1.SetToolTip(this.lblPerWei, "人工未审的处方");
            this.lblPerWei.Click += new System.EventHandler(this.lblPerWei_Click);
            // 
            // lblPerWeiAndTui
            // 
            this.lblPerWeiAndTui.AutoSize = true;
            this.lblPerWeiAndTui.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblPerWeiAndTui.ForeColor = System.Drawing.Color.Black;
            this.lblPerWeiAndTui.Location = new System.Drawing.Point(3, 6);
            this.lblPerWeiAndTui.Name = "lblPerWeiAndTui";
            this.lblPerWeiAndTui.Size = new System.Drawing.Size(83, 12);
            this.lblPerWeiAndTui.TabIndex = 0;
            this.lblPerWeiAndTui.Text = "人工未审/退单";
            this.toolTip1.SetToolTip(this.lblPerWeiAndTui, "显示人工未审/退单的处方");
            this.lblPerWeiAndTui.Click += new System.EventHandler(this.lblPerWei_Click);
            // 
            // pnlSYS
            // 
            this.pnlSYS.Controls.Add(this.lblSysUnPass);
            this.pnlSYS.Controls.Add(this.lblSysPass);
            this.pnlSYS.Controls.Add(this.lblSysAll);
            this.pnlSYS.Location = new System.Drawing.Point(16, 1);
            this.pnlSYS.Name = "pnlSYS";
            this.pnlSYS.Size = new System.Drawing.Size(289, 23);
            this.pnlSYS.TabIndex = 17;
            // 
            // lblSysUnPass
            // 
            this.lblSysUnPass.AutoSize = true;
            this.lblSysUnPass.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSysUnPass.ForeColor = System.Drawing.Color.Black;
            this.lblSysUnPass.Location = new System.Drawing.Point(157, 6);
            this.lblSysUnPass.Name = "lblSysUnPass";
            this.lblSysUnPass.Size = new System.Drawing.Size(53, 12);
            this.lblSysUnPass.TabIndex = 2;
            this.lblSysUnPass.Text = "系统未过";
            this.toolTip1.SetToolTip(this.lblSysUnPass, "只显示系统未过的处方");
            this.lblSysUnPass.Click += new System.EventHandler(this.lblSysAll_Click);
            // 
            // lblSysPass
            // 
            this.lblSysPass.AutoSize = true;
            this.lblSysPass.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSysPass.ForeColor = System.Drawing.Color.Black;
            this.lblSysPass.Location = new System.Drawing.Point(79, 6);
            this.lblSysPass.Name = "lblSysPass";
            this.lblSysPass.Size = new System.Drawing.Size(53, 12);
            this.lblSysPass.TabIndex = 1;
            this.lblSysPass.Text = "系统通过";
            this.toolTip1.SetToolTip(this.lblSysPass, "只显示系统通过的处方");
            this.lblSysPass.Click += new System.EventHandler(this.lblSysAll_Click);
            // 
            // lblSysAll
            // 
            this.lblSysAll.AutoSize = true;
            this.lblSysAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSysAll.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblSysAll.ForeColor = System.Drawing.Color.Blue;
            this.lblSysAll.Location = new System.Drawing.Point(3, 6);
            this.lblSysAll.Name = "lblSysAll";
            this.lblSysAll.Size = new System.Drawing.Size(53, 12);
            this.lblSysAll.TabIndex = 0;
            this.lblSysAll.Text = "系统全部";
            this.toolTip1.SetToolTip(this.lblSysAll, "系统全部的处方 ");
            this.lblSysAll.Click += new System.EventHandler(this.lblSysAll_Click);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.panel8);
            this.panel10.Controls.Add(this.lblLingCount);
            this.panel10.Controls.Add(this.chkBoxSTShort);
            this.panel10.Controls.Add(this.lblLongCount);
            this.panel10.Controls.Add(this.chkBoxStLong);
            this.panel10.Location = new System.Drawing.Point(252, 1);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(146, 25);
            this.panel10.TabIndex = 19;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(210)))), ((int)(((byte)(251)))));
            this.panel8.Controls.Add(this.PreType);
            this.panel8.Location = new System.Drawing.Point(7, 1);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(137, 24);
            this.panel8.TabIndex = 16;
            // 
            // PreType
            // 
            this.PreType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PreType.FormattingEnabled = true;
            this.PreType.Items.AddRange(new object[] {
            "全部",
            "长期",
            "临时"});
            this.PreType.Location = new System.Drawing.Point(2, 1);
            this.PreType.Name = "PreType";
            this.PreType.Size = new System.Drawing.Size(134, 20);
            this.PreType.TabIndex = 0;
            this.PreType.SelectionChangeCommitted += new System.EventHandler(this.PreType_SelectionChangeCommitted);
            // 
            // lblLingCount
            // 
            this.lblLingCount.AutoSize = true;
            this.lblLingCount.Font = new System.Drawing.Font("宋体", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblLingCount.ForeColor = System.Drawing.Color.Red;
            this.lblLingCount.Location = new System.Drawing.Point(119, 12);
            this.lblLingCount.Name = "lblLingCount";
            this.lblLingCount.Size = new System.Drawing.Size(25, 10);
            this.lblLingCount.TabIndex = 218;
            this.lblLingCount.Text = "9999";
            this.toolTip1.SetToolTip(this.lblLingCount, "当日未审临时医嘱");
            // 
            // chkBoxSTShort
            // 
            this.chkBoxSTShort.AutoSize = true;
            this.chkBoxSTShort.Checked = true;
            this.chkBoxSTShort.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkBoxSTShort.Location = new System.Drawing.Point(77, 6);
            this.chkBoxSTShort.Name = "chkBoxSTShort";
            this.chkBoxSTShort.Size = new System.Drawing.Size(48, 16);
            this.chkBoxSTShort.TabIndex = 208;
            this.chkBoxSTShort.Text = "临时";
            this.toolTip1.SetToolTip(this.chkBoxSTShort, "临时医嘱");
            this.chkBoxSTShort.UseVisualStyleBackColor = true;
            this.chkBoxSTShort.CheckedChanged += new System.EventHandler(this.chkBoxSTShort_CheckedChanged);
            this.chkBoxSTShort.Click += new System.EventHandler(this.chkBoxSTShort_Click);
            // 
            // lblLongCount
            // 
            this.lblLongCount.AutoSize = true;
            this.lblLongCount.Font = new System.Drawing.Font("宋体", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblLongCount.ForeColor = System.Drawing.Color.Red;
            this.lblLongCount.Location = new System.Drawing.Point(51, 12);
            this.lblLongCount.Name = "lblLongCount";
            this.lblLongCount.Size = new System.Drawing.Size(25, 10);
            this.lblLongCount.TabIndex = 217;
            this.lblLongCount.Text = "9999";
            this.toolTip1.SetToolTip(this.lblLongCount, "当日未审长期医嘱");
            // 
            // chkBoxStLong
            // 
            this.chkBoxStLong.AutoSize = true;
            this.chkBoxStLong.Checked = true;
            this.chkBoxStLong.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkBoxStLong.Location = new System.Drawing.Point(6, 6);
            this.chkBoxStLong.Name = "chkBoxStLong";
            this.chkBoxStLong.Size = new System.Drawing.Size(48, 16);
            this.chkBoxStLong.TabIndex = 207;
            this.chkBoxStLong.Text = "长期";
            this.toolTip1.SetToolTip(this.chkBoxStLong, "长期医嘱");
            this.chkBoxStLong.UseVisualStyleBackColor = true;
            this.chkBoxStLong.CheckedChanged += new System.EventHandler(this.chkBoxStLong_CheckedChanged);
            this.chkBoxStLong.Click += new System.EventHandler(this.chkBoxStLong_Click);
            // 
            // cbbPer
            // 
            this.cbbPer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(210)))), ((int)(((byte)(250)))));
            this.cbbPer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbPer.FormattingEnabled = true;
            this.cbbPer.Items.AddRange(new object[] {
            "人工未审/退单",
            "人工未审",
            "人工已审",
            "人工退单"});
            this.cbbPer.Location = new System.Drawing.Point(97, 3);
            this.cbbPer.Name = "cbbPer";
            this.cbbPer.Size = new System.Drawing.Size(19, 20);
            this.cbbPer.TabIndex = 100;
            this.cbbPer.Visible = false;
            this.cbbPer.SelectionChangeCommitted += new System.EventHandler(this.cbbPer_SelectionChangeCommitted);
            // 
            // cbbSys
            // 
            this.cbbSys.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(210)))), ((int)(((byte)(250)))));
            this.cbbSys.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbSys.FormattingEnabled = true;
            this.cbbSys.Items.AddRange(new object[] {
            "系统全部",
            "系统通过",
            "系统未过"});
            this.cbbSys.Location = new System.Drawing.Point(73, 3);
            this.cbbSys.Name = "cbbSys";
            this.cbbSys.Size = new System.Drawing.Size(18, 20);
            this.cbbSys.TabIndex = 70;
            this.cbbSys.Visible = false;
            this.cbbSys.SelectionChangeCommitted += new System.EventHandler(this.cbbSys_SelectionChangeCommitted);
            // 
            // pnlTable
            // 
            this.pnlTable.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlTable.Controls.Add(this.splitContainer1);
            this.pnlTable.Location = new System.Drawing.Point(199, 48);
            this.pnlTable.Name = "pnlTable";
            this.pnlTable.Size = new System.Drawing.Size(958, 455);
            this.pnlTable.TabIndex = 16;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer1.Location = new System.Drawing.Point(0, 2);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dgvResult);
            this.splitContainer1.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.pnlUp);
            this.splitContainer1.Panel2.Controls.Add(this.med1);
            this.splitContainer1.Panel2.Controls.Add(this.information1);
            this.splitContainer1.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitContainer1.Panel2MinSize = 1;
            this.splitContainer1.Size = new System.Drawing.Size(918, 454);
            this.splitContainer1.SplitterDistance = 475;
            this.splitContainer1.SplitterWidth = 2;
            this.splitContainer1.TabIndex = 17;
            // 
            // dgvResult
            // 
            this.dgvResult.AllowUserToAddRows = false;
            this.dgvResult.AllowUserToDeleteRows = false;
            this.dgvResult.AllowUserToResizeRows = false;
            this.dgvResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvResult.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.dgvResult.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvResult.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(210)))), ((int)(((byte)(250)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvResult.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvResult.ColumnHeadersHeight = 20;
            this.dgvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.RowNum,
            this.Care,
            this.Check,
            this.IsPass,
            this.dgvSysResult,
            this.WardName,
            this.BedNo,
            this.PatName,
            this.GroupNo,
            this.StartDT,
            this.InceptDT,
            this.DoctorExplain,
            this.Remark1,
            this.Remark2,
            this.Remark3,
            this.Remark4,
            this.Remark5,
            this.Remark6,
            this.Rev1,
            this.PrescriptionID,
            this.Level,
            this.PatientCode,
            this.Rev2,
            this.Column2});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(200)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvResult.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvResult.GridColor = System.Drawing.Color.Gray;
            this.dgvResult.Location = new System.Drawing.Point(-1, -2);
            this.dgvResult.Margin = new System.Windows.Forms.Padding(0);
            this.dgvResult.MultiSelect = false;
            this.dgvResult.Name = "dgvResult";
            this.dgvResult.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(210)))), ((int)(((byte)(250)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvResult.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvResult.RowHeadersVisible = false;
            this.dgvResult.RowTemplate.Height = 30;
            this.dgvResult.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvResult.Size = new System.Drawing.Size(476, 456);
            this.dgvResult.TabIndex = 15;
            this.dgvResult.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvResult_CellClick);
            this.dgvResult.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvResult_CellMouseClick);
            this.dgvResult.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.dgvResult_RowPrePaint);
            this.dgvResult.Scroll += new System.Windows.Forms.ScrollEventHandler(this.dgvResult_Scroll);
            this.dgvResult.SizeChanged += new System.EventHandler(this.dgvResult_SizeChanged);
            this.dgvResult.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvResult_KeyUp);
            // 
            // RowNum
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.RowNum.DefaultCellStyle = dataGridViewCellStyle2;
            this.RowNum.HeaderText = "0";
            this.RowNum.Name = "RowNum";
            this.RowNum.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.RowNum.Width = 40;
            // 
            // Care
            // 
            this.Care.DataPropertyName = "Attention";
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Red;
            this.Care.DefaultCellStyle = dataGridViewCellStyle3;
            this.Care.HeaderText = "关注";
            this.Care.Name = "Care";
            this.Care.ReadOnly = true;
            this.Care.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Care.Width = 35;
            // 
            // Check
            // 
            this.Check.HeaderText = "";
            this.Check.Name = "Check";
            this.Check.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Check.Width = 30;
            // 
            // IsPass
            // 
            this.IsPass.DataPropertyName = "IsPass";
            this.IsPass.HeaderText = "结果";
            this.IsPass.Name = "IsPass";
            this.IsPass.ReadOnly = true;
            this.IsPass.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.IsPass.Visible = false;
            this.IsPass.Width = 80;
            // 
            // dgvSysResult
            // 
            this.dgvSysResult.DataPropertyName = "DoctorOperate";
            this.dgvSysResult.HeaderText = "结果";
            this.dgvSysResult.Name = "dgvSysResult";
            this.dgvSysResult.ReadOnly = true;
            // 
            // WardName
            // 
            this.WardName.DataPropertyName = "WardName";
            this.WardName.HeaderText = "病区名";
            this.WardName.Name = "WardName";
            this.WardName.ReadOnly = true;
            this.WardName.Width = 150;
            // 
            // BedNo
            // 
            this.BedNo.DataPropertyName = "BedNo";
            this.BedNo.HeaderText = "床号";
            this.BedNo.Name = "BedNo";
            this.BedNo.ReadOnly = true;
            this.BedNo.Width = 60;
            // 
            // PatName
            // 
            this.PatName.DataPropertyName = "PatName";
            this.PatName.HeaderText = "病人姓名";
            this.PatName.Name = "PatName";
            this.PatName.ReadOnly = true;
            this.PatName.Width = 80;
            // 
            // GroupNo
            // 
            this.GroupNo.DataPropertyName = "GroupNo";
            this.GroupNo.HeaderText = "组号";
            this.GroupNo.Name = "GroupNo";
            this.GroupNo.ReadOnly = true;
            this.GroupNo.Width = 120;
            // 
            // StartDT
            // 
            this.StartDT.HeaderText = "开始日期";
            this.StartDT.Name = "StartDT";
            this.StartDT.ReadOnly = true;
            this.StartDT.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.StartDT.Width = 120;
            // 
            // InceptDT
            // 
            this.InceptDT.DataPropertyName = "InceptDT";
            this.InceptDT.HeaderText = "接收日期";
            this.InceptDT.Name = "InceptDT";
            this.InceptDT.ReadOnly = true;
            this.InceptDT.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.InceptDT.Width = 120;
            // 
            // DoctorExplain
            // 
            this.DoctorExplain.DataPropertyName = "DoctorExplain";
            this.DoctorExplain.HeaderText = "医师意见";
            this.DoctorExplain.Name = "DoctorExplain";
            this.DoctorExplain.ReadOnly = true;
            // 
            // Remark1
            // 
            this.Remark1.DataPropertyName = "Remark1";
            this.Remark1.HeaderText = "备注1";
            this.Remark1.Name = "Remark1";
            // 
            // Remark2
            // 
            this.Remark2.DataPropertyName = "Remark2";
            this.Remark2.HeaderText = "备注2";
            this.Remark2.Name = "Remark2";
            // 
            // Remark3
            // 
            this.Remark3.DataPropertyName = "Remark3";
            this.Remark3.HeaderText = "备注3";
            this.Remark3.Name = "Remark3";
            // 
            // Remark4
            // 
            this.Remark4.DataPropertyName = "Remark4";
            this.Remark4.HeaderText = "备注4";
            this.Remark4.Name = "Remark4";
            // 
            // Remark5
            // 
            this.Remark5.DataPropertyName = "Remark5";
            this.Remark5.HeaderText = "备注5";
            this.Remark5.Name = "Remark5";
            // 
            // Remark6
            // 
            this.Remark6.DataPropertyName = "Remark6";
            this.Remark6.HeaderText = "备注6";
            this.Remark6.Name = "Remark6";
            // 
            // Rev1
            // 
            this.Rev1.HeaderText = "";
            this.Rev1.Image = global::PivasRevPre.Properties.Resources.tm;
            this.Rev1.Name = "Rev1";
            this.Rev1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Rev1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Rev1.Width = 25;
            // 
            // PrescriptionID
            // 
            this.PrescriptionID.DataPropertyName = "PrescriptionID";
            this.PrescriptionID.HeaderText = "PreID";
            this.PrescriptionID.Name = "PrescriptionID";
            this.PrescriptionID.Visible = false;
            // 
            // Level
            // 
            this.Level.DataPropertyName = "Level";
            this.Level.HeaderText = "Level";
            this.Level.Name = "Level";
            this.Level.Visible = false;
            // 
            // PatientCode
            // 
            this.PatientCode.DataPropertyName = "PatientCode";
            this.PatientCode.HeaderText = "PatCode";
            this.PatientCode.Name = "PatientCode";
            this.PatientCode.Visible = false;
            // 
            // Rev2
            // 
            this.Rev2.HeaderText = "";
            this.Rev2.Image = global::PivasRevPre.Properties.Resources.tm;
            this.Rev2.Name = "Rev2";
            this.Rev2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Rev2.Width = 20;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "";
            this.Column2.Name = "Column2";
            this.Column2.Width = 40;
            // 
            // pnlUp
            // 
            this.pnlUp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlUp.BackgroundImage = global::PivasRevPre.Properties.Resources._151;
            this.pnlUp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pnlUp.Location = new System.Drawing.Point(206, 437);
            this.pnlUp.Name = "pnlUp";
            this.pnlUp.Size = new System.Drawing.Size(68, 18);
            this.pnlUp.TabIndex = 16;
            this.pnlUp.Click += new System.EventHandler(this.pnlUp_Click);
            // 
            // med1
            // 
            this.med1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.med1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.med1.Location = new System.Drawing.Point(3, 173);
            this.med1.Name = "med1";
            this.med1.Size = new System.Drawing.Size(441, 282);
            this.med1.TabIndex = 1;
            this.med1.Visible = false;
            this.med1.VisibleChanged += new System.EventHandler(this.med1_VisibleChanged);
            // 
            // information1
            // 
            this.information1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.information1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.information1.Location = new System.Drawing.Point(1, 0);
            this.information1.Margin = new System.Windows.Forms.Padding(0);
            this.information1.Name = "information1";
            this.information1.Size = new System.Drawing.Size(438, 453);
            this.information1.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.BackColor = System.Drawing.Color.DodgerBlue;
            this.label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label2.Location = new System.Drawing.Point(183, 297);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 79);
            this.label2.TabIndex = 1;
            this.label2.Text = ">";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // pnlDetail
            // 
            this.pnlDetail.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlDetail.Location = new System.Drawing.Point(200, 37);
            this.pnlDetail.Name = "pnlDetail";
            this.pnlDetail.Size = new System.Drawing.Size(962, 470);
            this.pnlDetail.TabIndex = 17;
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.HeaderText = "";
            this.dataGridViewImageColumn1.Image = global::PivasRevPre.Properties.Resources.tm;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewImageColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewImageColumn1.Width = 20;
            // 
            // dataGridViewImageColumn2
            // 
            this.dataGridViewImageColumn2.HeaderText = "";
            this.dataGridViewImageColumn2.Image = global::PivasRevPre.Properties.Resources.tm;
            this.dataGridViewImageColumn2.Name = "dataGridViewImageColumn2";
            this.dataGridViewImageColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewImageColumn2.Width = 20;
            // 
            // ckBoxSelAll
            // 
            this.ckBoxSelAll.AutoSize = true;
            this.ckBoxSelAll.Location = new System.Drawing.Point(5, 5);
            this.ckBoxSelAll.Name = "ckBoxSelAll";
            this.ckBoxSelAll.Size = new System.Drawing.Size(72, 16);
            this.ckBoxSelAll.TabIndex = 23;
            this.ckBoxSelAll.Text = "病区列表";
            this.ckBoxSelAll.ThreeState = true;
            this.toolTip1.SetToolTip(this.ckBoxSelAll, "病区列表全选");
            this.ckBoxSelAll.UseVisualStyleBackColor = true;
            this.ckBoxSelAll.Click += new System.EventHandler(this.ckBoxSelAll_Click);
            // 
            // lblUnchecks
            // 
            this.lblUnchecks.AutoSize = true;
            this.lblUnchecks.Location = new System.Drawing.Point(115, 6);
            this.lblUnchecks.Name = "lblUnchecks";
            this.lblUnchecks.Size = new System.Drawing.Size(29, 12);
            this.lblUnchecks.TabIndex = 24;
            this.lblUnchecks.Text = "未审";
            this.toolTip1.SetToolTip(this.lblUnchecks, "当前日期以前所有的人工未审的处方数（含当天）");
            // 
            // lblAllChecks
            // 
            this.lblAllChecks.AutoSize = true;
            this.lblAllChecks.Location = new System.Drawing.Point(153, 6);
            this.lblAllChecks.Name = "lblAllChecks";
            this.lblAllChecks.Size = new System.Drawing.Size(29, 12);
            this.lblAllChecks.TabIndex = 25;
            this.lblAllChecks.Text = "全部";
            this.toolTip1.SetToolTip(this.lblAllChecks, "当天的全部处方数");
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // txtWard
            // 
            this.txtWard.BackColor = System.Drawing.Color.White;
            this.txtWard.ForeColor = System.Drawing.Color.Gray;
            this.txtWard.Location = new System.Drawing.Point(104, 1);
            this.txtWard.Name = "txtWard";
            this.txtWard.Size = new System.Drawing.Size(94, 21);
            this.txtWard.TabIndex = 0;
            this.txtWard.Text = "病区名/简拼";
            this.txtWard.TextChanged += new System.EventHandler(this.txtWard_TextChanged);
            this.txtWard.DoubleClick += new System.EventHandler(this.txtWard_DoubleClick);
            this.txtWard.Enter += new System.EventHandler(this.txtWard_Enter);
            this.txtWard.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWard_KeyPress);
            this.txtWard.Leave += new System.EventHandler(this.txtWard_Leave);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.Controls.Add(this.cmBoxWardArea);
            this.panel1.Controls.Add(this.txtWard);
            this.panel1.Location = new System.Drawing.Point(0, 482);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(199, 23);
            this.panel1.TabIndex = 18;
            // 
            // cmBoxWardArea
            // 
            this.cmBoxWardArea.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmBoxWardArea.FormattingEnabled = true;
            this.cmBoxWardArea.Location = new System.Drawing.Point(3, 1);
            this.cmBoxWardArea.Name = "cmBoxWardArea";
            this.cmBoxWardArea.Size = new System.Drawing.Size(99, 20);
            this.cmBoxWardArea.TabIndex = 1;
            this.cmBoxWardArea.SelectionChangeCommitted += new System.EventHandler(this.cmBoxWardArea_SelectionChangeCommitted);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Controls.Add(this.txtName);
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Location = new System.Drawing.Point(73, 169);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(81, 294);
            this.panel2.TabIndex = 17;
            this.panel2.Visible = false;
            this.panel2.Leave += new System.EventHandler(this.panel2_Leave);
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.SystemColors.Control;
            this.txtName.ForeColor = System.Drawing.Color.Gray;
            this.txtName.Location = new System.Drawing.Point(0, 272);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(79, 21);
            this.txtName.TabIndex = 1;
            this.txtName.Text = "姓名/ID/床";
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            this.txtName.DoubleClick += new System.EventHandler(this.txtName_DoubleClick);
            this.txtName.Enter += new System.EventHandler(this.textBox1_Enter);
            this.txtName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            this.txtName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtName_KeyPress);
            this.txtName.Leave += new System.EventHandler(this.txtName_Leave);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ColumnHeadersVisible = false;
            this.dataGridView1.Location = new System.Drawing.Point(0, 1);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(79, 270);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.Click += new System.EventHandler(this.dataGridView1_Click);
            // 
            // dgvWards
            // 
            this.dgvWards.AllowUserToAddRows = false;
            this.dgvWards.AllowUserToDeleteRows = false;
            this.dgvWards.AllowUserToResizeRows = false;
            this.dgvWards.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dgvWards.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dgvWards.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvWards.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvWards.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvWards.ColumnHeadersVisible = false;
            this.dgvWards.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cbBoxSel,
            this.colWardCode,
            this.colWardName,
            this.colUnchecks,
            this.colAllChecks});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvWards.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgvWards.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvWards.Location = new System.Drawing.Point(1, 25);
            this.dgvWards.MultiSelect = false;
            this.dgvWards.Name = "dgvWards";
            this.dgvWards.ReadOnly = true;
            this.dgvWards.RowHeadersVisible = false;
            this.dgvWards.RowTemplate.Height = 23;
            this.dgvWards.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvWards.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvWards.Size = new System.Drawing.Size(197, 456);
            this.dgvWards.TabIndex = 22;
            this.dgvWards.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvWards_CellClick);
            this.dgvWards.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.dgvWards_RowPrePaint);
            // 
            // cbBoxSel
            // 
            this.cbBoxSel.HeaderText = "";
            this.cbBoxSel.Name = "cbBoxSel";
            this.cbBoxSel.ReadOnly = true;
            this.cbBoxSel.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cbBoxSel.Width = 22;
            // 
            // colWardCode
            // 
            this.colWardCode.HeaderText = "";
            this.colWardCode.Name = "colWardCode";
            this.colWardCode.ReadOnly = true;
            this.colWardCode.Visible = false;
            // 
            // colWardName
            // 
            this.colWardName.HeaderText = "";
            this.colWardName.Name = "colWardName";
            this.colWardName.ReadOnly = true;
            // 
            // colUnchecks
            // 
            this.colUnchecks.HeaderText = "";
            this.colUnchecks.Name = "colUnchecks";
            this.colUnchecks.ReadOnly = true;
            this.colUnchecks.Width = 30;
            // 
            // colAllChecks
            // 
            this.colAllChecks.HeaderText = "";
            this.colAllChecks.Name = "colAllChecks";
            this.colAllChecks.ReadOnly = true;
            this.colAllChecks.Width = 30;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(142, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(11, 12);
            this.label5.TabIndex = 216;
            this.label5.Text = "/";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel5.Controls.Add(this.ckBoxSelAll);
            this.panel5.Controls.Add(this.cbbSys);
            this.panel5.Controls.Add(this.cbbPer);
            this.panel5.Controls.Add(this.lblUnchecks);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Controls.Add(this.lblAllChecks);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(199, 32);
            this.panel5.TabIndex = 217;
            // 
            // CheckPre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dgvWards);
            this.Controls.Add(this.pnlTitle);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlTable);
            this.Controls.Add(this.pnlDetail);
            this.Controls.Add(this.panel5);
            this.Name = "CheckPre";
            this.Size = new System.Drawing.Size(1117, 505);
            this.Load += new System.EventHandler(this.CheckPre_Load);
            this.pnlTitle.ResumeLayout(false);
            this.pnlTitle.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.pnlPER.ResumeLayout(false);
            this.pnlPER.PerformLayout();
            this.pnlSYS.ResumeLayout(false);
            this.pnlSYS.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.pnlTable.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWards)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTitle;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnPass;
        public System.Windows.Forms.DateTimePicker DT;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn2;
        private System.Windows.Forms.Panel pnlTable;
        public Med med1;
        private System.Windows.Forms.Panel pnlUp;
        private System.Windows.Forms.Panel pnlDetail;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Timer timer1;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Panel pnlHongqi;
        public System.Windows.Forms.Panel pnlbaiqi;
        private System.Windows.Forms.Button btnhistory;
        private System.Windows.Forms.TextBox txtWard;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtName;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.ComboBox cbbPer;
        public System.Windows.Forms.ComboBox cbbSys;
        private System.Windows.Forms.CheckBox chkBoxStLong;
        private System.Windows.Forms.CheckBox chkBoxSTShort;
        private System.Windows.Forms.DataGridView dgvWards;
        private System.Windows.Forms.ComboBox cmBoxWardArea;
        private System.Windows.Forms.CheckBox ckBoxYin;
        private System.Windows.Forms.CheckBox ckBoxHua;
        private System.Windows.Forms.CheckBox ckBoxKang;
        private System.Windows.Forms.CheckBox ckBoxPu;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.CheckBox ckBoxSelAll;
        private System.Windows.Forms.Label lblUnchecks;
        private System.Windows.Forms.Label lblAllChecks;
        public System.Windows.Forms.DataGridView dgvResult;
        private System.Windows.Forms.Panel pnlSYS;
        private System.Windows.Forms.Label lblSysUnPass;
        private System.Windows.Forms.Label lblSysPass;
        private System.Windows.Forms.Label lblSysAll;
        private System.Windows.Forms.Panel pnlPER;
        private System.Windows.Forms.Label lblPerYi;
        private System.Windows.Forms.Label lblPerWei;
        private System.Windows.Forms.Label lblPerWeiAndTui;
        private System.Windows.Forms.Label lblPerTui;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cbBoxSel;
        private System.Windows.Forms.DataGridViewTextBoxColumn colWardCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn colWardName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colUnchecks;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAllChecks;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lblLingCount;
        private System.Windows.Forms.Label lblLongCount;
        private System.Windows.Forms.Button button3;
        private Information information1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ComboBox PreType;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.ComboBox CPType;
        private System.Windows.Forms.ComboBox SysType;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn RowNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn Care;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Check;
        private System.Windows.Forms.DataGridViewTextBoxColumn IsPass;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvSysResult;
        private System.Windows.Forms.DataGridViewTextBoxColumn WardName;
        private System.Windows.Forms.DataGridViewTextBoxColumn BedNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn PatName;
        private System.Windows.Forms.DataGridViewTextBoxColumn GroupNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn InceptDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn DoctorExplain;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remark1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remark2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remark3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remark4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remark5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remark6;
        private System.Windows.Forms.DataGridViewImageColumn Rev1;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrescriptionID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Level;
        private System.Windows.Forms.DataGridViewTextBoxColumn PatientCode;
        private System.Windows.Forms.DataGridViewImageColumn Rev2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.CheckBox ckBoxZhong;
    }
}
