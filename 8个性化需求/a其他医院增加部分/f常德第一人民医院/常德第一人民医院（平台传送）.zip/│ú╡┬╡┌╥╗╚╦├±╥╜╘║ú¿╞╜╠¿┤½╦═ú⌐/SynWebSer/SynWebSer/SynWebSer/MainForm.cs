﻿using System;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Reflection;
using System.Text;
using IBM.WMQ;
using System.Threading;
using System.Web.Services.Description;
using System.Windows.Forms;
using Microsoft.CSharp;
using Microsoft.Win32;
using PIVAsDBhelp;
using System.Collections;


namespace SynWebSer
{
    internal sealed partial class MainForm : Form
    {
        private DataTable dt = new DataTable();
        private DataTable res = new DataTable();
        private string @namespace = "EnterpriseServerBase.WebService.DynamicWebCalling";
        private bool CanRun = false;
        private DB_Help db = new DB_Help();
        internal MainForm()
        {
            if (!Directory.Exists(".\\CrWebSerDLL\\"))
            {
                Directory.CreateDirectory(".\\CrWebSerDLL\\");
            }
            if (!Directory.Exists(".\\ErrLog\\"))
            {
                Directory.CreateDirectory(".\\ErrLog\\");
            }
            if (!Directory.Exists(".\\SyncDatBack\\"))
            {
                Directory.CreateDirectory(".\\SyncDatBack\\");
            }
            InitializeComponent();
            comboBox1.SelectedIndex = 5;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                StringBuilder SB = new StringBuilder();
                SB.AppendLine(" IF OBJECT_ID('IVRecordToFC') IS NULL BEGIN ");
                SB.AppendLine(" CREATE TABLE[dbo].[IVRecordToFC]([LabelNo][varchar](32) NOT NULL,[FCDT][datetime] NULL,CONSTRAINT[PK_IVRecordToFC] PRIMARY KEY CLUSTERED ");
                SB.AppendLine(" ([LabelNo] ASC)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]) ON[PRIMARY] ");
                SB.AppendLine(" END");
                SB.AppendLine(" IF OBJECT_ID('PrescriptionToFC') IS NULL BEGIN  ");
                SB.AppendLine(" CREATE TABLE [dbo].[PrescriptionToFC]([GroupNo] [varchar](64) NOT NULL,[FCDT] [datetime] NULL, ");
                SB.AppendLine(" CONSTRAINT [PK_PrescriptionToFC] PRIMARY KEY CLUSTERED ([GroupNo] ASC) ");
                SB.AppendLine(" WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]) ");
                SB.AppendLine(" ON [PRIMARY] END ");
                db.SetPIVAsDB(SB.ToString());

                if (File.Exists(".\\SynWebDat.dat"))
                {
                    dt.ReadXml(".\\SynWebDat.dat");
                    CheckDLL();
                }
                else
                {
                    dt.TableName = "SynWebDat";
                    dt.Columns.Add("WebService地址", typeof(string));
                    dt.Columns.Add("类名", typeof(string));
                    dt.Columns.Add("方法名", typeof(string));
                    dt.Columns.Add("参数", typeof(string));
                    dt.Columns.Add("回传更新", typeof(string));
                    dt.Columns.Add("Enable", typeof(bool));
                    dt.Columns.Add("CanRun", typeof(bool));
                    dt.PrimaryKey = new DataColumn[] { dt.Columns["WebService地址"], dt.Columns["方法名"], dt.Columns["参数"] };
                }
                dataGridView1.DataSource = dt;
                dataGridView1.Columns[0].Width = 300;
                dataGridView1.Columns[1].Width = 150;
                dataGridView1.Columns[2].Width = 150;
                dataGridView1.Columns[3].Width = 200;
                dataGridView1.Columns[4].Width = 200;
                dataGridView1.Columns["Enable"].Visible = false;
                dataGridView1.Columns["CanRun"].Visible = false;
                res.TableName = "res";
                res.Columns.Add("time", typeof(string));
                res.Columns.Add("CZ", typeof(string));
                res.Columns.Add("ret", typeof(string));
                dataGridView2.DataSource = res;
                dataGridView2.Columns[0].Width = 60;
                dataGridView2.Columns[1].Width = 120;
                //if (dt.Rows.Count > 0)
               // {
                //    button1_Click(sender, e);
               // }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void CheckPTDLL()
        {
            string xml = "";
            DB_Help DB = new DB_Help();

            try
            {

                try
                {

                    using (DataSet ds = DB.GetPIVAsDB(string.Format(@"select ivd.RecipeNo as GroupNo,
                                             case Batch when '1-K'then 1 when '2-K' then 2 when '3-K' then 3 when '4-K' then 4 else i.TeamNumber end as Batch,
                                             LabelNo,i.PatCode,i.PatName,pp.CaseID,p.admiss_times,i.WardCode,WardName,DrugCode,DrugName,Dosage,DosageUnit,
                                             (select top 1 DEmployeeName from DEmployee e inner join IVRecord_PZ ip on e.DEmployeeID =ip.PCode where ip.IVRecordID =i.LabelNo ) as  pz,
                                             (select  top 1 DEmployeeCode from DEmployee e inner join IVRecord_PZ ip on e.DEmployeeID =ip.PCode where ip.IVRecordID =i.LabelNo ) as  pzCode,
                                            (select  top 1 DEmployeeName from DEmployee e inner join IVRecord_DB idb on e.DEmployeeID =idb.PCode where idb.IVRecordID =i.LabelNo ) as  db,
                                            (select  top 1 DEmployeeCode from DEmployee e inner join IVRecord_DB ip on e.DEmployeeID =ip.PCode where ip.IVRecordID =i.LabelNo ) as  dbCode
                                              from  IVRecord i
                                             inner join IVRecordDetail ivd
                                             on i.IVRecordID = ivd.IVRecordID
                                           
                                             inner join Patient p
                                             on i.PatCode =p.PatCode
                                             inner join Prescription pp
                                             on i.GroupNo =pp.GroupNo 
                                             where DATEDIFF(DD,GETDATE(),i.InfusionDT)=0

                                             ")))
                    {



                        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                        {



                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {

                                string hostname = "172.16.15.13";//正式环境
                                // string hostname = "172.16.13.42";//测试环境
                                string channel = "IE.SVRCONN";
                                string qManager = "GWI.QM";
                                string queueManager = "IN.BS307.LQ";

                                Hashtable env = new Hashtable();
                                env.Add(MQC.HOST_NAME_PROPERTY, hostname);
                                env.Add(MQC.CHANNEL_PROPERTY, channel);
                                env.Add(MQC.CCSID_PROPERTY, 1208);
                                env.Add(MQC.PORT_PROPERTY, 5000);
                                env.Add(MQC.TRANSPORT_PROPERTY, MQC.TRANSPORT_MQSERIES);
                                env.Add(MQC.USER_ID_PROPERTY, "mqm");


                                int openOptions = MQC.MQOO_OUTPUT
                                        | MQC.MQPMO_PASS_ALL_CONTEXT;
                                MQMessage msg1 = new MQMessage();
                                MQQueueManager qMgr = new MQQueueManager(qManager, env);
                                msg1.CharacterSet = 1208;
                                MQQueue queue = null;
                                queue = qMgr.AccessQueue(queueManager, openOptions);
                                msg1.Format = MQC.MQFMT_STRING;
                                msg1.SetStringProperty("service_id", "BS307");
                                msg1.SetStringProperty("domain_id", "02");
                                msg1.SetStringProperty("apply_unit_id", "0");
                                msg1.SetStringProperty("send_sys_id", "S055");
                                msg1.SetStringProperty("hospital_id", "44643245-7");
                                msg1.SetStringProperty("order_exec_id", "0");
                                msg1.SetStringProperty("exec_unit_id", "0");
                                msg1.SetStringProperty("extend_sub_id", "0");

                                for (int k = 0; k <= i; k++)
                                {
                                    xml = "";
                                    string Batch = ds.Tables[0].Rows[i]["Batch"].ToString();
                                    //string labelNo = ds.Tables[0].Rows[0]["LabelNo"].ToString();
                                    string PatCode = ds.Tables[0].Rows[i]["PatCode"].ToString();
                                    string PatName = ds.Tables[0].Rows[i]["PatName"].ToString();
                                    string CaseID = ds.Tables[0].Rows[i]["CaseID"].ToString();
                                    string admiss_times = ds.Tables[0].Rows[i]["admiss_times"].ToString();
                                    string WardCode = ds.Tables[0].Rows[i]["WardCode"].ToString();
                                    string WardName = ds.Tables[0].Rows[i]["WardName"].ToString();
                                    string pz = ds.Tables[0].Rows[i]["pz"].ToString();
                                    string pzCode = ds.Tables[0].Rows[i]["pzCode"].ToString();
                                    string GroupNo = ds.Tables[0].Rows[i]["GroupNo"].ToString();
                                    string LabelNo = ds.Tables[0].Rows[i]["LabelNo"].ToString();
                                    string Dosage = ds.Tables[0].Rows[i]["Dosage"].ToString();
                                    string DosageUnit = ds.Tables[0].Rows[i]["DosageUnit"].ToString();
                                    string DBDT = DateTime.Parse(DateTime.Now.ToString()).ToString("yyyyMMddHHmm");


                                   // DataSet datas = DB.GetPIVAsDB(string.Format("   select * from DEmployee where DEmployeeID in( select PCode from IVRecord_PZ where IVRecordID ='{0}') ", LabelNo));
                                    string db = ds.Tables[0].Rows[0]["db"].ToString();
                                    string dbCode = ds.Tables[0].Rows[0]["dbCode"].ToString();


                                    xml += "<?xml version=" + "\"1.0\"" + " encoding=" + "\"UTF-8\"" + "?>";
                                    xml += "<PORX_IN010370UV ITSVersion=" + "\"XML_1.0\"" + " xmlns=" + "\"urn:hl7-org:v3\"" + " xmlns:xsi=" + "\"http://www.w3.org/2001/XMLSchema-instance\"" + " xsi:schemaLocation=\"urn:hl7-org:v3 ../../Schemas/PORX_IN010370UV01.xsd\">";
                                    xml += "<!--";
                                    xml += "发药确认";
                                    xml += "-->";
                                    xml += "<!-- 消息ID -->";
                                    xml += "<id extension=" + "\"BS307\"" + " />";
                                    xml += "<!-- 消息创建时间 -->";
                                    string time = DateTime.Parse(DateTime.Now.ToString()).ToString("yyyyMMddHHmmss");
                                    xml += "<creationTime value=\"" + time + "\" />";
                                    xml += "<!-- 交互ID -->";
                                    xml += "<interactionId root=\"\" extension=" + "\"PORX_IN010370UV\"" + " />";
                                    xml += "<!-- 消息用途: P(Production); D(Debugging); T(Training) -->";
                                    xml += "<processingCode code=" + "\"P\"" + " />";
                                    xml += "<!-- 消息处理模式: A(Archive); I(Initial load); R(Restore from archive); T(Current processing) -->";
                                    xml += "<processingModeCode code=" + "\"T\"" + " />";
                                    xml += "<!-- 消息应答: AL(Always); ER(Error/reject only); NE(Never) -->";
                                    xml += "<acceptAckCode code=" + "\"NE\"" + " />";
                                    xml += "<!-- 接受者 -->";
                                    xml += "<receiver typeCode=" + "\"RCV\"" + ">";
                                    xml += "<device classCode=" + "\"DEV\"" + " determinerCode=" + "\"INSTANCE\"" + ">";
                                    xml += "<!-- 接受者ID -->";
                                    xml += "<id />";
                                    xml += "</device>";
                                    xml += "</receiver>";
                                    xml += "<!-- 发送者 -->";
                                    xml += "<sender typeCode=" + "\"SND\"" + ">";
                                    xml += "<device classCode=" + "\"DEV\"" + " determinerCode=" + "\"INSTANCE\"" + ">";
                                    xml += "<!-- 发送者ID -->";
                                    xml += "<id />";
                                    xml += "</device>";
                                    xml += "</sender>";

                                    xml += "<!-- 封装的消息内容 -->";
                                    xml += "<controlActProcess classCode=" + "\"CACT\"" + " moodCode=" + "\"EVN\"" + ">";
                                    xml += "<!-- ";
                                    xml += "消息交互类型";
                                    xml += "@code: 新增:new";
                                    xml += "-->";
                                    xml += "<code code=" + "\"new\"" + " />";
                                    xml += "<subject typeCode=" + "\"SUBJ\"" + " contextConductionInd=" + "\"false\"" + ">";

                                    xml += "<!-- 一个消息可包含一个患者一次就诊的多个处方笺/摆药单 -->";
                                    xml += "<combinedMedicationRequest moodCode=" + "\"RQO\"" + ">";

                                    xml += "<!-- 病人信息 -->";
                                    xml += "<subject typeCode=" + "\"SBJ\"" + ">";
                                    xml += "<patient classCode=" + "\"PAT\"" + ">";
                                    xml += "<!-- 病人标识 -->";
                                    xml += "<id>";
                                    xml += "<!-- 域ID -->";
                                    xml += "<item root=" + "\"1.2.156.112649.1.2.1.2\"" + " extension=" + "\"02\"" + "/>";
                                    xml += "<!-- 患者ID -->";
                                    xml += "<item root=" + "\"1.2.156.112649.1.2.1.3\"" + " extension=\"" + PatCode + "\"/>";
                                    xml += "<!-- 就诊号 -->";
                                    xml += "<item root=" + "\"1.2.156.112649.1.2.1.12\"" + " extension=\"" + CaseID + "\"/>";
                                    xml += "</id>";

                                    xml += "<!-- 个人信息 -->";
                                    xml += "<patientPerson classCode=" + "\"PSN\"" + " determinerCode=" + "\"INSTANCE\"" + ">";
                                    xml += "<!-- 病人名称 -->";
                                    xml += "<name xsi:type=" + "\"DSET_EN\"" + ">";
                                    xml += "<item>";
                                    xml += "<part value=\"" + PatName + "\"/>";
                                    xml += "</item>";
                                    xml += "</name>";
                                    xml += "</patientPerson>";

                                    xml += "<!-- 病人当前科室信息 -->";
                                    xml += "<providerOrganization classCode=" + "\"ORG\"" + " determinerCode=" + "\"INSTANCE\"" + ">";
                                    xml += "<id />";
                                    xml += "<!-- 医疗机构信息 -->";
                                    xml += "<asOrganizationPartOf classCode=" + "\"PART\"" + ">";
                                    xml += "<wholeOrganization classCode=" + "\"ORG\"" + " determinerCode=" + "\"INSTANCE\"" + ">";
                                    xml += "<!-- 医疗机构编码 -->";
                                    xml += "<id>";
                                    xml += "<item extension=" + "\"44643245-7\"" + "/>";
                                    xml += "</id>";
                                    xml += "<!-- 医疗机构名称 -->";
                                    xml += "<name xsi:type=" + "\"BAG_EN\"" + ">";
                                    xml += "<item><part value=" + "\"常德市第一人民医院\"" + " /></item>";
                                    xml += "</name>";
                                    xml += "</wholeOrganization>";
                                    xml += "</asOrganizationPartOf>";
                                    xml += "</providerOrganization>";
                                    xml += "</patient>";
                                    xml += "</subject>";

                                    xml += "<!-- 处方/摆药单信息(可循环) -->";
                                    xml += "<component3>";
                                    xml += "<combinedMedicationRequest moodCode=" + "\"RQO\"" + ">";
                                    xml += "<!-- 处方号或摆药单单号 -->";
                                    xml += "<id>";
                                    xml += "<item extension=\"" + LabelNo + "\" />";
                                    xml += "</id>";

                                    xml += "<!-- 配药医师信息 -->";
                                    xml += "<responsibleParty typeCode=" + "\"RESP\"" + ">";
                                    xml += "<assignedEntity classCode=" + "\"ASSIGNED\"" + ">";
                                    xml += "<!-- 配药人编码 -->";
                                    xml += "<id>";
                                    xml += "<item root=" + "\"1.2.156.112649.1.1.2\"" + " extension=\"" + pzCode + "\" />";
                                    xml += "</id>";
                                    xml += "<!-- 配药人名称 -->";
                                    xml += "<assignedPerson classCode=" + "\"PSN\"" + " determinerCode=" + "\"INSTANCE\"" + ">";
                                    xml += "<name xsi:type=" + "\"LIST_EN\"" + ">";
                                    xml += "<item><part value=\"" + pz + "\"/></item>";
                                    xml += "</name>";
                                    xml += "</assignedPerson>";
                                    xml += "</assignedEntity>";
                                    xml += "</responsibleParty>";

                                    xml += "<!-- 发药确认人信息 -->";
                                    xml += "<verifier typeCode=" + "\"VRF\"" + ">";
                                    xml += "<!-- 发药确认时间 -->";
                                    xml += "<time xsi:type=" + "\"TS\"" + " value=\"" + DBDT + "\" />";
                                    xml += "<assignedEntity classCode=" + "\"ASSIGNED\"" + ">";
                                    xml += "<!-- 发药人编码 -->";
                                    xml += "<id>";
                                    xml += "<item root=" + "\"1.2.156.112649.1.1.2\"" + " extension=\"" + dbCode + "\" />";
                                    xml += "</id>";
                                    xml += "<!-- 发药人名称 -->";
                                    xml += "<assignedPerson classCode=" + "\"PSN\"" + " determinerCode=" + "\"INSTANCE\"" + ">";
                                    xml += "<name xsi:type=" + "\"BAG_EN\"" + ">";
                                    xml += "<item><part value=\"" + db + "\"/></item>";
                                    xml += "</name>";
                                    xml += "</assignedPerson>";
                                    xml += "</assignedEntity>";
                                    xml += "</verifier>";

                                    xml += "<!-- 药物信息(可循环) -->";
                                    xml += "<component1 typeCode=" + "\"COMP\"" + ">";
                                    xml += "<substanceAdministrationRequest classCode=" + "\"SBADM\"" + " moodCode=" + "\"RQO\"" + ">";
                                    xml += "<!-- 医嘱号/批次号 -->";
                                    xml += "<id>";
                                    xml += "<!-- 医嘱号 -->";
                                    xml += "<item extension=\"" + GroupNo + "\" />";
                                    xml += "<!-- 批次号 -->";
                                    xml += "<item extension=\"\" scope=" + "\"VER\"" + " />";
                                    xml += "</id>";
                                    xml += "<!-- 药量及单位 -->";
                                    xml += "<doseCheckQuantity>";
                                    xml += "<item>";
                                    xml += "<numerator xsi:type=" + "\"PQ\"" + " value=\"" + Dosage + "\" unit=\"" + DosageUnit + "\" />";
                                    xml += "</item>";
                                    xml += "</doseCheckQuantity>";
                                    xml += "</substanceAdministrationRequest>";
                                    xml += "</component1>";






                                    xml += "<!-- 多条药物按上面格式添加 -->";
                                    xml += "<!-- 发药相关信息 -->";
                                    xml += "<component2 typeCode=" + "\"COMP\"" + ">";
                                    xml += "<dispenseRequest classCode=" + "\"SPLY\"" + " moodCode=" + "\"RQO\"" + ">";
                                    xml += "<!-- 必须项 -->";
                                    xml += "<quantity />";

                                    xml += "<!-- 请领人信息(在请领情况下会有此标签) -->";
                                    xml += "<receiver typeCode=" + "\"RCV\"" + ">";
                                    xml += "<assignedPerson classCode=" + "\"ASSIGNED\"" + ">";
                                    xml += "<!-- 请领人编码 -->";
                                    xml += "<id>";
                                    xml += "<item root=" + "\" 1.2.156.112649.1.1.2 \"" + " extension=\"\" />";
                                    xml += "</id>";
                                    xml += "<!-- 请领人名称 -->";
                                    xml += "<assignedPerson classCode=" + "\"PSN\"" + " determinerCode=" + "\"INSTANCE\"" + ">";
                                    xml += "<name xsi:type=" + "\"BAG_EN\"" + ">";
                                    xml += "<item><part value=\"\" /></item>";
                                    xml += "</name>";
                                    xml += "</assignedPerson>";
                                    xml += "</assignedPerson>";
                                    xml += "</receiver>";

                                    xml += "<!-- 发药库房 -->";
                                    xml += "<performer typeCode=" + "\"PRF\"" + ">";
                                    xml += "<assignedOrganization classCode=" + "\"ASSIGNED\"" + ">";
                                    xml += "<!-- 科室编码 -->";
                                    xml += "<id>";
                                    xml += "<item root=" + "\"1.2.156.112649.1.1.1\"" + " extension=\"\" />";
                                    xml += "</id>";
                                    xml += "<assignedOrganization classCode=" + "\"ORG\"" + " determinerCode=" + "\"INSTANCE\"" + ">";
                                    xml += "<!-- 科室名称 -->";
                                    xml += "<name xsi:type=" + "\"BAG_EN\"" + ">";
                                    xml += "<item>";
                                    xml += "<part value=\"\" />";
                                    xml += "</item>";
                                    xml += "</name>";
                                    xml += "</assignedOrganization>";
                                    xml += "</assignedOrganization>";
                                    xml += "</performer>";

                                    xml += "<!-- 请领科室(在请领情况下会有此标签) -->";
                                    xml += "<origin typeCode=" + "\"ORG\"" + ">";
                                    xml += "<serviceDeliveryLocation classCode=" + "\"SDLOC\"" + ">";
                                    xml += "<serviceProviderOrganization classCode=" + "\"ORG\"" + " determinerCode=" + "\"INSTANCE\"" + ">";
                                    xml += "<!-- 科室编码 -->";
                                    xml += "<id>";
                                    xml += "<item root=" + "\"1.2.156.112649.1.1.1\"" + " extension=\"\" />";
                                    xml += "</id>";
                                    xml += "<!-- 科室名称 -->";
                                    xml += "<name xsi:type=" + "\"BAG_EN\"" + ">";
                                    xml += "<item>";
                                    xml += "<part value=\"\"/>";
                                    xml += "</item>";
                                    xml += "</name>";
                                    xml += "</serviceProviderOrganization>";
                                    xml += "</serviceDeliveryLocation>";
                                    xml += "</origin>";
                                    xml += "</dispenseRequest>";
                                    xml += "</component2>";
                                    xml += "</combinedMedicationRequest>";
                                    xml += "</component3>";
                                    xml += "<!-- 多个处方笺按上面格式添加 -->";

                                    xml += " <!-- 就诊信息 -->";
                                    xml += "<componentOf typeCode=" + "\"COMP\"" + ">";
                                    xml += "<encounter classCode=" + "\"ENC\"" + " moodCode=" + "\"EVN\"" + ">";
                                    xml += "<id>";
                                    xml += "<!-- 就诊次数 -->";
                                    xml += "<item root=" + "\"1.2.156.112649.1.2.1.7\"" + " extension=\"" + admiss_times + "\" />";
                                    xml += "</id>";
                                    xml += "<statusCode code=" + "\"active\"" + " />";
                                    xml += "<subject typeCode=" + "\"SBJ\"" + ">";
                                    xml += "<patient classCode=" + "\"PAT\"" + " />";
                                    xml += "</subject>";
                                    xml += "</encounter>";
                                    xml += "</componentOf>";

                                    xml += "</combinedMedicationRequest>";
                                    xml += "</subject>";
                                    xml += "</controlActProcess>";
                                    xml += "</PORX_IN010370UV>";


                                }
                                msg1.WriteString(xml);
                                // MessageBox.Show(xml);
                                MQPutMessageOptions pmo = new MQPutMessageOptions();
                                pmo.Options = MQC.MQPMO_SYNCPOINT;
                                queue.Put(msg1, pmo);
                                queue.Close();
                                qMgr.Commit();
                                qMgr.Disconnect();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
           

        }

        private void CheckDLL()
        {
            try
            {
                foreach (DataRow dr in dt.Rows)
                {
                    if (File.Exists(".\\CrWebSerDLL\\" + dr["类名"].ToString() + "_" + dr["方法名"].ToString() + ".dll"))
                    {
                        dr["Enable"] = true;
                        dr["CanRun"] = true;
                    }
                    else
                    {
                        dr["类名"] = CrWebSerDLL(dr["WebService地址"].ToString(), dr["类名"].ToString(), dr["方法名"].ToString());
                        dr["Enable"] = !string.IsNullOrEmpty(dr["类名"].ToString());
                        dr["CanRun"] = true;
                    }
                }
                dt.WriteXml(".\\SynWebDat.dat", XmlWriteMode.WriteSchema, false);
                dt.WriteXml(".\\SyncDatBack\\SynWebDat(" + DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss") + ").dat.bak", XmlWriteMode.WriteSchema, false);
            }
            catch (Exception ex)
            {
                SaveErrLog("CheckDLL", ex.Message);
            }
        }

        private string CrWebSerDLL(string url, string classname, string methodname)
        {
            string Creat = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(classname))
                {
                    classname = GetWsClassName(url);
                }
                ServiceDescriptionImporter sdi = new ServiceDescriptionImporter();
                sdi.AddServiceDescription(ServiceDescription.Read(new WebClient().OpenRead(url.Contains("?WSDL") ? url : url + "?WSDL")), string.Empty, string.Empty);
                CodeNamespace cn = new CodeNamespace(@namespace);
                CodeCompileUnit ccu = new CodeCompileUnit();
                ccu.Namespaces.Add(cn);
                sdi.Import(cn, ccu);

                CompilerParameters cplist = new CompilerParameters();
                cplist.GenerateExecutable = false;
                cplist.OutputAssembly = ".\\CrWebSerDLL\\" + classname + "_" + methodname + ".dll";
                cplist.ReferencedAssemblies.Add("System.dll");
                cplist.ReferencedAssemblies.Add("System.XML.dll");
                cplist.ReferencedAssemblies.Add("System.Web.Services.dll");
                cplist.ReferencedAssemblies.Add("System.Data.dll");

                CompilerResults cr = new CSharpCodeProvider().CompileAssemblyFromDom(cplist, ccu);
                if (cr.Errors.HasErrors)
                {
                    StringBuilder sb = new StringBuilder();
                    foreach (CompilerError ce in cr.Errors)
                    {
                        sb.Append(ce.ToString());
                        sb.Append(Environment.NewLine);
                    }
                    throw new Exception(sb.ToString());
                }
                else
                {
                    Creat = classname;
                }
            }
            catch (Exception ex)
            {
                SaveErrLog("CrWebSerDLL", ex.Message);
            }
            return Creat;
        }

        private void SaveErrLog(string Func, string ErrMsg)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("【" + DateTime.Now.ToString("HH:mm:ss") + "】" + Func);
                sb.AppendLine(ErrMsg);
                sb.AppendLine(" ");
                File.AppendAllText(".\\ErrLog\\" + DateTime.Now.ToString("yyyy-MM-dd") + ".log", sb.ToString());
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
        }

        private object RunMethodofWebSer(string classname, string methodname, object[] args)
        {
            object ret = string.Empty;
            try
            {
                Assembly assembly = Assembly.LoadFrom(".\\CrWebSerDLL\\" + classname + "_" + methodname + ".dll");
                Type t = assembly.GetType(@namespace + "." + classname, true, true);
                object obj = Activator.CreateInstance(t);
                MethodInfo mi = t.GetMethod(methodname);
                ret = mi.Invoke(obj, args);
            }
            catch (Exception ex)
            {
                SaveErrLog("RunMethodofWebSer", ex.Message);
            }
            return ret;
        }

        private string GetWsClassName(string wsUrl)
        {
            string ret = string.Empty;
            try
            {
                string[] parts = wsUrl.Split('/');
                string[] pps = parts[parts.Length - 1].Split('.');
                ret = pps[0];
            }
            catch (Exception ex)
            {
                SaveErrLog("GetWsClassName", ex.Message);
            }
            return ret;
        }

        private void timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (!CanRun)
            {
                CanRun = true;
                try
                {
                    CheckPTDLL();
                    //foreach (DataRow dr in dt.Rows)
                    //{
                    //    try
                    //    {
                    //        if (true.Equals(dr["Enable"]) && true.Equals(dr["CanRun"]))
                    //        {
                    //            dr["CanRun"] = false;
                    //            string[] Values = dr["参数"].ToString().Split('|');
                    //            string xmlstr = string.Empty;
                    //            DataSet dss = new DataSet();
                    //            int i = 0;
                    //            foreach (string Value in Values)
                    //            {
                    //                i = i + 1;
                    //                if (Value.ToUpper().Contains("SELECT") && Value.ToUpper().Contains("FROM"))
                    //                {
                    //                    dss = db.GetPIVAsDB(Value);
                    //                    if (dss != null && dss.Tables.Count > 0 && dss.Tables[0].Rows.Count > 0)
                    //                    {
                    //                        using (StringWriter sw = new StringWriter())
                    //                        {
                    //                            dss.WriteXml(sw, XmlWriteMode.WriteSchema);
                    //                            xmlstr = xmlstr + sw.ToString() + (i == Values.Length ? string.Empty : "|");
                    //                        }
                    //                    }
                    //                }
                    //                else
                    //                {
                    //                    xmlstr = xmlstr + Value + (i == Values.Length ? string.Empty : "|");
                    //                }
                    //            }
                    //            if (!string.IsNullOrEmpty(xmlstr))
                    //            {
                    //                object[] args = xmlstr.Split('|');
                    //                Thread TH = new Thread(() =>
                    //                {
                    //                    try
                    //                    {
                    //                        object obj = RunMethodofWebSer(dr["类名"].ToString(), dr["方法名"].ToString(), args);
                    //                        res.Rows.Add(DateTime.Now.ToString("HH:mm:ss"), dr["方法名"].ToString(), obj.ToString());
                    //                        if (obj.ToString() == dr["回传更新"].ToString().Split('|')[0])
                    //                        {
                    //                            if (dss != null && dss.Tables.Count > 0 && dr["回传更新"].ToString().ToUpper().Contains("SELECT") && dr["回传更新"].ToString().ToUpper().Contains("FROM") && dr["回传更新"].ToString().ToUpper().Contains("WHERE"))
                    //                            {
                    //                                using (DataSet ds = new DataSet())
                    //                                {
                    //                                    using (SqlConnection sc = new SqlConnection(db.DatebasePIVAsInfo()))
                    //                                    {
                    //                                        using (SqlDataAdapter sda = new SqlDataAdapter(dr["回传更新"].ToString().Split('|')[1], sc))
                    //                                        {
                    //                                            sda.Fill(ds);
                    //                                            ds.Tables[0].PrimaryKey = new DataColumn[] { ds.Tables[0].Columns[0] };
                    //                                            string pKey = ds.Tables[0].Columns[0].ColumnName;
                    //                                            foreach (DataRow drs in dss.Tables[0].Rows)
                    //                                            {
                    //                                                if (ds.Tables[0].Select(string.Format("{0}='{1}'", pKey, drs[pKey])).Length == 0)
                    //                                                {
                    //                                                    DataRow dsdr = ds.Tables[0].NewRow();
                    //                                                    dsdr[0] = drs[pKey];
                    //                                                    dsdr[1] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    //                                                    ds.Tables[0].Rows.Add(dsdr);
                    //                                                }
                    //                                            }
                    //                                            using (SqlCommandBuilder scb = new SqlCommandBuilder(sda))
                    //                                            {
                    //                                                scb.GetInsertCommand();
                    //                                                scb.DataAdapter.Update(ds.GetChanges(DataRowState.Added));
                    //                                            }
                    //                                        }
                    //                                    }
                    //                                }
                    //                            }
                    //                        }
                    //                        dss.Dispose();
                        //                }
                        //                catch (Exception ex)
                        //                {
                        //                    SaveErrLog("timer1_Elapsed_Thread", ex.Message);
                        //                }
                        //                finally
                        //                {
                        //                    dr["CanRun"] = true;
                        //                }
                        //            });
                        //            TH.IsBackground = true;
                        //            TH.Start();
                        //        }
                        //    }
                    //   }
                    //    catch (Exception ex)
                    //    {
                    //        SaveErrLog("timer1_Elapsed", ex.Message);
                    //    }
                    //}
                }
                catch (Exception ex)
                {
                    SaveErrLog("timer1_Elapsed", ex.Message);
                }
                CanRun = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!timer1.Enabled)
            {
               // CheckDLL();
                dataGridView1.ReadOnly = true;
                timer1.Enabled = true;
                button1.Text = "停止";
                timer1_Elapsed(sender, null);
            }
            else
            {
                
                dataGridView1.ReadOnly = false;
                timer1.Enabled = false;
                button1.Text = "启动";
            }
        }

        private void 删除ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!timer1.Enabled)
            {
                if (dataGridView1.RowCount > 0 && !dataGridView1.CurrentRow.IsNewRow)
                {
                    dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0: { timer1.Interval = 1000 * 60; break; }
                case 1: { timer1.Interval = 1000 * 180; break; }
                case 2: { timer1.Interval = 1000 * 600; break; }
                case 3: { timer1.Interval = 1000 * 1800; break; }
                case 4: { timer1.Interval = 1000 * 3600; break; }
                case 5: { timer1.Interval = 1000 * 18000; break; }
                default: { break; }
            }
        }

        private void dataGridView1_SizeChanged(object sender, EventArgs e)
        {
            dataGridView1.Columns[0].Width = 3 * dataGridView1.Width / 8;
            dataGridView1.Columns[1].Width = 150;
            dataGridView1.Columns[2].Width = 150;
            dataGridView1.Columns[3].Width = dataGridView1.Width / 4;
        }

        private void timer2_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (res.Rows.Count > 14)
            {
                res.Rows.RemoveAt(0);
            }
            dataGridView2.Refresh();
        }

        private bool SetAutoRun(bool isAutoRun)
        {
            try
            {
                string fileName = Application.StartupPath + "\\SynWebSer.exe";
                if (File.Exists(fileName))
                {
                    using (RegistryKey reg = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true))
                    {
                        if (isAutoRun)
                        {
                            reg.SetValue("SynServer", fileName);
                            reg.Flush();
                        }
                        else
                        {
                            reg.DeleteValue("SynServer", false);
                        }

                    }
                    return true;
                }
                else
                {
                    MessageBox.Show("执行文件不存在!");
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}
